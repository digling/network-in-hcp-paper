var networks = {"guangyun.gml": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "guangyun.gml",
    "name" : "guangyun.gml",
    "SUID" : 52,
    "__Annotations" : [ "" ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "548",
        "shared_name" : "德",
        "color" : "#9664c8",
        "name" : "德",
        "reading" : "tək",
        "SUID" : 548,
        "label" : "德",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -1908.3120764916796,
        "y" : 2380.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "shared_name" : "徒",
        "color" : "#9664c8",
        "name" : "徒",
        "reading" : "dʰu˩",
        "SUID" : 547,
        "label" : "徒",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -209.0843349057193,
        "y" : -864.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "shared_name" : "陟",
        "color" : "#9664c8",
        "name" : "陟",
        "reading" : "ţĭək",
        "SUID" : 546,
        "label" : "陟",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 389.4649352551339,
        "y" : -1582.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "shared_name" : "直",
        "color" : "#9664c8",
        "name" : "直",
        "reading" : "ɖʰĭək",
        "SUID" : 545,
        "label" : "直",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -257.3120764916796,
        "y" : -1377.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "shared_name" : "職",
        "color" : "#9664c8",
        "name" : "職",
        "reading" : "tɕĭək",
        "SUID" : 544,
        "label" : "職",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1119.3120764916796,
        "y" : -1724.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "敕",
        "color" : "#96c864",
        "name" : "敕",
        "reading" : "ţʰĭək",
        "SUID" : 543,
        "label" : "敕",
        "community" : 41,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 817.6879235083204,
        "y" : -2205.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "鋤",
        "color" : "#9664c8",
        "name" : "鋤",
        "reading" : "dʒʰĭo˩",
        "SUID" : 542,
        "label" : "鋤",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1863.6879235083204,
        "y" : -2265.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "shared_name" : "息",
        "color" : "#6496c8",
        "name" : "息",
        "reading" : "sĭək",
        "SUID" : 541,
        "label" : "息",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1902.1879235083204,
        "y" : 271.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "shared_name" : "如",
        "color" : "#64c8c8",
        "name" : "如",
        "reading" : "nʑĭo˩˥",
        "SUID" : 540,
        "label" : "如",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -738.3120764916796,
        "y" : 783.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "shared_name" : "居",
        "color" : "#c89664",
        "name" : "居",
        "reading" : "kĭo˥˩",
        "SUID" : 539,
        "label" : "居",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1916.6879235083204,
        "y" : -1253.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "以",
        "color" : "#c86464",
        "name" : "以",
        "reading" : "jĭə˥",
        "SUID" : 538,
        "label" : "以",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -840.3120764916796,
        "y" : -816.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "shared_name" : "羽",
        "color" : "#96c864",
        "name" : "羽",
        "reading" : "ĭu˩˥",
        "SUID" : 537,
        "label" : "羽",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -68.31207649167959,
        "y" : 1553.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "莫",
        "color" : "#64c896",
        "name" : "莫",
        "reading" : "mɑk",
        "SUID" : 536,
        "label" : "莫",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1241.496741811762,
        "y" : 156.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "shared_name" : "去",
        "color" : "#c89664",
        "name" : "去",
        "reading" : "kʰĭo˥",
        "SUID" : 535,
        "label" : "去",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1369.9156650942807,
        "y" : -1682.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "shared_name" : "渠",
        "color" : "#c89664",
        "name" : "渠",
        "reading" : "gʰĭo˩",
        "SUID" : 534,
        "label" : "渠",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1735.6879235083204,
        "y" : -1902.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "shared_name" : "房",
        "color" : "#c8c864",
        "name" : "房",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 533,
        "label" : "房",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1581.3121337890625,
        "y" : 276.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "shared_name" : "方",
        "color" : "#c8c864",
        "name" : "方",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 532,
        "label" : "方",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1420.3121337890625,
        "y" : 426.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "敷",
        "color" : "#c8c864",
        "name" : "敷",
        "reading" : "pʰĭu˥˩",
        "SUID" : 531,
        "label" : "敷",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1490.5032958984375,
        "y" : 1171.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "昌",
        "color" : "#9664c8",
        "name" : "昌",
        "reading" : "tɕʰĭaŋ˥˩",
        "SUID" : 530,
        "label" : "昌",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 1561.4526502945548,
        "y" : 1897.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "shared_name" : "力",
        "color" : "#6464c8",
        "name" : "力",
        "reading" : "lĭək",
        "SUID" : 529,
        "label" : "力",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 693.4967418117619,
        "y" : 1690.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "苦",
        "color" : "#c89664",
        "name" : "苦",
        "reading" : "kʰu˥",
        "SUID" : 528,
        "label" : "苦",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -47.086301582272654,
        "y" : 630.9779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "shared_name" : "古",
        "color" : "#c89664",
        "name" : "古",
        "reading" : "ku˥",
        "SUID" : 527,
        "label" : "古",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 225.68595683176704,
        "y" : 67.4779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "shared_name" : "盧",
        "color" : "#6464c8",
        "name" : "盧",
        "reading" : "lu˩",
        "SUID" : 526,
        "label" : "盧",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2433.6879235083206,
        "y" : 1860.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "shared_name" : "戸",
        "color" : "#c86464",
        "name" : "戸",
        "reading" : "ɣu˥",
        "SUID" : 525,
        "label" : "戸",
        "community" : 28,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1229.238531402004,
        "y" : 1464.4864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "徂",
        "color" : "#c89664",
        "name" : "徂",
        "reading" : "dzʰu˩",
        "SUID" : 524,
        "label" : "徂",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 2146.761468597996,
        "y" : 1863.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "shared_name" : "烏",
        "color" : "#96c864",
        "name" : "烏",
        "reading" : "ʔu˥˩",
        "SUID" : 523,
        "label" : "烏",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1302.996741811762,
        "y" : -942.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "shared_name" : "倉",
        "color" : "#9664c8",
        "name" : "倉",
        "reading" : "tsʰɑŋ˥˩",
        "SUID" : 522,
        "label" : "倉",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1770.0702869014378,
        "y" : 1579.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "shared_name" : "他",
        "color" : "#9664c8",
        "name" : "他",
        "reading" : "tʰɑ˥˩",
        "SUID" : 521,
        "label" : "他",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -671.0032581882381,
        "y" : -1246.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "shared_name" : "子",
        "color" : "#c89664",
        "name" : "子",
        "reading" : "tsĭə˥",
        "SUID" : 520,
        "label" : "子",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1328.3120764916796,
        "y" : -1268.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "薄",
        "color" : "#c8c864",
        "name" : "薄",
        "reading" : "bʰuɑk",
        "SUID" : 519,
        "label" : "薄",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1528.3121337890625,
        "y" : 69.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "呼",
        "color" : "#c89664",
        "name" : "呼",
        "reading" : "xu˥˩",
        "SUID" : 518,
        "label" : "呼",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1037.0066737881814,
        "y" : 1891.9252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "shared_name" : "五",
        "color" : "#64c8c8",
        "name" : "五",
        "reading" : "ŋu˥",
        "SUID" : 517,
        "label" : "五",
        "community" : 44,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -821.3120764916796,
        "y" : 366.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "shared_name" : "蘇",
        "color" : "#6496c8",
        "name" : "蘇",
        "reading" : "su˥˩",
        "SUID" : 516,
        "label" : "蘇",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 2028.6879235083204,
        "y" : 705.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "都",
        "color" : "#9664c8",
        "name" : "都",
        "reading" : "tu˥˩",
        "SUID" : 515,
        "label" : "都",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 746.6879235083204,
        "y" : -1818.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "shared_name" : "藏",
        "color" : "#c89664",
        "name" : "藏",
        "reading" : "dzʰɑŋ˩",
        "SUID" : 514,
        "label" : "藏",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 2115.761468597996,
        "y" : 1775.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "shared_name" : "奴",
        "color" : "#64c8c8",
        "name" : "奴",
        "reading" : "nu˩",
        "SUID" : 513,
        "label" : "奴",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : -1561.3120764916796,
        "y" : 2311.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "作",
        "color" : "#c89664",
        "name" : "作",
        "reading" : "tsu˩˥",
        "SUID" : 512,
        "label" : "作",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1555.3120764916796,
        "y" : -1440.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "shared_name" : "私",
        "color" : "#6496c8",
        "name" : "私",
        "reading" : "si˥˩",
        "SUID" : 511,
        "label" : "私",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1820.6879235083204,
        "y" : -3.8309458406215526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "shared_name" : "書",
        "color" : "#6496c8",
        "name" : "書",
        "reading" : "ɕĭo˥˩",
        "SUID" : 510,
        "label" : "書",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -890.3120764916796,
        "y" : -2051.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "shared_name" : "祥",
        "color" : "#6496c8",
        "name" : "祥",
        "reading" : "zĭaŋ˩",
        "SUID" : 509,
        "label" : "祥",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -895.3120764916796,
        "y" : -263.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "尺",
        "color" : "#9664c8",
        "name" : "尺",
        "reading" : "tɕʰĭɛk",
        "SUID" : 508,
        "label" : "尺",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 1561.4526502945548,
        "y" : 2020.6985077318463
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "shared_name" : "餘",
        "color" : "#c86464",
        "name" : "餘",
        "reading" : "jĭo˩",
        "SUID" : 507,
        "label" : "餘",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -950.3120764916796,
        "y" : -902.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "府",
        "color" : "#c8c864",
        "name" : "府",
        "reading" : "pĭu˥",
        "SUID" : 506,
        "label" : "府",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1433.3121337890625,
        "y" : 557.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "shared_name" : "許",
        "color" : "#c89664",
        "name" : "許",
        "reading" : "xĭo˥",
        "SUID" : 505,
        "label" : "許",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -487.5473497054454,
        "y" : 1480.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "魚",
        "color" : "#64c8c8",
        "name" : "魚",
        "reading" : "ŋĭo˩",
        "SUID" : 504,
        "label" : "魚",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -413.8120764916796,
        "y" : 288.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "shared_name" : "於",
        "color" : "#96c864",
        "name" : "於",
        "reading" : "ʔĭo˥˩",
        "SUID" : 503,
        "label" : "於",
        "community" : 1,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1492.1879235083204,
        "y" : -372.33094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "shared_name" : "女",
        "color" : "#64c8c8",
        "name" : "女",
        "reading" : "ɳĭo˩˥",
        "SUID" : 502,
        "label" : "女",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -593.3120764916796,
        "y" : 1052.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "shared_name" : "疾",
        "color" : "#c89664",
        "name" : "疾",
        "reading" : "dzʰĭĕt",
        "SUID" : 501,
        "label" : "疾",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1569.3120764916796,
        "y" : -1137.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "丑",
        "color" : "#9664c8",
        "name" : "丑",
        "reading" : "ţʰĭəu˥",
        "SUID" : 500,
        "label" : "丑",
        "community" : 41,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 764.6879235083204,
        "y" : -2106.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "shared_name" : "符",
        "color" : "#c8c864",
        "name" : "符",
        "reading" : "bʰĭu˩",
        "SUID" : 499,
        "label" : "符",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1458.3121337890625,
        "y" : 280.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "shared_name" : "即",
        "color" : "#c89664",
        "name" : "即",
        "reading" : "tsĭək",
        "SUID" : 498,
        "label" : "即",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1341.3120764916796,
        "y" : -1140.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "shared_name" : "而",
        "color" : "#64c8c8",
        "name" : "而",
        "reading" : "nʑĭə˩",
        "SUID" : 497,
        "label" : "而",
        "community" : 39,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -671.3120764916796,
        "y" : 865.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "shared_name" : "蜀",
        "color" : "#9664c8",
        "name" : "蜀",
        "reading" : "ʑĭwok",
        "SUID" : 496,
        "label" : "蜀",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -745.0473497054454,
        "y" : -1639.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "shared_name" : "九",
        "color" : "#c89664",
        "name" : "九",
        "reading" : "kĭəu˥",
        "SUID" : 495,
        "label" : "九",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 2185.6879235083206,
        "y" : -1242.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "七",
        "color" : "#9664c8",
        "name" : "七",
        "reading" : "tsʰĭĕt",
        "SUID" : 494,
        "label" : "七",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 2024.7614685979963,
        "y" : 1456.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "shared_name" : "曲",
        "color" : "#c89664",
        "name" : "曲",
        "reading" : "kʰĭwok",
        "SUID" : 493,
        "label" : "曲",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 994.6879235083204,
        "y" : -1606.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "shared_name" : "楚",
        "color" : "#9664c8",
        "name" : "楚",
        "reading" : "ʧʰĭo˥",
        "SUID" : 492,
        "label" : "楚",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1441.3120764916796,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "shared_name" : "博",
        "color" : "#c8c864",
        "name" : "博",
        "reading" : "puɑk",
        "SUID" : 491,
        "label" : "博",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1257.464935255134,
        "y" : 1534.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "shared_name" : "下",
        "color" : "#96c864",
        "name" : "下",
        "reading" : "ɣa˩˥",
        "SUID" : 490,
        "label" : "下",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1197.5473497054454,
        "y" : 2020.7511530311472
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "shared_name" : "匹",
        "color" : "#c8c864",
        "name" : "匹",
        "reading" : "pʰĭĕt",
        "SUID" : 489,
        "label" : "匹",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1241.3121337890625,
        "y" : 965.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "吕",
        "color" : "#6464c8",
        "name" : "吕",
        "reading" : "lĭo˥",
        "SUID" : 488,
        "label" : "吕",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 475.6879235083204,
        "y" : 1623.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "shared_name" : "所",
        "color" : "#6496c8",
        "name" : "所",
        "reading" : "ʃĭo˥",
        "SUID" : 487,
        "label" : "所",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : -853.9933262118188,
        "y" : 1627.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "shared_name" : "握",
        "color" : "#96c864",
        "name" : "握",
        "reading" : "ʔɔk",
        "SUID" : 486,
        "label" : "握",
        "community" : 1,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1334.117223020826,
        "y" : -487.1760321763836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "shared_name" : "宅",
        "color" : "#9664c8",
        "name" : "宅",
        "reading" : "ɖʰɐk",
        "SUID" : 485,
        "label" : "宅",
        "community" : 9,
        "selected" : false,
        "group" : "dr "
      },
      "position" : {
        "x" : 32.68792350832041,
        "y" : -1108.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "shared_name" : "士",
        "color" : "#9664c8",
        "name" : "士",
        "reading" : "dʒʰĭə˥",
        "SUID" : 484,
        "label" : "士",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1905.6879235083204,
        "y" : -2174.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "章",
        "color" : "#9664c8",
        "name" : "章",
        "reading" : "tɕĭaŋ˥˩",
        "SUID" : 483,
        "label" : "章",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1187.3120764916796,
        "y" : -1454.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "shared_name" : "弋",
        "color" : "#c86464",
        "name" : "弋",
        "reading" : "jĭək",
        "SUID" : 482,
        "label" : "弋",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -645.3120764916796,
        "y" : -805.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "shared_name" : "薳",
        "color" : "#96c864",
        "name" : "薳",
        "reading" : "ĭwe˥",
        "SUID" : 481,
        "label" : "薳",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 140.6879235083204,
        "y" : 1718.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "shared_name" : "靡",
        "color" : "#64c896",
        "name" : "靡",
        "reading" : "mĭe˥",
        "SUID" : 480,
        "label" : "靡",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 779.6879235083204,
        "y" : 887.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "shared_name" : "是",
        "color" : "#9664c8",
        "name" : "是",
        "reading" : "ʑĭe˥",
        "SUID" : 479,
        "label" : "是",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1072.3120764916796,
        "y" : -1128.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "shared_name" : "彼",
        "color" : "#c8c864",
        "name" : "彼",
        "reading" : "pĭe˥",
        "SUID" : 478,
        "label" : "彼",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1200.3121337890625,
        "y" : 416.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "shared_name" : "旬",
        "color" : "#6496c8",
        "name" : "旬",
        "reading" : "zĭuĕn˩",
        "SUID" : 477,
        "label" : "旬",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -796.3120764916796,
        "y" : -694.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "巨",
        "color" : "#c89664",
        "name" : "巨",
        "reading" : "gʰĭo˥",
        "SUID" : 476,
        "label" : "巨",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1716.6879235083204,
        "y" : -1821.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "shared_name" : "汝",
        "color" : "#64c8c8",
        "name" : "汝",
        "reading" : "nʑĭo˥",
        "SUID" : 475,
        "label" : "汝",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -781.3120764916796,
        "y" : 576.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "shared_name" : "式",
        "color" : "#6496c8",
        "name" : "式",
        "reading" : "ɕĭək",
        "SUID" : 474,
        "label" : "式",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -549.8120764916796,
        "y" : -2066.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "shared_name" : "武",
        "color" : "#64c896",
        "name" : "武",
        "reading" : "mĭu˥",
        "SUID" : 473,
        "label" : "武",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1083.964935255134,
        "y" : 717.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "shared_name" : "此",
        "color" : "#9664c8",
        "name" : "此",
        "reading" : "tsʰĭe˥",
        "SUID" : 472,
        "label" : "此",
        "community" : 59,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : -1345.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "shared_name" : "香",
        "color" : "#c89664",
        "name" : "香",
        "reading" : "xĭaŋ˥˩",
        "SUID" : 471,
        "label" : "香",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -610.3120764916796,
        "y" : 1480.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "shared_name" : "山",
        "color" : "#6496c8",
        "name" : "山",
        "reading" : "ʃæn˥˩",
        "SUID" : 470,
        "label" : "山",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -953.3120764916797,
        "y" : 1555.509758252715
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "shared_name" : "人",
        "color" : "#64c8c8",
        "name" : "人",
        "reading" : "nʑĭĕn˩",
        "SUID" : 469,
        "label" : "人",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -772.3120764916796,
        "y" : 683.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "shared_name" : "姊",
        "color" : "",
        "name" : "姊",
        "reading" : "",
        "SUID" : 468,
        "label" : "姊",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -1224.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "shared_name" : "遵",
        "color" : "#c89664",
        "name" : "遵",
        "reading" : "tsĭuĕn˥˩",
        "SUID" : 467,
        "label" : "遵",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1439.3120764916796,
        "y" : -928.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "shared_name" : "竹",
        "color" : "#9664c8",
        "name" : "竹",
        "reading" : "ţĭuk",
        "SUID" : 466,
        "label" : "竹",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 286.6879235083204,
        "y" : -1301.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "shared_name" : "叱",
        "color" : "",
        "name" : "叱",
        "reading" : "",
        "SUID" : 465,
        "label" : "叱",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -1103.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "shared_name" : "側",
        "color" : "#9664c8",
        "name" : "側",
        "reading" : "ʧĭək",
        "SUID" : 464,
        "label" : "側",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -1794.3120764916796,
        "y" : -1514.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "shared_name" : "恱",
        "color" : "#c86464",
        "name" : "恱",
        "reading" : "jĭwɛt",
        "SUID" : 463,
        "label" : "恱",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -549.3120764916796,
        "y" : -864.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "shared_name" : "旨",
        "color" : "#9664c8",
        "name" : "旨",
        "reading" : "tɕi˥",
        "SUID" : 462,
        "label" : "旨",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1129.3120764916796,
        "y" : -1840.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "shared_name" : "䟽",
        "color" : "#6496c8",
        "name" : "䟽",
        "reading" : "ʃĭo˩˥",
        "SUID" : 461,
        "label" : "䟽",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -816.0569393250751,
        "y" : 1510.9128607781363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "shared_name" : "處",
        "color" : "#9664c8",
        "name" : "處",
        "reading" : "tɕʰĭo˩˥",
        "SUID" : 460,
        "label" : "處",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 1438.6879235083204,
        "y" : 1897.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "shared_name" : "取",
        "color" : "#9664c8",
        "name" : "取",
        "reading" : "tsʰĭu˥",
        "SUID" : 459,
        "label" : "取",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1952.7614685979963,
        "y" : 1382.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "儒",
        "color" : "#64c8c8",
        "name" : "儒",
        "reading" : "nʑĭu˩",
        "SUID" : 458,
        "label" : "儒",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -870.3120764916796,
        "y" : 693.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "shared_name" : "視",
        "color" : "#9664c8",
        "name" : "視",
        "reading" : "ʑi˥",
        "SUID" : 457,
        "label" : "視",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -893.3120764916796,
        "y" : -1148.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "shared_name" : "洧",
        "color" : "#96c864",
        "name" : "洧",
        "reading" : "wi˥",
        "SUID" : 456,
        "label" : "洧",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -243.3120764916796,
        "y" : 1858.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "shared_name" : "叉",
        "color" : "#9664c8",
        "name" : "叉",
        "reading" : "ʧʰai˥˩",
        "SUID" : 455,
        "label" : "叉",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh "
      },
      "position" : {
        "x" : -1679.4325404042797,
        "y" : 1462.6076894725288
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "shared_name" : "丁",
        "color" : "#9664c8",
        "name" : "丁",
        "reading" : "ţæŋ˥˩",
        "SUID" : 454,
        "label" : "丁",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 567.6879235083204,
        "y" : -1900.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "醉",
        "color" : "#c89664",
        "name" : "醉",
        "reading" : "tswi˩˥",
        "SUID" : 453,
        "label" : "醉",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1320.3120764916796,
        "y" : -920.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "shared_name" : "丘",
        "color" : "#c89664",
        "name" : "丘",
        "reading" : "kʰĭəu˥˩",
        "SUID" : 452,
        "label" : "丘",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1085.6879235083204,
        "y" : -1625.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "shared_name" : "牛",
        "color" : "#64c8c8",
        "name" : "牛",
        "reading" : "ŋĭəu˩",
        "SUID" : 451,
        "label" : "牛",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -670.3120764916796,
        "y" : 97.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "shared_name" : "喜",
        "color" : "#c89664",
        "name" : "喜",
        "reading" : "xĭə˥",
        "SUID" : 450,
        "label" : "喜",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -512.0473497054454,
        "y" : 1859.4337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "shared_name" : "止",
        "color" : "#9664c8",
        "name" : "止",
        "reading" : "tɕĭə˥",
        "SUID" : 449,
        "label" : "止",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1299.3120764916796,
        "y" : -1682.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "與",
        "color" : "#c86464",
        "name" : "與",
        "reading" : "jĭo˩",
        "SUID" : 448,
        "label" : "與",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -752.3120764916796,
        "y" : -828.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "shared_name" : "市",
        "color" : "#9664c8",
        "name" : "市",
        "reading" : "ʑĭə˥",
        "SUID" : 447,
        "label" : "市",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -867.8120764916796,
        "y" : -1639.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "語",
        "color" : "#64c8c8",
        "name" : "語",
        "reading" : "ŋĭo˥",
        "SUID" : 446,
        "label" : "語",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -685.3120764916796,
        "y" : 199.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "shared_name" : "似",
        "color" : "#6496c8",
        "name" : "似",
        "reading" : "zĭə˥",
        "SUID" : 445,
        "label" : "似",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1044.503258188238,
        "y" : -526.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "shared_name" : "里",
        "color" : "#6464c8",
        "name" : "里",
        "reading" : "lĭə˥",
        "SUID" : 444,
        "label" : "里",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 320.6879235083204,
        "y" : 1738.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "shared_name" : "赤",
        "color" : "#9664c8",
        "name" : "赤",
        "reading" : "tɕʰĭɛk",
        "SUID" : 443,
        "label" : "赤",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 1684.2173770807892,
        "y" : 1897.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "shared_name" : "俟",
        "color" : "#6496c8",
        "name" : "俟",
        "reading" : "gʰĭəi˩",
        "SUID" : 442,
        "label" : "俟",
        "community" : 18,
        "selected" : false,
        "group" : "zr j"
      },
      "position" : {
        "x" : 1791.6879235083204,
        "y" : -1995.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "無",
        "color" : "#64c896",
        "name" : "無",
        "reading" : "mĭu˩",
        "SUID" : 441,
        "label" : "無",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 825.6879235083204,
        "y" : 713.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "shared_name" : "雨",
        "color" : "#96c864",
        "name" : "雨",
        "reading" : "ĭu˩˥",
        "SUID" : 440,
        "label" : "雨",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 120.68792350832041,
        "y" : 1587.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "shared_name" : "芳",
        "color" : "#c8c864",
        "name" : "芳",
        "reading" : "pʰĭwaŋ˥˩",
        "SUID" : 439,
        "label" : "芳",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1445.9832763671875,
        "y" : 862.2533569335938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "甫",
        "color" : "#c8c864",
        "name" : "甫",
        "reading" : "pĭu˥",
        "SUID" : 438,
        "label" : "甫",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1304.3121337890625,
        "y" : 444.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "shared_name" : "舉",
        "color" : "#c89664",
        "name" : "舉",
        "reading" : "kĭo˥",
        "SUID" : 437,
        "label" : "舉",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 2174.6879235083206,
        "y" : -1336.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "shared_name" : "傷",
        "color" : "#6496c8",
        "name" : "傷",
        "reading" : "ɕĭaŋ˩˥",
        "SUID" : 436,
        "label" : "傷",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -801.3120764916796,
        "y" : -2084.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "shared_name" : "強",
        "color" : "#c89664",
        "name" : "強",
        "reading" : "gʰĭaŋ˩",
        "SUID" : 435,
        "label" : "強",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1813.6879235083204,
        "y" : -1902.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "相",
        "color" : "#6496c8",
        "name" : "相",
        "reading" : "sĭaŋ˩˥",
        "SUID" : 434,
        "label" : "相",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1995.6879235083204,
        "y" : -3.8309458406215526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "shared_name" : "朽",
        "color" : "#c89664",
        "name" : "朽",
        "reading" : "xĭəu˥",
        "SUID" : 433,
        "label" : "朽",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -415.0473497054454,
        "y" : 1750.4337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "shared_name" : "央",
        "color" : "#96c864",
        "name" : "央",
        "reading" : "ʔĭaŋ˥˩",
        "SUID" : 432,
        "label" : "央",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1650.2586239958143,
        "y" : -487.17603217638384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "shared_name" : "署",
        "color" : "#9664c8",
        "name" : "署",
        "reading" : "ʑĭo˩˥",
        "SUID" : 431,
        "label" : "署",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -897.3120764916796,
        "y" : -1233.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "shared_name" : "遇",
        "color" : "#64c8c8",
        "name" : "遇",
        "reading" : "ŋĭu˩˥",
        "SUID" : 430,
        "label" : "遇",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -641.3120764916796,
        "y" : -1.8309458406215526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "shared_name" : "測",
        "color" : "#9664c8",
        "name" : "測",
        "reading" : "ʧʰĭək",
        "SUID" : 429,
        "label" : "測",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1781.3120764916796,
        "y" : 1942.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "況",
        "color" : "#c89664",
        "name" : "況",
        "reading" : "xĭwaŋ˩˥",
        "SUID" : 428,
        "label" : "況",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -364.78262291921124,
        "y" : 1480.9337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "shared_name" : "其",
        "color" : "#c89664",
        "name" : "其",
        "reading" : "gʰĭə˩",
        "SUID" : 427,
        "label" : "其",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1903.496741811762,
        "y" : -1665.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "shared_name" : "羊",
        "color" : "#c86464",
        "name" : "羊",
        "reading" : "jĭaŋ˩",
        "SUID" : 426,
        "label" : "羊",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -730.3120764916796,
        "y" : -754.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "shared_name" : "豈",
        "color" : "#c89664",
        "name" : "豈",
        "reading" : "kʰĭəi˥",
        "SUID" : 425,
        "label" : "豈",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1397.6879235083204,
        "y" : -1270.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "shared_name" : "防",
        "color" : "#c8c864",
        "name" : "防",
        "reading" : "bʰĭwaŋ˩˥",
        "SUID" : 424,
        "label" : "防",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1306.3121337890625,
        "y" : 295.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "shared_name" : "仕",
        "color" : "#9664c8",
        "name" : "仕",
        "reading" : "dʒʰĭə˥",
        "SUID" : 423,
        "label" : "仕",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 2065.6879235083206,
        "y" : -2093.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "莊",
        "color" : "#9664c8",
        "name" : "莊",
        "reading" : "ʧĭaŋ˥˩",
        "SUID" : 422,
        "label" : "莊",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -1877.3120764916796,
        "y" : -1594.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "shared_name" : "憶",
        "color" : "#96c864",
        "name" : "憶",
        "reading" : "ʔĭək",
        "SUID" : 421,
        "label" : "憶",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1125.6879235083204,
        "y" : -293.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "shared_name" : "同",
        "color" : "#9664c8",
        "name" : "同",
        "reading" : "dʰuŋ˩",
        "SUID" : 420,
        "label" : "同",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -72.31404316823296,
        "y" : -864.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "shared_name" : "乃",
        "color" : "#64c8c8",
        "name" : "乃",
        "reading" : "nɒi˥",
        "SUID" : 419,
        "label" : "乃",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : -1467.3120764916796,
        "y" : 2328.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "shared_name" : "荒",
        "color" : "#c89664",
        "name" : "荒",
        "reading" : "xuɑŋ˩˥",
        "SUID" : 418,
        "label" : "荒",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 937.6879235083204,
        "y" : 1819.7659516339577
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "shared_name" : "則",
        "color" : "#c89664",
        "name" : "則",
        "reading" : "tsək",
        "SUID" : 417,
        "label" : "則",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1438.3120764916796,
        "y" : -1368.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "shared_name" : "落",
        "color" : "#6464c8",
        "name" : "落",
        "reading" : "lɑk",
        "SUID" : 416,
        "label" : "落",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2334.6879235083206,
        "y" : 1856.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "shared_name" : "素",
        "color" : "#6496c8",
        "name" : "素",
        "reading" : "su˩˥",
        "SUID" : 415,
        "label" : "素",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 2034.6879235083204,
        "y" : 606.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "shared_name" : "昨",
        "color" : "#c89664",
        "name" : "昨",
        "reading" : "dzʰɑk",
        "SUID" : 414,
        "label" : "昨",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 1867.0702869014378,
        "y" : 1911.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "shared_name" : "哀",
        "color" : "#96c864",
        "name" : "哀",
        "reading" : "ʔɒi˥˩",
        "SUID" : 413,
        "label" : "哀",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1269.6879235083204,
        "y" : -699.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "shared_name" : "當",
        "color" : "#9664c8",
        "name" : "當",
        "reading" : "tɑŋ˥˩",
        "SUID" : 412,
        "label" : "當",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 675.6879235083204,
        "y" : -1901.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "shared_name" : "普",
        "color" : "#c8c864",
        "name" : "普",
        "reading" : "pʰu˥",
        "SUID" : 411,
        "label" : "普",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : -1713.3121337890625,
        "y" : 995.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "郎",
        "color" : "#6464c8",
        "name" : "郎",
        "reading" : "lɑŋ˩",
        "SUID" : 410,
        "label" : "郎",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 509.6879235083204,
        "y" : 1437.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "shared_name" : "杜",
        "color" : "#9664c8",
        "name" : "杜",
        "reading" : "dʰu˥",
        "SUID" : 409,
        "label" : "杜",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -332.310109815126,
        "y" : -805.4885402613618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "邊",
        "color" : "#c8c864",
        "name" : "邊",
        "reading" : "pien˥˩",
        "SUID" : 408,
        "label" : "邊",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 973.6879235083204,
        "y" : 1694.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "shared_name" : "胡",
        "color" : "#96c864",
        "name" : "胡",
        "reading" : "ɣu˩",
        "SUID" : 407,
        "label" : "胡",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1197.5473497054454,
        "y" : 1897.9864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "shared_name" : "先",
        "color" : "#6496c8",
        "name" : "先",
        "reading" : "sien˩˥",
        "SUID" : 406,
        "label" : "先",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 2022.6879235083204,
        "y" : 800.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "shared_name" : "土",
        "color" : "#9664c8",
        "name" : "土",
        "reading" : "tʰu˥",
        "SUID" : 405,
        "label" : "土",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -532.3120764916796,
        "y" : -950.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "部",
        "color" : "#c8c864",
        "name" : "部",
        "reading" : "bʰu˥",
        "SUID" : 404,
        "label" : "部",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1399.3121337890625,
        "y" : 52.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "shared_name" : "成",
        "color" : "#9664c8",
        "name" : "成",
        "reading" : "ʑĭɛŋ˩",
        "SUID" : 403,
        "label" : "成",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1109.3120764916796,
        "y" : -1026.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "shared_name" : "火",
        "color" : "#c89664",
        "name" : "火",
        "reading" : "xuɑ˥",
        "SUID" : 402,
        "label" : "火",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1159.7714005744153,
        "y" : 1891.9252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "shared_name" : "妳",
        "color" : "",
        "name" : "妳",
        "reading" : "",
        "SUID" : 401,
        "label" : "妳",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -982.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "shared_name" : "乙",
        "color" : "#96c864",
        "name" : "乙",
        "reading" : "ʔĭĕt",
        "SUID" : 400,
        "label" : "乙",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1334.117223020826,
        "y" : -257.4858595048595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "shared_name" : "步",
        "color" : "#c8c864",
        "name" : "步",
        "reading" : "bʰu˩˥",
        "SUID" : 399,
        "label" : "步",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1577.3121337890625,
        "y" : 157.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "卓",
        "color" : "#9664c8",
        "name" : "卓",
        "reading" : "ţɔk",
        "SUID" : 398,
        "label" : "卓",
        "community" : 19,
        "selected" : false,
        "group" : "tr "
      },
      "position" : {
        "x" : 352.6879235083204,
        "y" : -1214.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "shared_name" : "賴",
        "color" : "#6464c8",
        "name" : "賴",
        "reading" : "lɑi˩˥",
        "SUID" : 397,
        "label" : "賴",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2267.6879235083206,
        "y" : 1927.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "口",
        "color" : "#c89664",
        "name" : "口",
        "reading" : "kʰəu˥",
        "SUID" : 396,
        "label" : "口",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -170.31207649167936,
        "y" : 690.3203645814797
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "shared_name" : "擬",
        "color" : "#64c8c8",
        "name" : "擬",
        "reading" : "ŋĭə˥",
        "SUID" : 395,
        "label" : "擬",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -413.8120764916796,
        "y" : 411.43378094561285
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "shared_name" : "公",
        "color" : "#c89664",
        "name" : "公",
        "reading" : "kuŋ˥˩",
        "SUID" : 394,
        "label" : "公",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 336.21304340598294,
        "y" : 178.0050455764358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "shared_name" : "魯",
        "color" : "#6464c8",
        "name" : "魯",
        "reading" : "lu˥",
        "SUID" : 393,
        "label" : "魯",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 571.6879235083204,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "布",
        "color" : "#c8c864",
        "name" : "布",
        "reading" : "pu˩˥",
        "SUID" : 392,
        "label" : "布",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1013.6879235083204,
        "y" : 1603.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "shared_name" : "臧",
        "color" : "#c89664",
        "name" : "臧",
        "reading" : "tsɑŋ˥˩",
        "SUID" : 391,
        "label" : "臧",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1548.3120764916796,
        "y" : -1347.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "shared_name" : "祖",
        "color" : "#c89664",
        "name" : "祖",
        "reading" : "tsu˥",
        "SUID" : 390,
        "label" : "祖",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1449.3120764916796,
        "y" : -1479.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "shared_name" : "扶",
        "color" : "#c8c864",
        "name" : "扶",
        "reading" : "bʰĭu˩",
        "SUID" : 389,
        "label" : "扶",
        "community" : 2,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1394.3121337890625,
        "y" : 372.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "shared_name" : "植",
        "color" : "#9664c8",
        "name" : "植",
        "reading" : "ɖʰĭə˩˥",
        "SUID" : 388,
        "label" : "植",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -606.3120764916796,
        "y" : -1452.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "shared_name" : "食",
        "color" : "#6496c8",
        "name" : "食",
        "reading" : "jĭə˩˥",
        "SUID" : 387,
        "label" : "食",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -633.0901229068502,
        "y" : -620.4142890603068
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "失",
        "color" : "#6496c8",
        "name" : "失",
        "reading" : "ɕĭĕt",
        "SUID" : 386,
        "label" : "失",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -427.0473497054452,
        "y" : -2066.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "shared_name" : "必",
        "color" : "#c8c864",
        "name" : "必",
        "reading" : "pĭĕt",
        "SUID" : 385,
        "label" : "必",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1817.3121337890625,
        "y" : 273.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "shared_name" : "將",
        "color" : "#c89664",
        "name" : "將",
        "reading" : "tsĭaŋ˥˩",
        "SUID" : 384,
        "label" : "將",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1369.3120764916796,
        "y" : -1017.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "shared_name" : "匠",
        "color" : "#c89664",
        "name" : "匠",
        "reading" : "dzʰĭaŋ˩˥",
        "SUID" : 383,
        "label" : "匠",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1618.3120764916796,
        "y" : -1033.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "shared_name" : "翼",
        "color" : "#c86464",
        "name" : "翼",
        "reading" : "jĭək",
        "SUID" : 382,
        "label" : "翼",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -736.3120764916796,
        "y" : -898.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "shared_name" : "爲",
        "color" : "#96c864",
        "name" : "爲",
        "reading" : "ĭwe˩",
        "SUID" : 381,
        "label" : "爲",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 36.68792350832041,
        "y" : 1718.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "彌",
        "color" : "#64c896",
        "name" : "彌",
        "reading" : "mĭe˩",
        "SUID" : 380,
        "label" : "彌",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1121.9013221418775,
        "y" : 600.9128607781363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "shared_name" : "常",
        "color" : "#9664c8",
        "name" : "常",
        "reading" : "ʑĭaŋ˩",
        "SUID" : 379,
        "label" : "常",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -767.3120764916796,
        "y" : -1048.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "shared_name" : "詳",
        "color" : "#6496c8",
        "name" : "詳",
        "reading" : "jĭaŋ˩",
        "SUID" : 378,
        "label" : "詳",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -831.3120764916796,
        "y" : -752.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "shared_name" : "王",
        "color" : "#96c864",
        "name" : "王",
        "reading" : "ĭwaŋ˩",
        "SUID" : 377,
        "label" : "王",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 26.68792350832041,
        "y" : 1551.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "shared_name" : "愚",
        "color" : "#64c8c8",
        "name" : "愚",
        "reading" : "ŋĭu˩",
        "SUID" : 376,
        "label" : "愚",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -688.3120764916796,
        "y" : -88.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "附",
        "color" : "#c8c864",
        "name" : "附",
        "reading" : "bʰĭu˩˥",
        "SUID" : 375,
        "label" : "附",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1415.3121337890625,
        "y" : 205.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "孚",
        "color" : "#c8c864",
        "name" : "孚",
        "reading" : "pʰĭu˥˩",
        "SUID" : 374,
        "label" : "孚",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1430.3121337890625,
        "y" : 789.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "shared_name" : "虚",
        "color" : "#c89664",
        "name" : "虚",
        "reading" : "kʰĭo˥˩",
        "SUID" : 373,
        "label" : "虚",
        "community" : 4,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : 1455.190547189847,
        "y" : -1789.2622657873255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "shared_name" : "謁",
        "color" : "#96c864",
        "name" : "謁",
        "reading" : "ʔĭɐt",
        "SUID" : 372,
        "label" : "謁",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1431.810288547602,
        "y" : -186.5076927084424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "shared_name" : "思",
        "color" : "#6496c8",
        "name" : "思",
        "reading" : "sĭə˥˩",
        "SUID" : 371,
        "label" : "思",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 2078.6879235083206,
        "y" : 40.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "蒲",
        "color" : "#c8c864",
        "name" : "蒲",
        "reading" : "bʰu˩",
        "SUID" : 370,
        "label" : "蒲",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1489.3121337890625,
        "y" : 6.16905403137207
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "shared_name" : "吐",
        "color" : "#9664c8",
        "name" : "吐",
        "reading" : "tʰu˥",
        "SUID" : 369,
        "label" : "吐",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -543.3120764916796,
        "y" : -1581.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "俄",
        "color" : "#64c8c8",
        "name" : "俄",
        "reading" : "ŋɑ˩",
        "SUID" : 368,
        "label" : "俄",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : -907.3120764916796,
        "y" : 414.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "shared_name" : "那",
        "color" : "#64c8c8",
        "name" : "那",
        "reading" : "nɑ˩",
        "SUID" : 367,
        "label" : "那",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : -1631.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "shared_name" : "多",
        "color" : "#9664c8",
        "name" : "多",
        "reading" : "tɑ˥˩",
        "SUID" : 366,
        "label" : "多",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -1842.3120764916796,
        "y" : 2312.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "shared_name" : "一",
        "color" : "#96c864",
        "name" : "一",
        "reading" : "ʔĭĕt",
        "SUID" : 365,
        "label" : "一",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1296.8017924547682,
        "y" : -372.33094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "shared_name" : "度",
        "color" : "#9664c8",
        "name" : "度",
        "reading" : "dʰɑk",
        "SUID" : 364,
        "label" : "度",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -239.51858796062243,
        "y" : -731.489770868495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "shared_name" : "在",
        "color" : "#c89664",
        "name" : "在",
        "reading" : "dzʰɒi˩˥",
        "SUID" : 363,
        "label" : "在",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 1989.8350136876722,
        "y" : 1911.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "shared_name" : "借",
        "color" : "#c89664",
        "name" : "借",
        "reading" : "tsĭa˩˥",
        "SUID" : 362,
        "label" : "借",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1245.3120764916796,
        "y" : -1197.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "shared_name" : "母",
        "color" : "#64c896",
        "name" : "母",
        "reading" : "məu˥",
        "SUID" : 361,
        "label" : "母",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1364.2614685979963,
        "y" : 156.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "shared_name" : "北",
        "color" : "#c8c864",
        "name" : "北",
        "reading" : "pək",
        "SUID" : 360,
        "label" : "北",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1380.2296620413679,
        "y" : 1534.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "shared_name" : "數",
        "color" : "#6496c8",
        "name" : "數",
        "reading" : "ʃɔk",
        "SUID" : 359,
        "label" : "數",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -851.7703379586321,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "shared_name" : "可",
        "color" : "#c89664",
        "name" : "可",
        "reading" : "kʰɑ˥",
        "SUID" : 358,
        "label" : "可",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 100.68595683176704,
        "y" : 992.9779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "shared_name" : "阻",
        "color" : "#9664c8",
        "name" : "阻",
        "reading" : "ʧĭo˥",
        "SUID" : 357,
        "label" : "阻",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -1908.3120764916796,
        "y" : -1500.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "充",
        "color" : "#9664c8",
        "name" : "充",
        "reading" : "tɕʰĭuŋ˥˩",
        "SUID" : 356,
        "label" : "充",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 1561.4526502945548,
        "y" : 1775.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "shared_name" : "委",
        "color" : "#96c864",
        "name" : "委",
        "reading" : "ʔĭwe˥",
        "SUID" : 355,
        "label" : "委",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1552.5655584690387,
        "y" : -186.5076927084424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "墜",
        "color" : "#9664c8",
        "name" : "墜",
        "reading" : "ɖʰwi˩˥",
        "SUID" : 354,
        "label" : "墜",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -195.9297130985624,
        "y" : -1271.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "shared_name" : "跪",
        "color" : "#c89664",
        "name" : "跪",
        "reading" : "kʰĭwe˥",
        "SUID" : 353,
        "label" : "跪",
        "community" : 4,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1640.6879235083204,
        "y" : -1851.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "shared_name" : "獲",
        "color" : "#96c864",
        "name" : "獲",
        "reading" : "ɣwæk",
        "SUID" : 352,
        "label" : "獲",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1074.7826229192112,
        "y" : 1897.9864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "shared_name" : "並",
        "color" : "#c8c864",
        "name" : "並",
        "reading" : "bʰieŋ˥",
        "SUID" : 351,
        "label" : "並",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1448.3121337890625,
        "y" : -88.83094787597656
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "目",
        "color" : "#64c896",
        "name" : "目",
        "reading" : "mĭuk",
        "SUID" : 350,
        "label" : "目",
        "community" : 33,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1259.6879235083204,
        "y" : 407.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "shared_name" : "卜",
        "color" : "#c8c864",
        "name" : "卜",
        "reading" : "puk",
        "SUID" : 349,
        "label" : "卜",
        "community" : 14,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 1158.146184975273,
        "y" : 1606.3283500660418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "偏",
        "color" : "#c8c864",
        "name" : "偏",
        "reading" : "pʰĭɛn˥˩",
        "SUID" : 348,
        "label" : "偏",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1318.3121337890625,
        "y" : 890.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "shared_name" : "蒼",
        "color" : "#9664c8",
        "name" : "蒼",
        "reading" : "tsʰɑŋ˥˩",
        "SUID" : 347,
        "label" : "蒼",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 2073.761468597996,
        "y" : 1547.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "shared_name" : "崇",
        "color" : "#9664c8",
        "name" : "崇",
        "reading" : "dʒʰĭuŋ˩",
        "SUID" : 346,
        "label" : "崇",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1840.6879235083204,
        "y" : -2366.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "shared_name" : "諸",
        "color" : "#9664c8",
        "name" : "諸",
        "reading" : "tɕĭo˥˩",
        "SUID" : 345,
        "label" : "諸",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1256.3120764916796,
        "y" : -1568.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "張",
        "color" : "#9664c8",
        "name" : "張",
        "reading" : "ţĭaŋ˥˩",
        "SUID" : 344,
        "label" : "張",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 196.6879235083204,
        "y" : -1363.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "shared_name" : "須",
        "color" : "#6496c8",
        "name" : "須",
        "reading" : "sĭu˥˩",
        "SUID" : 343,
        "label" : "須",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 2046.6879235083204,
        "y" : -88.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "卑",
        "color" : "#c8c864",
        "name" : "卑",
        "reading" : "dzʰæn˩",
        "SUID" : 342,
        "label" : "卑",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1782.3121337890625,
        "y" : 187.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "shared_name" : "夕",
        "color" : "#6496c8",
        "name" : "夕",
        "reading" : "zĭɛk",
        "SUID" : 341,
        "label" : "夕",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -804.3120764916796,
        "y" : -201.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "shared_name" : "有",
        "color" : "#96c864",
        "name" : "有",
        "reading" : "ĭəu˥",
        "SUID" : 340,
        "label" : "有",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -37.31207649167959,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "shared_name" : "于",
        "color" : "#96c864",
        "name" : "于",
        "reading" : "ĭu˩",
        "SUID" : 339,
        "label" : "于",
        "community" : 6,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : -32.31207649167959,
        "y" : 1643.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "撫",
        "color" : "#c8c864",
        "name" : "撫",
        "reading" : "pʰĭu˥",
        "SUID" : 338,
        "label" : "撫",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1359.3121337890625,
        "y" : 965.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "shared_name" : "起",
        "color" : "#c89664",
        "name" : "起",
        "reading" : "kʰĭə˥",
        "SUID" : 337,
        "label" : "起",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1143.6879235083204,
        "y" : -1944.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "shared_name" : "鉏",
        "color" : "#9664c8",
        "name" : "鉏",
        "reading" : "dʒʰĭo˩",
        "SUID" : 336,
        "label" : "鉏",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1962.6879235083204,
        "y" : -2093.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "shared_name" : "得",
        "color" : "#9664c8",
        "name" : "得",
        "reading" : "tək",
        "SUID" : 335,
        "label" : "得",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -1774.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "shared_name" : "託",
        "color" : "#9664c8",
        "name" : "託",
        "reading" : "tʰɑk",
        "SUID" : 334,
        "label" : "託",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -548.2385314020039,
        "y" : -1246.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "諾",
        "color" : "#64c8c8",
        "name" : "諾",
        "reading" : "nɑk",
        "SUID" : 333,
        "label" : "諾",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : -1653.3120764916796,
        "y" : 2337.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "shared_name" : "虎",
        "color" : "#c89664",
        "name" : "虎",
        "reading" : "xu˥",
        "SUID" : 332,
        "label" : "虎",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1287.2296620413679,
        "y" : 2025.4252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "shared_name" : "滂",
        "color" : "#c8c864",
        "name" : "滂",
        "reading" : "pʰɑŋ˥˩",
        "SUID" : 331,
        "label" : "滂",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : -1628.3121337890625,
        "y" : 946.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "shared_name" : "求",
        "color" : "#c89664",
        "name" : "求",
        "reading" : "gʰĭəu˩",
        "SUID" : 330,
        "label" : "求",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1761.6879235083204,
        "y" : -1863.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "shared_name" : "醋",
        "color" : "#9664c8",
        "name" : "醋",
        "reading" : "tsʰu˩˥",
        "SUID" : 329,
        "label" : "醋",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1892.8350136876722,
        "y" : 1579.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "縷",
        "color" : "#6464c8",
        "name" : "縷",
        "reading" : "lĭu˥",
        "SUID" : 328,
        "label" : "縷",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 816.2614685979959,
        "y" : 1690.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "shared_name" : "正",
        "color" : "#9664c8",
        "name" : "正",
        "reading" : "tɕĭɛŋ˥˩",
        "SUID" : 327,
        "label" : "正",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1208.3120764916796,
        "y" : -1662.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "伯",
        "color" : "#c8c864",
        "name" : "伯",
        "reading" : "pɐk",
        "SUID" : 326,
        "label" : "伯",
        "community" : 14,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 1507.6879235083204,
        "y" : 1405.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "shared_name" : "初",
        "color" : "#9664c8",
        "name" : "初",
        "reading" : "ʧʰĭo˥˩",
        "SUID" : 325,
        "label" : "初",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1724.3120764916796,
        "y" : 1718.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "shared_name" : "才",
        "color" : "#c89664",
        "name" : "才",
        "reading" : "dzʰɒi˩",
        "SUID" : 324,
        "label" : "才",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 1805.6879235083204,
        "y" : 1804.8516820738437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "shared_name" : "寫",
        "color" : "#6496c8",
        "name" : "寫",
        "reading" : "sĭa˥",
        "SUID" : 323,
        "label" : "寫",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1525.6879235083204,
        "y" : 262.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "shared_name" : "乞",
        "color" : "#c89664",
        "name" : "乞",
        "reading" : "kʰĭət",
        "SUID" : 322,
        "label" : "乞",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1455.190547189847,
        "y" : -1575.3996258939178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "shared_name" : "色",
        "color" : "#6496c8",
        "name" : "色",
        "reading" : "ʃĭək",
        "SUID" : 321,
        "label" : "色",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : -943.7703379586321,
        "y" : 1379.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "客",
        "color" : "#c89664",
        "name" : "客",
        "reading" : "kʰɐk",
        "SUID" : 320,
        "label" : "客",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 38.1885805132938,
        "y" : 737.9092789489237
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "shared_name" : "助",
        "color" : "#9664c8",
        "name" : "助",
        "reading" : "dʒʰĭo˩˥",
        "SUID" : 319,
        "label" : "助",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1773.6879235083204,
        "y" : -2132.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "shared_name" : "永",
        "color" : "#96c864",
        "name" : "永",
        "reading" : "ĭwɐŋ˥",
        "SUID" : 318,
        "label" : "永",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -90.31207649167959,
        "y" : 1731.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "shared_name" : "中",
        "color" : "#9664c8",
        "name" : "中",
        "reading" : "ţĭuŋ˩˥",
        "SUID" : 317,
        "label" : "中",
        "community" : 46,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 463.6879235083204,
        "y" : -1869.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "shared_name" : "余",
        "color" : "#c86464",
        "name" : "余",
        "reading" : "jĭo˩",
        "SUID" : 316,
        "label" : "余",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -845.3120764916796,
        "y" : -899.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "shared_name" : "特",
        "color" : "#9664c8",
        "name" : "特",
        "reading" : "dʰək",
        "SUID" : 315,
        "label" : "特",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -123.80945281015283,
        "y" : -757.8996258939178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "桑",
        "color" : "#6496c8",
        "name" : "桑",
        "reading" : "sɑŋ˥˩",
        "SUID" : 314,
        "label" : "桑",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 2047.6879235083204,
        "y" : 509.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "shared_name" : "煑",
        "color" : "#9664c8",
        "name" : "煑",
        "reading" : "tɕĭo˥",
        "SUID" : 313,
        "label" : "煑",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1293.3120764916796,
        "y" : -1469.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "筆",
        "color" : "#c8c864",
        "name" : "筆",
        "reading" : "pĭĕt",
        "SUID" : 312,
        "label" : "筆",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1292.3121337890625,
        "y" : 606.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "shared_name" : "識",
        "color" : "#9664c8",
        "name" : "識",
        "reading" : "tɕĭə˩˥",
        "SUID" : 311,
        "label" : "識",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -997.3120764916796,
        "y" : -1933.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "shared_name" : "虛",
        "color" : "#c89664",
        "name" : "虛",
        "reading" : "xĭo˥˩",
        "SUID" : 310,
        "label" : "虛",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -510.0473497054454,
        "y" : 1761.4337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "shared_name" : "綺",
        "color" : "#c89664",
        "name" : "綺",
        "reading" : "kʰĭe˥",
        "SUID" : 309,
        "label" : "綺",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1026.6879235083204,
        "y" : -1842.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "自",
        "color" : "#c89664",
        "name" : "自",
        "reading" : "dzʰi˩˥",
        "SUID" : 308,
        "label" : "自",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1656.3120764916796,
        "y" : -1211.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "shared_name" : "耳",
        "color" : "#64c8c8",
        "name" : "耳",
        "reading" : "nʑĭə˥",
        "SUID" : 307,
        "label" : "耳",
        "community" : 39,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -578.3120764916796,
        "y" : 831.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "shared_name" : "縛",
        "color" : "#c8c864",
        "name" : "縛",
        "reading" : "bʰĭwak",
        "SUID" : 306,
        "label" : "縛",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1339.3121337890625,
        "y" : 207.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "shared_name" : "速",
        "color" : "#6496c8",
        "name" : "速",
        "reading" : "suk",
        "SUID" : 305,
        "label" : "速",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 2142.6879235083206,
        "y" : 504.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "shared_name" : "恪",
        "color" : "#c89664",
        "name" : "恪",
        "reading" : "kʰɑk",
        "SUID" : 304,
        "label" : "恪",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -77.52055463717579,
        "y" : 764.3191339743466
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "shared_name" : "千",
        "color" : "#9664c8",
        "name" : "千",
        "reading" : "tsʰien˥˩",
        "SUID" : 303,
        "label" : "千",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 2163.761468597996,
        "y" : 1586.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "shared_name" : "亡",
        "color" : "#64c896",
        "name" : "亡",
        "reading" : "mĭwaŋ˩",
        "SUID" : 302,
        "label" : "亡",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 984.646184975273,
        "y" : 789.8283500660418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "shared_name" : "皮",
        "color" : "#c8c864",
        "name" : "皮",
        "reading" : "bʰĭe˩",
        "SUID" : 301,
        "label" : "皮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1382.3121337890625,
        "y" : 284.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "shared_name" : "徐",
        "color" : "#6496c8",
        "name" : "徐",
        "reading" : "zĭo˩",
        "SUID" : 300,
        "label" : "徐",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -921.7385314020039,
        "y" : -526.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "shared_name" : "知",
        "color" : "#9664c8",
        "name" : "知",
        "reading" : "ţĭe˥˩",
        "SUID" : 299,
        "label" : "知",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 127.68792350832041,
        "y" : -1455.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "shared_name" : "氏",
        "color" : "#9664c8",
        "name" : "氏",
        "reading" : "tɕĭe˥˩",
        "SUID" : 298,
        "label" : "氏",
        "community" : 23,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1174.3120764916796,
        "y" : -1301.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "shared_name" : "挹",
        "color" : "#96c864",
        "name" : "挹",
        "reading" : "ʔĭĕp",
        "SUID" : 297,
        "label" : "挹",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1943.6879235083204,
        "y" : -323.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "shared_name" : "史",
        "color" : "#6496c8",
        "name" : "史",
        "reading" : "ʃĭə˥",
        "SUID" : 296,
        "label" : "史",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : -825.7703379586321,
        "y" : 1991.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "shared_name" : "勒",
        "color" : "#6464c8",
        "name" : "勒",
        "reading" : "lək",
        "SUID" : 295,
        "label" : "勒",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2491.6879235083206,
        "y" : 1939.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "shared_name" : "白",
        "color" : "#c8c864",
        "name" : "白",
        "reading" : "bʰɐk",
        "SUID" : 294,
        "label" : "白",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1685.3121337890625,
        "y" : -9.83094596862793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "shared_name" : "名",
        "color" : "#64c896",
        "name" : "名",
        "reading" : "mĭɛŋ˩",
        "SUID" : 293,
        "label" : "名",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1206.7296620413679,
        "y" : 717.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "shared_name" : "僕",
        "color" : "#c8c864",
        "name" : "僕",
        "reading" : "bʰuok",
        "SUID" : 292,
        "label" : "僕",
        "community" : 25,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1479.3121337890625,
        "y" : 105.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "shared_name" : "康",
        "color" : "#c89664",
        "name" : "康",
        "reading" : "kʰɑŋ˥˩",
        "SUID" : 291,
        "label" : "康",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -77.52055463717602,
        "y" : 497.63678403009317
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "shared_name" : "之",
        "color" : "#9664c8",
        "name" : "之",
        "reading" : "tɕĭə˥˩",
        "SUID" : 290,
        "label" : "之",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1215.3120764916796,
        "y" : -1757.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "shared_name" : "時",
        "color" : "#9664c8",
        "name" : "時",
        "reading" : "ʑĭə˩",
        "SUID" : 289,
        "label" : "時",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -867.8120764916796,
        "y" : -1762.0956726268557
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "shared_name" : "歩",
        "color" : "",
        "name" : "歩",
        "reading" : "",
        "SUID" : 288,
        "label" : "歩",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -861.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "shared_name" : "巴",
        "color" : "#c8c864",
        "name" : "巴",
        "reading" : "pa˥˩",
        "SUID" : 287,
        "label" : "巴",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1587.6879235083204,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "shared_name" : "承",
        "color" : "#9664c8",
        "name" : "承",
        "reading" : "ʑĭəŋ˩",
        "SUID" : 286,
        "label" : "承",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1026.3120764916796,
        "y" : -1228.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "shared_name" : "文",
        "color" : "#64c896",
        "name" : "文",
        "reading" : "mĭuən˩",
        "SUID" : 285,
        "label" : "文",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 838.6879235083204,
        "y" : 810.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "shared_name" : "過",
        "color" : "#c89664",
        "name" : "過",
        "reading" : "kuɑ˩˥",
        "SUID" : 284,
        "label" : "過",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 542.685956831767,
        "y" : -7.0220409977800955
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "shared_name" : "墟",
        "color" : "#c89664",
        "name" : "墟",
        "reading" : "kʰĭo˥˩",
        "SUID" : 283,
        "label" : "墟",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1112.6879235083204,
        "y" : -1846.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "shared_name" : "韋",
        "color" : "#96c864",
        "name" : "韋",
        "reading" : "ĭwəi˩",
        "SUID" : 282,
        "label" : "韋",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 199.6879235083204,
        "y" : 1644.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "shared_name" : "雌",
        "color" : "#9664c8",
        "name" : "雌",
        "reading" : "tsʰĭe˥˩",
        "SUID" : 281,
        "label" : "雌",
        "community" : 59,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : -1346.3120764916796,
        "y" : 2322.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "shared_name" : "池",
        "color" : "#9664c8",
        "name" : "池",
        "reading" : "ɖʰĭe˩",
        "SUID" : 280,
        "label" : "池",
        "community" : 30,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -412.3120764916796,
        "y" : -1123.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "shared_name" : "斯",
        "color" : "#6496c8",
        "name" : "斯",
        "reading" : "sĭe˥˩",
        "SUID" : 279,
        "label" : "斯",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1902.1879235083204,
        "y" : 148.90432737314404
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "移",
        "color" : "#c86464",
        "name" : "移",
        "reading" : "jĭe˩",
        "SUID" : 278,
        "label" : "移",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -555.3120764916796,
        "y" : -793.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "shared_name" : "并",
        "color" : "#c8c864",
        "name" : "并",
        "reading" : "pĭɛŋ˥˩",
        "SUID" : 277,
        "label" : "并",
        "community" : 2,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1517.3121337890625,
        "y" : 616.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "shared_name" : "兒",
        "color" : "#64c8c8",
        "name" : "兒",
        "reading" : "nʑĭe˩",
        "SUID" : 276,
        "label" : "兒",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -796.3120764916796,
        "y" : 472.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "shared_name" : "綿",
        "color" : "#64c896",
        "name" : "綿",
        "reading" : "mĭɛn˩",
        "SUID" : 275,
        "label" : "綿",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 984.646184975273,
        "y" : 645.5097582527151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "便",
        "color" : "#c8c864",
        "name" : "便",
        "reading" : "bʰĭɛn˩",
        "SUID" : 274,
        "label" : "便",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1611.3121337890625,
        "y" : 382.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "shared_name" : "施",
        "color" : "#6496c8",
        "name" : "施",
        "reading" : "ɕĭe˥˩",
        "SUID" : 273,
        "label" : "施",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -358.3120764916796,
        "y" : -2305.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "shared_name" : "隨",
        "color" : "#6496c8",
        "name" : "隨",
        "reading" : "zĭwe˩",
        "SUID" : 272,
        "label" : "隨",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -784.3120764916796,
        "y" : -629.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "shared_name" : "神",
        "color" : "#6496c8",
        "name" : "神",
        "reading" : "dʑʰĭĕn˩",
        "SUID" : 271,
        "label" : "神",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -652.1977987089774,
        "y" : -504.9374657344083
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "shared_name" : "興",
        "color" : "#c89664",
        "name" : "興",
        "reading" : "xĭəŋ˥˩",
        "SUID" : 270,
        "label" : "興",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -603.0473497054454,
        "y" : 1735.4337809456124
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "shared_name" : "榮",
        "color" : "#96c864",
        "name" : "榮",
        "reading" : "ĭwɐŋ˩",
        "SUID" : 269,
        "label" : "榮",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -165.3120764916796,
        "y" : 1798.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "豬",
        "color" : "#9664c8",
        "name" : "豬",
        "reading" : "ţĭo˥˩",
        "SUID" : 268,
        "label" : "豬",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 290.14618497527294,
        "y" : -1654.4902417472847
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "shared_name" : "楮",
        "color" : "#9664c8",
        "name" : "楮",
        "reading" : "ţʰĭo˥",
        "SUID" : 267,
        "label" : "楮",
        "community" : 41,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 716.6879235083204,
        "y" : -2002.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "曁",
        "color" : "#c89664",
        "name" : "曁",
        "reading" : "kĭət",
        "SUID" : 266,
        "label" : "曁",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1855.3055601152034,
        "y" : -1147.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "shared_name" : "踈",
        "color" : "#6496c8",
        "name" : "踈",
        "reading" : "ʃĭo˥˩",
        "SUID" : 265,
        "label" : "踈",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : -829.7703379586321,
        "y" : 1896.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "shared_name" : "良",
        "color" : "#6464c8",
        "name" : "良",
        "reading" : "lĭaŋ˩",
        "SUID" : 264,
        "label" : "良",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 394.6879235083204,
        "y" : 1678.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "shared_name" : "胥",
        "color" : "#6496c8",
        "name" : "胥",
        "reading" : "sĭo˥˩",
        "SUID" : 263,
        "label" : "胥",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1907.6879235083204,
        "y" : -47.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "shared_name" : "詩",
        "color" : "#6496c8",
        "name" : "詩",
        "reading" : "ɕĭə˥˩",
        "SUID" : 262,
        "label" : "詩",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -950.3120764916796,
        "y" : -2120.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "shared_name" : "牀",
        "color" : "#9664c8",
        "name" : "牀",
        "reading" : "dʒʰĭaŋ˩",
        "SUID" : 261,
        "label" : "牀",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1858.6879235083204,
        "y" : -2081.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "袪",
        "color" : "#c89664",
        "name" : "袪",
        "reading" : "kʰĭo˥˩",
        "SUID" : 260,
        "label" : "袪",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1406.6879235083204,
        "y" : -1370.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "shared_name" : "浮",
        "color" : "#c8c864",
        "name" : "浮",
        "reading" : "bʰĭəu˩",
        "SUID" : 259,
        "label" : "浮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1260.3121337890625,
        "y" : 140.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "shared_name" : "舒",
        "color" : "#6496c8",
        "name" : "舒",
        "reading" : "ɕĭo˥˩",
        "SUID" : 258,
        "label" : "舒",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -770.3120764916796,
        "y" : -2334.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "shared_name" : "尼",
        "color" : "#64c8c8",
        "name" : "尼",
        "reading" : "ɳi˩",
        "SUID" : 257,
        "label" : "尼",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -500.3120764916796,
        "y" : 1088.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "shared_name" : "創",
        "color" : "#9664c8",
        "name" : "創",
        "reading" : "ʧʰĭaŋ˩˥",
        "SUID" : 256,
        "label" : "創",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1582.918993112527,
        "y" : 1538.4780613713233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "shared_name" : "慈",
        "color" : "#c89664",
        "name" : "慈",
        "reading" : "dzʰĭə˩",
        "SUID" : 255,
        "label" : "慈",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1538.3120764916796,
        "y" : -1237.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "羌",
        "color" : "#c89664",
        "name" : "羌",
        "reading" : "kʰĭaŋ˥˩",
        "SUID" : 254,
        "label" : "羌",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1339.4814120393773,
        "y" : -1815.672120812748
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "shared_name" : "虞",
        "color" : "#64c8c8",
        "name" : "虞",
        "reading" : "ŋĭu˩",
        "SUID" : 253,
        "label" : "虞",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -558.3120764916796,
        "y" : -53.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "shared_name" : "臣",
        "color" : "#9664c8",
        "name" : "臣",
        "reading" : "ʑĭĕn˩",
        "SUID" : 252,
        "label" : "臣",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -576.3120764916796,
        "y" : -1521.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "shared_name" : "驅",
        "color" : "#c89664",
        "name" : "驅",
        "reading" : "kʰĭu˥˩",
        "SUID" : 251,
        "label" : "驅",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1313.6879235083204,
        "y" : -1225.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "shared_name" : "俱",
        "color" : "#c89664",
        "name" : "俱",
        "reading" : "kĭu˥˩",
        "SUID" : 250,
        "label" : "俱",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 2246.6879235083206,
        "y" : -1403.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "shared_name" : "鶵",
        "color" : "#9664c8",
        "name" : "鶵",
        "reading" : "dʒʰĭu˩",
        "SUID" : 249,
        "label" : "鶵",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 2137.6879235083206,
        "y" : -2026.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "采",
        "color" : "#9664c8",
        "name" : "采",
        "reading" : "tsʰɒi˥",
        "SUID" : 248,
        "label" : "采",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1708.6879235083209,
        "y" : 1685.9864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "shared_name" : "疑",
        "color" : "#64c8c8",
        "name" : "疑",
        "reading" : "ŋĭə˩",
        "SUID" : 247,
        "label" : "疑",
        "community" : 44,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -754.3120764916796,
        "y" : 283.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "shared_name" : "裴",
        "color" : "#c8c864",
        "name" : "裴",
        "reading" : "bʰĭwəi˩",
        "SUID" : 246,
        "label" : "裴",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1439.3121337890625,
        "y" : 149.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "安",
        "color" : "#96c864",
        "name" : "安",
        "reading" : "ʔɑn˥˩",
        "SUID" : 245,
        "label" : "安",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1241.614378418645,
        "y" : -836.0135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "shared_name" : "侯",
        "color" : "#96c864",
        "name" : "侯",
        "reading" : "ɣəu˩",
        "SUID" : 244,
        "label" : "侯",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1106.4738046157697,
        "y" : 1464.4864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "shared_name" : "傍",
        "color" : "#c8c864",
        "name" : "傍",
        "reading" : "bʰɑŋ˩",
        "SUID" : 243,
        "label" : "傍",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1604.3121337890625,
        "y" : 47.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "研",
        "color" : "#64c8c8",
        "name" : "研",
        "reading" : "ŋien˩˥",
        "SUID" : 242,
        "label" : "研",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : -976.3120764916796,
        "y" : 240.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "shared_name" : "補",
        "color" : "#c8c864",
        "name" : "補",
        "reading" : "pu˥",
        "SUID" : 241,
        "label" : "補",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1158.146184975273,
        "y" : 1462.009758252715
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "shared_name" : "佳",
        "color" : "#c89664",
        "name" : "佳",
        "reading" : "kai˥˩",
        "SUID" : 240,
        "label" : "佳",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 336.21304340598294,
        "y" : -43.04912757199645
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "shared_name" : "乖",
        "color" : "#c89664",
        "name" : "乖",
        "reading" : "kwɐi˥˩",
        "SUID" : 239,
        "label" : "乖",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 225.68595683176704,
        "y" : -88.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "shared_name" : "丈",
        "color" : "#9664c8",
        "name" : "丈",
        "reading" : "ɖʰĭaŋ˥",
        "SUID" : 238,
        "label" : "丈",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -318.69443988479657,
        "y" : -1271.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "shared_name" : "懷",
        "color" : "#96c864",
        "name" : "懷",
        "reading" : "ɣwɐi˩",
        "SUID" : 237,
        "label" : "懷",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1290.620894795121,
        "y" : 1570.803798330448
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "花",
        "color" : "#c89664",
        "name" : "花",
        "reading" : "xwa˥˩",
        "SUID" : 236,
        "label" : "花",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1074.943060674925,
        "y" : 1775.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "shared_name" : "夷",
        "color" : "#c86464",
        "name" : "夷",
        "reading" : "ji˩",
        "SUID" : 235,
        "label" : "夷",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -933.3120764916796,
        "y" : -802.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "shared_name" : "來",
        "color" : "#6464c8",
        "name" : "來",
        "reading" : "lɒi˩",
        "SUID" : 234,
        "label" : "來",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2279.6879235083206,
        "y" : 1775.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "毗",
        "color" : "#c8c864",
        "name" : "毗",
        "reading" : "bʰi˩",
        "SUID" : 233,
        "label" : "毗",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1671.3121337890625,
        "y" : 325.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "shared_name" : "宜",
        "color" : "#64c8c8",
        "name" : "宜",
        "reading" : "ŋĭe˩",
        "SUID" : 232,
        "label" : "宜",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -413.8120764916796,
        "y" : 165.9043273731445
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "shared_name" : "眉",
        "color" : "#64c896",
        "name" : "眉",
        "reading" : "mi˩",
        "SUID" : 231,
        "label" : "眉",
        "community" : 33,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1227.6879235083204,
        "y" : 492.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "shared_name" : "癡",
        "color" : "#9664c8",
        "name" : "癡",
        "reading" : "ţʰĭə˥˩",
        "SUID" : 230,
        "label" : "癡",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 673.6879235083204,
        "y" : -2170.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "shared_name" : "弃",
        "color" : "#c89664",
        "name" : "弃",
        "reading" : "kʰi˩˥",
        "SUID" : 229,
        "label" : "弃",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1108.6879235083204,
        "y" : -1389.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "shared_name" : "珍",
        "color" : "#9664c8",
        "name" : "珍",
        "reading" : "ţĭĕn˥˩",
        "SUID" : 228,
        "label" : "珍",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 427.4013221418775,
        "y" : -1465.5747524593794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "shared_name" : "云",
        "color" : "#96c864",
        "name" : "云",
        "reading" : "ĭuən˩",
        "SUID" : 227,
        "label" : "云",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -9.31207649167959,
        "y" : 1452.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "shared_name" : "反",
        "color" : "#c8c864",
        "name" : "反",
        "reading" : "pʰĭwɐn˥˩",
        "SUID" : 226,
        "label" : "反",
        "community" : 10,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1427.3121337890625,
        "y" : 674.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "shared_name" : "休",
        "color" : "#c89664",
        "name" : "休",
        "reading" : "xĭəu˥˩",
        "SUID" : 225,
        "label" : "休",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -487.5473497054454,
        "y" : 1603.6985077318468
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "shared_name" : "雲",
        "color" : "#96c864",
        "name" : "雲",
        "reading" : "ĭuən˩",
        "SUID" : 224,
        "label" : "雲",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 98.68792350832041,
        "y" : 1479.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "shared_name" : "兹",
        "color" : "#c89664",
        "name" : "兹",
        "reading" : "dzʰĭə˩",
        "SUID" : 223,
        "label" : "兹",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1440.3120764916796,
        "y" : -1182.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "shared_name" : "模",
        "color" : "#64c896",
        "name" : "模",
        "reading" : "mu˩",
        "SUID" : 222,
        "label" : "模",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1180.1143784186445,
        "y" : 50.351682073843676
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "shared_name" : "空",
        "color" : "#c89664",
        "name" : "空",
        "reading" : "kʰuŋ˩˥",
        "SUID" : 221,
        "label" : "空",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 89.68399015521368,
        "y" : 630.9779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "辝",
        "color" : "#6496c8",
        "name" : "辝",
        "reading" : "zĭə˩",
        "SUID" : 220,
        "label" : "辝",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1105.8856215813553,
        "y" : -420.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "shared_name" : "雛",
        "color" : "#9664c8",
        "name" : "雛",
        "reading" : "dʒʰĭu˩",
        "SUID" : 219,
        "label" : "雛",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 2141.6879235083206,
        "y" : -2157.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "姑",
        "color" : "#c89664",
        "name" : "姑",
        "reading" : "ku˥˩",
        "SUID" : 218,
        "label" : "姑",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 381.9948616746085,
        "y" : 67.4779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "shared_name" : "牽",
        "color" : "#c89664",
        "name" : "牽",
        "reading" : "kʰien˩˥",
        "SUID" : 217,
        "label" : "牽",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 38.18858051329357,
        "y" : 524.0466390555157
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "持",
        "color" : "#9664c8",
        "name" : "持",
        "reading" : "ɖʰĭə˩",
        "SUID" : 216,
        "label" : "持",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -318.69443988479657,
        "y" : -1484.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "shared_name" : "狂",
        "color" : "#c89664",
        "name" : "狂",
        "reading" : "gʰĭwaŋ˩",
        "SUID" : 215,
        "label" : "狂",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1663.6879235083204,
        "y" : -1938.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "除",
        "color" : "#9664c8",
        "name" : "除",
        "reading" : "ɖʰĭo˩",
        "SUID" : 214,
        "label" : "除",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : 1.6879235083204094,
        "y" : -1251.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "shared_name" : "馨",
        "color" : "#c89664",
        "name" : "馨",
        "reading" : "xieŋ˥˩",
        "SUID" : 213,
        "label" : "馨",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 937.6879235083204,
        "y" : 1964.0845434472835
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "shared_name" : "治",
        "color" : "#9664c8",
        "name" : "治",
        "reading" : "ɖʰĭə˩˥",
        "SUID" : 212,
        "label" : "治",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -195.9297130985624,
        "y" : -1484.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "shared_name" : "苻",
        "color" : "#c8c864",
        "name" : "苻",
        "reading" : "bʰĭu˩",
        "SUID" : 211,
        "label" : "苻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1218.3121337890625,
        "y" : 271.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "陂",
        "color" : "#c8c864",
        "name" : "陂",
        "reading" : "pĭe˩˥",
        "SUID" : 210,
        "label" : "陂",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1097.3121337890625,
        "y" : 407.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "shared_name" : "平",
        "color" : "#c8c864",
        "name" : "平",
        "reading" : "bʰĭɛn˩",
        "SUID" : 209,
        "label" : "平",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1507.3121337890625,
        "y" : 195.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "親",
        "color" : "#9664c8",
        "name" : "親",
        "reading" : "tsʰĭĕn˩˥",
        "SUID" : 208,
        "label" : "親",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 2124.761468597996,
        "y" : 1438.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "shared_name" : "枯",
        "color" : "#c89664",
        "name" : "枯",
        "reading" : "kʰu˥˩",
        "SUID" : 207,
        "label" : "枯",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 67.68595683176704,
        "y" : 903.9779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "捕",
        "color" : "#c8c864",
        "name" : "捕",
        "reading" : "bʰu˩˥",
        "SUID" : 206,
        "label" : "捕",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1566.3121337890625,
        "y" : -35.8309440612793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "shared_name" : "砂",
        "color" : "#6496c8",
        "name" : "砂",
        "reading" : "ʃa˥˩",
        "SUID" : 205,
        "label" : "砂",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -816.0569393250751,
        "y" : 1744.4252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "悉",
        "color" : "#6496c8",
        "name" : "悉",
        "reading" : "sĭĕt",
        "SUID" : 204,
        "label" : "悉",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1620.6879235083204,
        "y" : 263.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "shared_name" : "𩛠",
        "color" : "#9664c8",
        "name" : "𩛠",
        "reading" : "tsĭuɑ˥˩",
        "SUID" : 203,
        "label" : "𩛠",
        "community" : 23,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1308.3120764916796,
        "y" : -1365.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "又",
        "color" : "#96c864",
        "name" : "又",
        "reading" : "ĭəu˩˥",
        "SUID" : 202,
        "label" : "又",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -134.3120764916796,
        "y" : 1633.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "shared_name" : "沙",
        "color" : "#6496c8",
        "name" : "沙",
        "reading" : "ʃa˩˥",
        "SUID" : 201,
        "label" : "沙",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -953.3120764916796,
        "y" : 1699.8283500660418
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "妃",
        "color" : "#c8c864",
        "name" : "妃",
        "reading" : "pʰĭwəi˥˩",
        "SUID" : 200,
        "label" : "妃",
        "community" : 55,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1533.3121337890625,
        "y" : 917.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "shared_name" : "分",
        "color" : "#c8c864",
        "name" : "分",
        "reading" : "pĭuən˥˩",
        "SUID" : 199,
        "label" : "分",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1401.3121337890625,
        "y" : 480.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "紆",
        "color" : "#96c864",
        "name" : "紆",
        "reading" : "ʔĭu˥˩",
        "SUID" : 198,
        "label" : "紆",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1059.6879235083204,
        "y" : -226.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "shared_name" : "各",
        "color" : "#c89664",
        "name" : "各",
        "reading" : "kɑk",
        "SUID" : 197,
        "label" : "各",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 115.15887025755114,
        "y" : 178.0050455764358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "麁",
        "color" : "#9664c8",
        "name" : "麁",
        "reading" : "tsʰu˥˩",
        "SUID" : 196,
        "label" : "麁",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 2038.7614685979963,
        "y" : 1638.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "shared_name" : "兵",
        "color" : "#c8c864",
        "name" : "兵",
        "reading" : "pĭɐŋ˥˩",
        "SUID" : 195,
        "label" : "兵",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1224.3121337890625,
        "y" : 510.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "何",
        "color" : "#96c864",
        "name" : "何",
        "reading" : "ɣɑ˥",
        "SUID" : 194,
        "label" : "何",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1197.5473497054454,
        "y" : 1775.2216994586793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "shared_name" : "拏",
        "color" : "#64c8c8",
        "name" : "拏",
        "reading" : "ɳa˩",
        "SUID" : 193,
        "label" : "拏",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -634.3120764916796,
        "y" : 1143.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "烟",
        "color" : "#96c864",
        "name" : "烟",
        "reading" : "ʔĭĕn˥˩",
        "SUID" : 192,
        "label" : "烟",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1512.6879235083204,
        "y" : -744.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "shared_name" : "殖",
        "color" : "#9664c8",
        "name" : "殖",
        "reading" : "ʑĭək",
        "SUID" : 191,
        "label" : "殖",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -699.3120764916796,
        "y" : -982.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "天",
        "color" : "#9664c8",
        "name" : "天",
        "reading" : "tʰien˥˩",
        "SUID" : 190,
        "label" : "天",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -732.3856215813553,
        "y" : -1140.0135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "shared_name" : "丕",
        "color" : "#c8c864",
        "name" : "丕",
        "reading" : "pʰi˥˩",
        "SUID" : 189,
        "label" : "丕",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1551.8856201171875,
        "y" : 1277.4864501953125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "欽",
        "color" : "#c89664",
        "name" : "欽",
        "reading" : "kʰĭĕm˥˩",
        "SUID" : 188,
        "label" : "欽",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1339.4814120393773,
        "y" : -1548.989770868495
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "shared_name" : "賞",
        "color" : "#6496c8",
        "name" : "賞",
        "reading" : "ɕĭaŋ˥",
        "SUID" : 187,
        "label" : "賞",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -886.3120764916796,
        "y" : -1973.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "謨",
        "color" : "#64c896",
        "name" : "謨",
        "reading" : "mu˩",
        "SUID" : 186,
        "label" : "謨",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1180.114378418645,
        "y" : 262.9864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "占",
        "color" : "#9664c8",
        "name" : "占",
        "reading" : "tɕĭɛm˥˩",
        "SUID" : 185,
        "label" : "占",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1150.3120764916796,
        "y" : -1591.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "衣",
        "color" : "#96c864",
        "name" : "衣",
        "reading" : "ʔĭəi˩˥",
        "SUID" : 184,
        "label" : "衣",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1687.5740545618721,
        "y" : -372.33094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "謙",
        "color" : "#c89664",
        "name" : "謙",
        "reading" : "kʰiem˥˩",
        "SUID" : 183,
        "label" : "謙",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -170.3120764916796,
        "y" : 571.6355534229601
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "青",
        "color" : "",
        "name" : "青",
        "reading" : "",
        "SUID" : 182,
        "label" : "青",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -740.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "shared_name" : "兼",
        "color" : "#c89664",
        "name" : "兼",
        "reading" : "kiem˩˥",
        "SUID" : 181,
        "label" : "兼",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 69.37705198892559,
        "y" : 67.4779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "shared_name" : "明",
        "color" : "#64c896",
        "name" : "明",
        "reading" : "mĭɐŋ˩",
        "SUID" : 180,
        "label" : "明",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1121.9013221418775,
        "y" : 834.4252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "shared_name" : "峯",
        "color" : "#c8c864",
        "name" : "峯",
        "reading" : "pʰĭwoŋ˥˩",
        "SUID" : 179,
        "label" : "峯",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1551.8856201171875,
        "y" : 1064.8516845703125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "shared_name" : "徧",
        "color" : "#c8c864",
        "name" : "徧",
        "reading" : "pien˩˥",
        "SUID" : 178,
        "label" : "徧",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1523.3121337890625,
        "y" : 424.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "shared_name" : "頻",
        "color" : "#c8c864",
        "name" : "頻",
        "reading" : "bʰĭĕn˩",
        "SUID" : 177,
        "label" : "頻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1520.3121337890625,
        "y" : 240.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "shared_name" : "馮",
        "color" : "#c8c864",
        "name" : "馮",
        "reading" : "bʰĭuŋ˩",
        "SUID" : 176,
        "label" : "馮",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1495.3121337890625,
        "y" : 342.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "shared_name" : "干",
        "color" : "#c89664",
        "name" : "干",
        "reading" : "kɑn˥˩",
        "SUID" : 175,
        "label" : "干",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 115.15887025755069,
        "y" : -43.049127571995996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "shared_name" : "乎",
        "color" : "#96c864",
        "name" : "乎",
        "reading" : "ɣu˩",
        "SUID" : 174,
        "label" : "乎",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1290.620894795121,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "shared_name" : "柱",
        "color" : "#9664c8",
        "name" : "柱",
        "reading" : "ɖʰĭu˥",
        "SUID" : 173,
        "label" : "柱",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : 17.68792350832041,
        "y" : -1481.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "shared_name" : "區",
        "color" : "#96c864",
        "name" : "區",
        "reading" : "kʰĭu˥˩",
        "SUID" : 172,
        "label" : "區",
        "community" : 50,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1390.6879235083204,
        "y" : -1171.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "shared_name" : "穠",
        "color" : "#64c8c8",
        "name" : "穠",
        "reading" : "ɳĭwoŋ˩",
        "SUID" : 171,
        "label" : "穠",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -638.3120764916796,
        "y" : 961.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "shared_name" : "支",
        "color" : "#9664c8",
        "name" : "支",
        "reading" : "tɕĭe˥˩",
        "SUID" : 170,
        "label" : "支",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1121.3120764916796,
        "y" : -1380.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "shared_name" : "詭",
        "color" : "#c89664",
        "name" : "詭",
        "reading" : "kĭwe˥",
        "SUID" : 169,
        "label" : "詭",
        "community" : 11,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 629.685956831767,
        "y" : -48.022040997780095
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "shared_name" : "披",
        "color" : "#c8c864",
        "name" : "披",
        "reading" : "pʰĭe˥˩",
        "SUID" : 168,
        "label" : "披",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1235.3121337890625,
        "y" : 1068.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "shared_name" : "奇",
        "color" : "#c89664",
        "name" : "奇",
        "reading" : "kĭe˥˩",
        "SUID" : 167,
        "label" : "奇",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 2039.4526502945548,
        "y" : -1253.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "shared_name" : "馳",
        "color" : "#9664c8",
        "name" : "馳",
        "reading" : "ɖʰĭe˩",
        "SUID" : 166,
        "label" : "馳",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -134.54734970544519,
        "y" : -1377.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "shared_name" : "窺",
        "color" : "#c89664",
        "name" : "窺",
        "reading" : "kʰĭwe˥˩",
        "SUID" : 165,
        "label" : "窺",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1506.685956831767,
        "y" : -1682.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "shared_name" : "危",
        "color" : "#64c8c8",
        "name" : "危",
        "reading" : "ŋĭwe˩",
        "SUID" : 164,
        "label" : "危",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -536.5768032779138,
        "y" : 288.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "shared_name" : "規",
        "color" : "#c89664",
        "name" : "規",
        "reading" : "kĭwe˥˩",
        "SUID" : 163,
        "label" : "規",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1978.0702869014374,
        "y" : -1360.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "shared_name" : "爭",
        "color" : "#9664c8",
        "name" : "爭",
        "reading" : "ʧæŋ˥˩",
        "SUID" : 162,
        "label" : "爭",
        "community" : 42,
        "selected" : false,
        "group" : "tsr "
      },
      "position" : {
        "x" : -1833.3120764916796,
        "y" : -1410.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "shared_name" : "卿",
        "color" : "#c89664",
        "name" : "卿",
        "reading" : "kʰĭɐŋ˥˩",
        "SUID" : 161,
        "label" : "卿",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1246.6898901848738,
        "y" : -1741.6733514198813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "shared_name" : "脂",
        "color" : "#9664c8",
        "name" : "脂",
        "reading" : "tɕi˥˩",
        "SUID" : 160,
        "label" : "脂",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1167.3120764916796,
        "y" : -1940.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "shared_name" : "雖",
        "color" : "#6496c8",
        "name" : "雖",
        "reading" : "swi˥˩",
        "SUID" : 159,
        "label" : "雖",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1779.423196722086,
        "y" : 271.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "shared_name" : "詰",
        "color" : "#c89664",
        "name" : "詰",
        "reading" : "kʰĭĕt",
        "SUID" : 158,
        "label" : "詰",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1181.6879235083204,
        "y" : -1438.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "shared_name" : "几",
        "color" : "#c89664",
        "name" : "几",
        "reading" : "ki˥",
        "SUID" : 157,
        "label" : "几",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1855.3055601152034,
        "y" : -1360.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "shared_name" : "資",
        "color" : "#c89664",
        "name" : "資",
        "reading" : "tsi˥˩",
        "SUID" : 156,
        "label" : "資",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1248.3120764916796,
        "y" : -1091.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "shared_name" : "秦",
        "color" : "#c89664",
        "name" : "秦",
        "reading" : "dzʰĭĕn˩",
        "SUID" : 155,
        "label" : "秦",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1522.3120764916796,
        "y" : -1040.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "shared_name" : "追",
        "color" : "#9664c8",
        "name" : "追",
        "reading" : "ţwi˥˩",
        "SUID" : 154,
        "label" : "追",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 427.4013221418775,
        "y" : -1699.0871392218637
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "shared_name" : "矢",
        "color" : "#6496c8",
        "name" : "矢",
        "reading" : "ɕi˥",
        "SUID" : 153,
        "label" : "矢",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -672.5768032779138,
        "y" : -2066.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "shared_name" : "釋",
        "color" : "#6496c8",
        "name" : "釋",
        "reading" : "ɕĭɛk",
        "SUID" : 152,
        "label" : "釋",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -291.3120764916796,
        "y" : -2366.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "shared_name" : "仍",
        "color" : "#64c8c8",
        "name" : "仍",
        "reading" : "nʑĭəŋ˩",
        "SUID" : 151,
        "label" : "仍",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : -816.3120764916796,
        "y" : 845.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "shared_name" : "近",
        "color" : "#c89664",
        "name" : "近",
        "reading" : "gʰĭən˥",
        "SUID" : 150,
        "label" : "近",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1670.6879235083204,
        "y" : -1737.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "shared_name" : "商",
        "color" : "#6496c8",
        "name" : "商",
        "reading" : "ɕĭaŋ˥˩",
        "SUID" : 149,
        "label" : "商",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -549.8120764916796,
        "y" : -2189.095672626856
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "shared_name" : "依",
        "color" : "#96c864",
        "name" : "依",
        "reading" : "ʔĭəi˥˩",
        "SUID" : 148,
        "label" : "依",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1650.2586239958143,
        "y" : -257.4858595048595
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "shared_name" : "遟",
        "color" : "#9664c8",
        "name" : "遟",
        "reading" : "ɖʰi˩˥",
        "SUID" : 147,
        "label" : "遟",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : 22.68792350832041,
        "y" : -1350.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "shared_name" : "瘡",
        "color" : "#9664c8",
        "name" : "瘡",
        "reading" : "ʧʰĭaŋ˥˩",
        "SUID" : 146,
        "label" : "瘡",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1486.4054458207743,
        "y" : 1614.3484332701178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "shared_name" : "抽",
        "color" : "#9664c8",
        "name" : "抽",
        "reading" : "ţʰĭəu˥˩",
        "SUID" : 145,
        "label" : "抽",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 867.6879235083204,
        "y" : -2067.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "shared_name" : "芻",
        "color" : "#9664c8",
        "name" : "芻",
        "reading" : "ʧʰĭu˥˩",
        "SUID" : 144,
        "label" : "芻",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : -1908.3120764916796,
        "y" : 2163.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "shared_name" : "洛",
        "color" : "#6464c8",
        "name" : "洛",
        "reading" : "lɑk",
        "SUID" : 143,
        "label" : "洛",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 2495.6879235083206,
        "y" : 1787.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "shared_name" : "湯",
        "color" : "#9664c8",
        "name" : "湯",
        "reading" : "ɕĭaŋ˥˩",
        "SUID" : 142,
        "label" : "湯",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -591.3120764916796,
        "y" : -1636.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "shared_name" : "征",
        "color" : "#9664c8",
        "name" : "征",
        "reading" : "tɕĭɛŋ˥˩",
        "SUID" : 141,
        "label" : "征",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -1365.3120764916796,
        "y" : -1592.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "shared_name" : "嘗",
        "color" : "#9664c8",
        "name" : "嘗",
        "reading" : "ʑĭaŋ˩",
        "SUID" : 140,
        "label" : "嘗",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -867.8120764916796,
        "y" : -1516.5662190543871
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "shared_name" : "黃",
        "color" : "#96c864",
        "name" : "黃",
        "reading" : "ɣuɑŋ˩",
        "SUID" : 139,
        "label" : "黃",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : -1320.3120764916796,
        "y" : 1897.9864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "shared_name" : "麤",
        "color" : "#9664c8",
        "name" : "麤",
        "reading" : "tsʰu˥˩",
        "SUID" : 138,
        "label" : "麤",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1708.6879235083204,
        "y" : 1473.3516820738437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "shared_name" : "犲",
        "color" : "",
        "name" : "犲",
        "reading" : "",
        "SUID" : 137,
        "label" : "犲",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -619.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "shared_name" : "海",
        "color" : "#c89664",
        "name" : "海",
        "reading" : "xɒi˥",
        "SUID" : 136,
        "label" : "海",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1074.943060674925,
        "y" : 2008.6814409218628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "shared_name" : "試",
        "color" : "#6496c8",
        "name" : "試",
        "reading" : "ɕĭə˩˥",
        "SUID" : 135,
        "label" : "試",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -549.8120764916796,
        "y" : -1943.5662190543874
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "shared_name" : "辭",
        "color" : "#6496c8",
        "name" : "辭",
        "reading" : "zĭə˩",
        "SUID" : 134,
        "label" : "辭",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1105.8856215813553,
        "y" : -633.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "shared_name" : "吾",
        "color" : "#64c8c8",
        "name" : "吾",
        "reading" : "ŋa˩",
        "SUID" : 133,
        "label" : "吾",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : -894.3120764916796,
        "y" : 297.16905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "shared_name" : "臼",
        "color" : "#c89664",
        "name" : "臼",
        "reading" : "gʰĭəu˥",
        "SUID" : 132,
        "label" : "臼",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1842.114378418645,
        "y" : -1559.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "shared_name" : "通",
        "color" : "#9664c8",
        "name" : "通",
        "reading" : "tʰuŋ˥˩",
        "SUID" : 131,
        "label" : "通",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -732.3856215813553,
        "y" : -1352.6483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "shared_name" : "生",
        "color" : "#6496c8",
        "name" : "生",
        "reading" : "ʃɐŋ˩˥",
        "SUID" : 130,
        "label" : "生",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : -731.2285994255847,
        "y" : 1627.6690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "shared_name" : "晡",
        "color" : "#c8c864",
        "name" : "晡",
        "reading" : "pu˥˩",
        "SUID" : 129,
        "label" : "晡",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1295.4013221418775,
        "y" : 1417.4128607781363
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "shared_name" : "堂",
        "color" : "#9664c8",
        "name" : "堂",
        "reading" : "dʰɑŋ˩",
        "SUID" : 128,
        "label" : "堂",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -332.3101098151262,
        "y" : -924.1733514198813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "shared_name" : "吉",
        "color" : "#c89664",
        "name" : "吉",
        "reading" : "kĭĕt",
        "SUID" : 127,
        "label" : "吉",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1978.0702869014374,
        "y" : -1147.5135737550868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "shared_name" : "婢",
        "color" : "#c8c864",
        "name" : "婢",
        "reading" : "bʰĭe˥",
        "SUID" : 126,
        "label" : "婢",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1686.3121337890625,
        "y" : 451.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "shared_name" : "連",
        "color" : "#6464c8",
        "name" : "連",
        "reading" : "lĭɛn˩",
        "SUID" : 125,
        "label" : "連",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 632.1143784186445,
        "y" : 1583.8516820738437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "shared_name" : "寔",
        "color" : "#9664c8",
        "name" : "寔",
        "reading" : "ʑĭək",
        "SUID" : 124,
        "label" : "寔",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -795.3120764916796,
        "y" : -980.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "shared_name" : "唐",
        "color" : "#9664c8",
        "name" : "唐",
        "reading" : "dʰɑŋ˩",
        "SUID" : 123,
        "label" : "唐",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -239.51858796062265,
        "y" : -998.1721208127481
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "shared_name" : "摸",
        "color" : "#64c896",
        "name" : "摸",
        "reading" : "mu˩",
        "SUID" : 122,
        "label" : "摸",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1316.6879235083204,
        "y" : -88.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "shared_name" : "司",
        "color" : "#6496c8",
        "name" : "司",
        "reading" : "sĭə˥˩",
        "SUID" : 121,
        "label" : "司",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 1902.1879235083204,
        "y" : 394.43378094561285
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "shared_name" : "始",
        "color" : "#6496c8",
        "name" : "始",
        "reading" : "ɕĭə˥",
        "SUID" : 120,
        "label" : "始",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -993.3120764916796,
        "y" : -2215.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "shared_name" : "遷",
        "color" : "#9664c8",
        "name" : "遷",
        "reading" : "tsʰĭɛn˥˩",
        "SUID" : 119,
        "label" : "遷",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 2053.761468597996,
        "y" : 1358.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "shared_name" : "巫",
        "color" : "#64c896",
        "name" : "巫",
        "reading" : "mĭu˩",
        "SUID" : 118,
        "label" : "巫",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1335.6879235083204,
        "y" : 848.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "shared_name" : "猪",
        "color" : "#9664c8",
        "name" : "猪",
        "reading" : "ţĭo˥˩",
        "SUID" : 117,
        "label" : "猪",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 290.14618497527294,
        "y" : -1510.1716499339582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "shared_name" : "比",
        "color" : "#c8c864",
        "name" : "比",
        "reading" : "bʰi˩",
        "SUID" : 116,
        "label" : "比",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1710.3121337890625,
        "y" : 255.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "shared_name" : "鷖",
        "color" : "#96c864",
        "name" : "鷖",
        "reading" : "ʔiei˥˩",
        "SUID" : 115,
        "label" : "鷖",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1241.614378418645,
        "y" : -1048.6483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "shared_name" : "𢌿",
        "color" : "#c8c864",
        "name" : "𢌿",
        "reading" : "pi˩˥",
        "SUID" : 114,
        "label" : "𢌿",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1908.3121337890625,
        "y" : 230.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "shared_name" : "實",
        "color" : "#6496c8",
        "name" : "實",
        "reading" : "dʑʰĭĕt",
        "SUID" : 113,
        "label" : "實",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -536.7209753830787,
        "y" : -485.8297899322811
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "shared_name" : "父",
        "color" : "#c8c864",
        "name" : "父",
        "reading" : "pĭu˥",
        "SUID" : 112,
        "label" : "父",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1318.3121337890625,
        "y" : 375.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "shared_name" : "台",
        "color" : "#9664c8",
        "name" : "台",
        "reading" : "jĭə˩",
        "SUID" : 111,
        "label" : "台",
        "community" : 31,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -639.3120764916796,
        "y" : -881.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "shared_name" : "伊",
        "color" : "#96c864",
        "name" : "伊",
        "reading" : "ʔi˥˩",
        "SUID" : 110,
        "label" : "伊",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1869.6879235083204,
        "y" : -382.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "shared_name" : "冝",
        "color" : "",
        "name" : "冝",
        "reading" : "",
        "SUID" : 109,
        "label" : "冝",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -498.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "紀",
        "color" : "#c89664",
        "name" : "紀",
        "reading" : "kĭə˥",
        "SUID" : 108,
        "label" : "紀",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1793.923196722086,
        "y" : -1253.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "漸",
        "color" : "#c89664",
        "name" : "漸",
        "reading" : "tsĭɛm˥˩",
        "SUID" : 107,
        "label" : "漸",
        "community" : 34,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1435.3120764916796,
        "y" : -1274.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "shared_name" : "佇",
        "color" : "#9664c8",
        "name" : "佇",
        "reading" : "ɖʰĭo˥",
        "SUID" : 106,
        "label" : "佇",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -380.07680327791377,
        "y" : -1377.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "玉",
        "color" : "#64c8c8",
        "name" : "玉",
        "reading" : "ŋĭwok",
        "SUID" : 105,
        "label" : "玉",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : -291.0473497054452,
        "y" : 288.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "shared_name" : "格",
        "color" : "#c89664",
        "name" : "格",
        "reading" : "kɐk",
        "SUID" : 104,
        "label" : "格",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 225.68595683176704,
        "y" : 223.78686384506136
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "音",
        "color" : "#96c864",
        "name" : "音",
        "reading" : "ʔĭĕm˥˩",
        "SUID" : 103,
        "label" : "音",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1431.810288547602,
        "y" : -558.1541989728009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "賔",
        "color" : "#c8c864",
        "name" : "賔",
        "reading" : "pĭĕn˥˩",
        "SUID" : 102,
        "label" : "賔",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1887.3121337890625,
        "y" : 346.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "shared_name" : "班",
        "color" : "#c8c864",
        "name" : "班",
        "reading" : "pan˥˩",
        "SUID" : 101,
        "label" : "班",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 937.6879235083204,
        "y" : 1543.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "殊",
        "color" : "#9664c8",
        "name" : "殊",
        "reading" : "ʑĭu˩",
        "SUID" : 100,
        "label" : "殊",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -990.5768032779138,
        "y" : -1639.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "冬",
        "color" : "#9664c8",
        "name" : "冬",
        "reading" : "tuoŋ˥˩",
        "SUID" : 99,
        "label" : "冬",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 828.6879235083204,
        "y" : -1746.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "shared_name" : "內",
        "color" : "",
        "name" : "內",
        "reading" : "",
        "SUID" : 98,
        "label" : "內",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -377.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "shared_name" : "封",
        "color" : "#c8c864",
        "name" : "封",
        "reading" : "pĭwoŋ˥˩",
        "SUID" : 97,
        "label" : "封",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1497.3121337890625,
        "y" : 503.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "shared_name" : "譬",
        "color" : "#c8c864",
        "name" : "譬",
        "reading" : "pʰĭe˩˥",
        "SUID" : 96,
        "label" : "譬",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1141.3121337890625,
        "y" : 970.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "shared_name" : "美",
        "color" : "#64c896",
        "name" : "美",
        "reading" : "mi˥",
        "SUID" : 95,
        "label" : "美",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 750.6879235083204,
        "y" : 651.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "鄙",
        "color" : "#c8c864",
        "name" : "鄙",
        "reading" : "pi˥",
        "SUID" : 94,
        "label" : "鄙",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1344.3121337890625,
        "y" : 521.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "shared_name" : "徵",
        "color" : "#9664c8",
        "name" : "徵",
        "reading" : "ţĭə˥",
        "SUID" : 93,
        "label" : "徵",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 512.2296620413679,
        "y" : -1582.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "羲",
        "color" : "#c89664",
        "name" : "羲",
        "reading" : "xĭe˥˩",
        "SUID" : 92,
        "label" : "羲",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -487.5473497054454,
        "y" : 1358.169054159378
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "辛",
        "color" : "#6496c8",
        "name" : "辛",
        "reading" : "sĭĕn˥˩",
        "SUID" : 91,
        "label" : "辛",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 2024.9526502945548,
        "y" : 271.66905415937845
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "shared_name" : "崱",
        "color" : "#9664c8",
        "name" : "崱",
        "reading" : "dʒʰĭək",
        "SUID" : 90,
        "label" : "崱",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : 1980.6879235083204,
        "y" : -2239.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "衢",
        "color" : "#c89664",
        "name" : "衢",
        "reading" : "gʰĭu˩",
        "SUID" : 89,
        "label" : "衢",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1842.1143784186445,
        "y" : -1772.1483179261563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "shared_name" : "望",
        "color" : "#64c896",
        "name" : "望",
        "reading" : "mĭwaŋ˩",
        "SUID" : 88,
        "label" : "望",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1278.6879235083204,
        "y" : 936.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "shared_name" : "拂",
        "color" : "#c8c864",
        "name" : "拂",
        "reading" : "pʰĭuət",
        "SUID" : 87,
        "label" : "拂",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1367.738525390625,
        "y" : 1171.1690673828125
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "shared_name" : "陀",
        "color" : "#9664c8",
        "name" : "陀",
        "reading" : "dʰɑ˩",
        "SUID" : 86,
        "label" : "陀",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -123.80945281015306,
        "y" : -971.7622657873255
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "shared_name" : "鄒",
        "color" : "#9664c8",
        "name" : "鄒",
        "reading" : "ʧĭəu˥˩",
        "SUID" : 85,
        "label" : "鄒",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -1760.3120764916796,
        "y" : -1620.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "shared_name" : "百",
        "color" : "#c8c864",
        "name" : "百",
        "reading" : "pɐk",
        "SUID" : 84,
        "label" : "百",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : 1295.4013221418775,
        "y" : 1650.9252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "shared_name" : "查",
        "color" : "",
        "name" : "查",
        "reading" : "",
        "SUID" : 83,
        "label" : "查",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -256.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "shared_name" : "練",
        "color" : "#6464c8",
        "name" : "練",
        "reading" : "lien˩˥",
        "SUID" : 82,
        "label" : "練",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 424.6879235083204,
        "y" : 1385.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "shared_name" : "情",
        "color" : "#c89664",
        "name" : "情",
        "reading" : "dzʰĭɛŋ˩",
        "SUID" : 81,
        "label" : "情",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -1683.3120764916796,
        "y" : -1114.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "shared_name" : "傾",
        "color" : "#c89664",
        "name" : "傾",
        "reading" : "kʰĭwɛŋ˥˩",
        "SUID" : 80,
        "label" : "傾",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1246.6898901848742,
        "y" : -1622.9885402613618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "shared_name" : "厠",
        "color" : "",
        "name" : "厠",
        "reading" : "",
        "SUID" : 79,
        "label" : "厠",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -135.3120764916796,
        "y" : 2244.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "shared_name" : "寺",
        "color" : "#6496c8",
        "name" : "寺",
        "reading" : "zĭə˩˥",
        "SUID" : 78,
        "label" : "寺",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -948.3120764916796,
        "y" : -169.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "離",
        "color" : "#6464c8",
        "name" : "離",
        "reading" : "lĭe˩",
        "SUID" : 77,
        "label" : "離",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 506.6879235083204,
        "y" : 1535.1690541593784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "shared_name" : "憂",
        "color" : "#96c864",
        "name" : "憂",
        "reading" : "ʔĭəu˥˩",
        "SUID" : 76,
        "label" : "憂",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1552.5655584690383,
        "y" : -558.1541989728009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "具",
        "color" : "#c89664",
        "name" : "具",
        "reading" : "gʰĭu˩˥",
        "SUID" : 75,
        "label" : "具",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 2026.2614685979959,
        "y" : -1665.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "shared_name" : "慕",
        "color" : "#64c896",
        "name" : "慕",
        "reading" : "mu˩˥",
        "SUID" : 74,
        "label" : "慕",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1404.6879235083204,
        "y" : -53.83094584062155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "呵",
        "color" : "#c89664",
        "name" : "呵",
        "reading" : "xɑ˥˩",
        "SUID" : 73,
        "label" : "呵",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : 1317.2296620413679,
        "y" : 1935.4252475406206
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "shared_name" : "場",
        "color" : "#9664c8",
        "name" : "場",
        "reading" : "ɖʰĭaŋ˩",
        "SUID" : 72,
        "label" : "場",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -63.31207649167959,
        "y" : -1156.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "弼",
        "color" : "#c8c864",
        "name" : "弼",
        "reading" : "bʰĭĕt",
        "SUID" : 71,
        "label" : "弼",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1652.3121337890625,
        "y" : 196.16905212402344
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "70",
        "shared_name" : "楷",
        "color" : "#c89664",
        "name" : "楷",
        "reading" : "kɐi˥˩",
        "SUID" : 70,
        "label" : "楷",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 80.68595683176704,
        "y" : 362.9779590022199
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "69",
        "shared_name" : "簪",
        "color" : "#9664c8",
        "name" : "簪",
        "reading" : "ʧĭĕm˥˩",
        "SUID" : 69,
        "label" : "簪",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -1673.3120764916796,
        "y" : -1480.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "68",
        "shared_name" : "營",
        "color" : "#c86464",
        "name" : "營",
        "reading" : "jĭwɛŋ˩",
        "SUID" : 68,
        "label" : "營",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -950.3120764916796,
        "y" : -1019.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "67",
        "shared_name" : "前",
        "color" : "#c89664",
        "name" : "前",
        "reading" : "dzʰien˩",
        "SUID" : 67,
        "label" : "前",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : 1805.6879235083209,
        "y" : 2017.4864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "66",
        "shared_name" : "林",
        "color" : "#6464c8",
        "name" : "林",
        "reading" : "lĭĕm˩",
        "SUID" : 66,
        "label" : "林",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : 632.114378418645,
        "y" : 1796.4864262449132
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "65",
        "shared_name" : "恥",
        "color" : "#9664c8",
        "name" : "恥",
        "reading" : "ţʰĭə˥",
        "SUID" : 65,
        "label" : "恥",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 873.6879235083204,
        "y" : -2297.8309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "64",
        "shared_name" : "乗",
        "color" : "#6496c8",
        "name" : "乗",
        "reading" : "dʑʰĭəŋ˩",
        "SUID" : 64,
        "label" : "乗",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -517.6132995809519,
        "y" : -601.3066132581798
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "63",
        "shared_name" : "愛",
        "color" : "#96c864",
        "name" : "愛",
        "reading" : "ʔɒi˩˥",
        "SUID" : 63,
        "label" : "愛",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1425.7614685979963,
        "y" : -942.3309458406216
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "62",
        "shared_name" : "筠",
        "color" : "#96c864",
        "name" : "筠",
        "reading" : "ĭwĕn˩",
        "SUID" : 62,
        "label" : "筠",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : 49.68792350832041,
        "y" : 1818.1690541593784
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "1114",
        "source" : "547",
        "target" : "420",
        "shared_name" : "徒 (interacts with) 同",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 同",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1113",
        "source" : "547",
        "target" : "86",
        "shared_name" : "徒 (interacts with) 陀",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 陀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1112",
        "source" : "547",
        "target" : "280",
        "shared_name" : "徒 (interacts with) 池",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 池",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1111",
        "source" : "547",
        "target" : "123",
        "shared_name" : "徒 (interacts with) 唐",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 唐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1110",
        "source" : "547",
        "target" : "128",
        "shared_name" : "徒 (interacts with) 堂",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 堂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1110,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1109",
        "source" : "547",
        "target" : "409",
        "shared_name" : "徒 (interacts with) 杜",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 杜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1109,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1108",
        "source" : "547",
        "target" : "405",
        "shared_name" : "徒 (interacts with) 土",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 土",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1107",
        "source" : "547",
        "target" : "364",
        "shared_name" : "徒 (interacts with) 度",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 度",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1106",
        "source" : "547",
        "target" : "315",
        "shared_name" : "徒 (interacts with) 特",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 特",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1105",
        "source" : "546",
        "target" : "317",
        "shared_name" : "陟 (interacts with) 中",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 中",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1104",
        "source" : "546",
        "target" : "299",
        "shared_name" : "陟 (interacts with) 知",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 知",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1103",
        "source" : "546",
        "target" : "154",
        "shared_name" : "陟 (interacts with) 追",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 追",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1103,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1102",
        "source" : "546",
        "target" : "268",
        "shared_name" : "陟 (interacts with) 豬",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 豬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1101",
        "source" : "546",
        "target" : "117",
        "shared_name" : "陟 (interacts with) 猪",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 猪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1100",
        "source" : "546",
        "target" : "228",
        "shared_name" : "陟 (interacts with) 珍",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 珍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1099",
        "source" : "546",
        "target" : "344",
        "shared_name" : "陟 (interacts with) 張",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 張",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1098",
        "source" : "546",
        "target" : "93",
        "shared_name" : "陟 (interacts with) 徵",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 徵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1097",
        "source" : "545",
        "target" : "166",
        "shared_name" : "直 (interacts with) 馳",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 馳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1097,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1096",
        "source" : "545",
        "target" : "280",
        "shared_name" : "直 (interacts with) 池",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 池",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1096,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1095",
        "source" : "545",
        "target" : "147",
        "shared_name" : "直 (interacts with) 遟",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 遟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1094",
        "source" : "545",
        "target" : "212",
        "shared_name" : "直 (interacts with) 治",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 治",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1093",
        "source" : "545",
        "target" : "216",
        "shared_name" : "直 (interacts with) 持",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 持",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1092",
        "source" : "545",
        "target" : "214",
        "shared_name" : "直 (interacts with) 除",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 除",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1092,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1091",
        "source" : "545",
        "target" : "72",
        "shared_name" : "直 (interacts with) 場",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 場",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1090",
        "source" : "545",
        "target" : "106",
        "shared_name" : "直 (interacts with) 佇",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 佇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1089",
        "source" : "545",
        "target" : "173",
        "shared_name" : "直 (interacts with) 柱",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 柱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1088",
        "source" : "545",
        "target" : "238",
        "shared_name" : "直 (interacts with) 丈",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 丈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1087",
        "source" : "545",
        "target" : "354",
        "shared_name" : "直 (interacts with) 墜",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 墜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1086",
        "source" : "545",
        "target" : "388",
        "shared_name" : "直 (interacts with) 植",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 植",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1086,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1085",
        "source" : "544",
        "target" : "185",
        "shared_name" : "職 (interacts with) 占",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 占",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1084",
        "source" : "544",
        "target" : "462",
        "shared_name" : "職 (interacts with) 旨",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 旨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1083",
        "source" : "544",
        "target" : "311",
        "shared_name" : "職 (interacts with) 識",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 識",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1082",
        "source" : "543",
        "target" : "65",
        "shared_name" : "敕 (interacts with) 恥",
        "shared_interaction" : "interacts with",
        "name" : "敕 (interacts with) 恥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1081",
        "source" : "543",
        "target" : "500",
        "shared_name" : "敕 (interacts with) 丑",
        "shared_interaction" : "interacts with",
        "name" : "敕 (interacts with) 丑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1081,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1080",
        "source" : "542",
        "target" : "346",
        "shared_name" : "鋤 (interacts with) 崇",
        "shared_interaction" : "interacts with",
        "name" : "鋤 (interacts with) 崇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1079",
        "source" : "541",
        "target" : "279",
        "shared_name" : "息 (interacts with) 斯",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 斯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1079,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1078",
        "source" : "541",
        "target" : "511",
        "shared_name" : "息 (interacts with) 私",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 私",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1077",
        "source" : "541",
        "target" : "159",
        "shared_name" : "息 (interacts with) 雖",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 雖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1076",
        "source" : "541",
        "target" : "371",
        "shared_name" : "息 (interacts with) 思",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 思",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1075",
        "source" : "541",
        "target" : "121",
        "shared_name" : "息 (interacts with) 司",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 司",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1075,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1074",
        "source" : "541",
        "target" : "91",
        "shared_name" : "息 (interacts with) 辛",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 辛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1073",
        "source" : "541",
        "target" : "434",
        "shared_name" : "息 (interacts with) 相",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 相",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1072",
        "source" : "541",
        "target" : "314",
        "shared_name" : "息 (interacts with) 桑",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 桑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1071",
        "source" : "541",
        "target" : "204",
        "shared_name" : "息 (interacts with) 悉",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 悉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1071,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1070",
        "source" : "540",
        "target" : "497",
        "shared_name" : "如 (interacts with) 而",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 而",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1069",
        "source" : "540",
        "target" : "469",
        "shared_name" : "如 (interacts with) 人",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 人",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1068",
        "source" : "540",
        "target" : "151",
        "shared_name" : "如 (interacts with) 仍",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 仍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1067",
        "source" : "539",
        "target" : "167",
        "shared_name" : "居 (interacts with) 奇",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 奇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1066",
        "source" : "539",
        "target" : "163",
        "shared_name" : "居 (interacts with) 規",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 規",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1066,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1065",
        "source" : "539",
        "target" : "427",
        "shared_name" : "居 (interacts with) 其",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 其",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1064",
        "source" : "539",
        "target" : "539",
        "shared_name" : "居 (interacts with) 居",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 居",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1064,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1063",
        "source" : "539",
        "target" : "157",
        "shared_name" : "居 (interacts with) 几",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 几",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1062",
        "source" : "539",
        "target" : "108",
        "shared_name" : "居 (interacts with) 紀",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 紀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1061",
        "source" : "539",
        "target" : "437",
        "shared_name" : "居 (interacts with) 舉",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 舉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1060",
        "source" : "539",
        "target" : "266",
        "shared_name" : "居 (interacts with) 曁",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 曁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1059",
        "source" : "539",
        "target" : "127",
        "shared_name" : "居 (interacts with) 吉",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 吉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1058",
        "source" : "538",
        "target" : "235",
        "shared_name" : "以 (interacts with) 夷",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 夷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1057",
        "source" : "538",
        "target" : "316",
        "shared_name" : "以 (interacts with) 余",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 余",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1057,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1056",
        "source" : "538",
        "target" : "507",
        "shared_name" : "以 (interacts with) 餘",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 餘",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1055",
        "source" : "538",
        "target" : "448",
        "shared_name" : "以 (interacts with) 與",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 與",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1055,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1054",
        "source" : "537",
        "target" : "339",
        "shared_name" : "羽 (interacts with) 于",
        "shared_interaction" : "interacts with",
        "name" : "羽 (interacts with) 于",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1053",
        "source" : "536",
        "target" : "222",
        "shared_name" : "莫 (interacts with) 模",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 模",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1052",
        "source" : "536",
        "target" : "122",
        "shared_name" : "莫 (interacts with) 摸",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 摸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1051",
        "source" : "536",
        "target" : "186",
        "shared_name" : "莫 (interacts with) 謨",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 謨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1051,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1050",
        "source" : "536",
        "target" : "361",
        "shared_name" : "莫 (interacts with) 母",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 母",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1049",
        "source" : "536",
        "target" : "74",
        "shared_name" : "莫 (interacts with) 慕",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 慕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1048",
        "source" : "536",
        "target" : "350",
        "shared_name" : "莫 (interacts with) 目",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 目",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1047",
        "source" : "535",
        "target" : "165",
        "shared_name" : "去 (interacts with) 窺",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 窺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1046",
        "source" : "535",
        "target" : "373",
        "shared_name" : "去 (interacts with) 虚",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 虚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1046,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1045",
        "source" : "535",
        "target" : "283",
        "shared_name" : "去 (interacts with) 墟",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 墟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1045,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1044",
        "source" : "535",
        "target" : "260",
        "shared_name" : "去 (interacts with) 袪",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 袪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1043",
        "source" : "535",
        "target" : "254",
        "shared_name" : "去 (interacts with) 羌",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 羌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1042",
        "source" : "535",
        "target" : "161",
        "shared_name" : "去 (interacts with) 卿",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 卿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1041",
        "source" : "535",
        "target" : "80",
        "shared_name" : "去 (interacts with) 傾",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 傾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1040",
        "source" : "535",
        "target" : "452",
        "shared_name" : "去 (interacts with) 丘",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 丘",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1040,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1039",
        "source" : "535",
        "target" : "188",
        "shared_name" : "去 (interacts with) 欽",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 欽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1038",
        "source" : "535",
        "target" : "353",
        "shared_name" : "去 (interacts with) 跪",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 跪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1038,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1037",
        "source" : "535",
        "target" : "158",
        "shared_name" : "去 (interacts with) 詰",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 詰",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1036",
        "source" : "535",
        "target" : "322",
        "shared_name" : "去 (interacts with) 乞",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 乞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1036,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1035",
        "source" : "534",
        "target" : "427",
        "shared_name" : "渠 (interacts with) 其",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 其",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1034",
        "source" : "534",
        "target" : "442",
        "shared_name" : "渠 (interacts with) 俟",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 俟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1033",
        "source" : "534",
        "target" : "353",
        "shared_name" : "渠 (interacts with) 跪",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 跪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1032",
        "source" : "534",
        "target" : "215",
        "shared_name" : "渠 (interacts with) 狂",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 狂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "533",
        "target" : "176",
        "shared_name" : "房 (interacts with) 馮",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 馮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "533",
        "target" : "233",
        "shared_name" : "房 (interacts with) 毗",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 毗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "533",
        "target" : "116",
        "shared_name" : "房 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "533",
        "target" : "274",
        "shared_name" : "房 (interacts with) 便",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 便",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "533",
        "target" : "209",
        "shared_name" : "房 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "source" : "533",
        "target" : "71",
        "shared_name" : "房 (interacts with) 弼",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 弼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "532",
        "target" : "94",
        "shared_name" : "方 (interacts with) 鄙",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 鄙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "532",
        "target" : "438",
        "shared_name" : "方 (interacts with) 甫",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 甫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "532",
        "target" : "506",
        "shared_name" : "方 (interacts with) 府",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 府",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "532",
        "target" : "112",
        "shared_name" : "方 (interacts with) 父",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 父",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "532",
        "target" : "97",
        "shared_name" : "方 (interacts with) 封",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 封",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "532",
        "target" : "178",
        "shared_name" : "方 (interacts with) 徧",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 徧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "531",
        "target" : "179",
        "shared_name" : "敷 (interacts with) 峯",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 峯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "531",
        "target" : "168",
        "shared_name" : "敷 (interacts with) 披",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 披",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "source" : "531",
        "target" : "189",
        "shared_name" : "敷 (interacts with) 丕",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 丕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "531",
        "target" : "439",
        "shared_name" : "敷 (interacts with) 芳",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 芳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "531",
        "target" : "87",
        "shared_name" : "敷 (interacts with) 拂",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 拂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1014",
        "source" : "530",
        "target" : "356",
        "shared_name" : "昌 (interacts with) 充",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 充",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1013",
        "source" : "530",
        "target" : "460",
        "shared_name" : "昌 (interacts with) 處",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 處",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1013,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1012",
        "source" : "530",
        "target" : "508",
        "shared_name" : "昌 (interacts with) 尺",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 尺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1011",
        "source" : "530",
        "target" : "443",
        "shared_name" : "昌 (interacts with) 赤",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 赤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1010",
        "source" : "529",
        "target" : "125",
        "shared_name" : "力 (interacts with) 連",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 連",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1010,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1009",
        "source" : "529",
        "target" : "66",
        "shared_name" : "力 (interacts with) 林",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 林",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1008",
        "source" : "529",
        "target" : "488",
        "shared_name" : "力 (interacts with) 吕",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 吕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1007",
        "source" : "529",
        "target" : "328",
        "shared_name" : "力 (interacts with) 縷",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 縷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1006",
        "source" : "529",
        "target" : "77",
        "shared_name" : "力 (interacts with) 離",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 離",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1005",
        "source" : "528",
        "target" : "221",
        "shared_name" : "苦 (interacts with) 空",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 空",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1004",
        "source" : "528",
        "target" : "207",
        "shared_name" : "苦 (interacts with) 枯",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 枯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1003",
        "source" : "528",
        "target" : "217",
        "shared_name" : "苦 (interacts with) 牽",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 牽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1002",
        "source" : "528",
        "target" : "291",
        "shared_name" : "苦 (interacts with) 康",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 康",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1001",
        "source" : "528",
        "target" : "183",
        "shared_name" : "苦 (interacts with) 謙",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 謙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1000",
        "source" : "528",
        "target" : "70",
        "shared_name" : "苦 (interacts with) 楷",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 楷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "999",
        "source" : "528",
        "target" : "396",
        "shared_name" : "苦 (interacts with) 口",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 口",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "998",
        "source" : "528",
        "target" : "528",
        "shared_name" : "苦 (interacts with) 苦",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 苦",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "997",
        "source" : "528",
        "target" : "304",
        "shared_name" : "苦 (interacts with) 恪",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 恪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "996",
        "source" : "528",
        "target" : "320",
        "shared_name" : "苦 (interacts with) 客",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 客",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "995",
        "source" : "527",
        "target" : "394",
        "shared_name" : "古 (interacts with) 公",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 公",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "994",
        "source" : "527",
        "target" : "218",
        "shared_name" : "古 (interacts with) 姑",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 姑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "993",
        "source" : "527",
        "target" : "240",
        "shared_name" : "古 (interacts with) 佳",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 佳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "992",
        "source" : "527",
        "target" : "70",
        "shared_name" : "古 (interacts with) 楷",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 楷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "991",
        "source" : "527",
        "target" : "239",
        "shared_name" : "古 (interacts with) 乖",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 乖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "990",
        "source" : "527",
        "target" : "175",
        "shared_name" : "古 (interacts with) 干",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 干",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "989",
        "source" : "527",
        "target" : "284",
        "shared_name" : "古 (interacts with) 過",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 過",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "988",
        "source" : "527",
        "target" : "181",
        "shared_name" : "古 (interacts with) 兼",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 兼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "987",
        "source" : "527",
        "target" : "197",
        "shared_name" : "古 (interacts with) 各",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 各",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "986",
        "source" : "527",
        "target" : "104",
        "shared_name" : "古 (interacts with) 格",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 格",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "985",
        "source" : "526",
        "target" : "416",
        "shared_name" : "盧 (interacts with) 落",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 落",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "984",
        "source" : "526",
        "target" : "143",
        "shared_name" : "盧 (interacts with) 洛",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 洛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "983",
        "source" : "526",
        "target" : "295",
        "shared_name" : "盧 (interacts with) 勒",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 勒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "982",
        "source" : "525",
        "target" : "407",
        "shared_name" : "戸 (interacts with) 胡",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 胡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "981",
        "source" : "525",
        "target" : "174",
        "shared_name" : "戸 (interacts with) 乎",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 乎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "980",
        "source" : "525",
        "target" : "237",
        "shared_name" : "戸 (interacts with) 懷",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 懷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "979",
        "source" : "525",
        "target" : "244",
        "shared_name" : "戸 (interacts with) 侯",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 侯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "978",
        "source" : "524",
        "target" : "514",
        "shared_name" : "徂 (interacts with) 藏",
        "shared_interaction" : "interacts with",
        "name" : "徂 (interacts with) 藏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "977",
        "source" : "523",
        "target" : "115",
        "shared_name" : "烏 (interacts with) 鷖",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 鷖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "976",
        "source" : "523",
        "target" : "413",
        "shared_name" : "烏 (interacts with) 哀",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 哀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "975",
        "source" : "523",
        "target" : "245",
        "shared_name" : "烏 (interacts with) 安",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 安",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "974",
        "source" : "523",
        "target" : "192",
        "shared_name" : "烏 (interacts with) 烟",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 烟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "973",
        "source" : "523",
        "target" : "172",
        "shared_name" : "烏 (interacts with) 區",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 區",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "972",
        "source" : "523",
        "target" : "63",
        "shared_name" : "烏 (interacts with) 愛",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 愛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "971",
        "source" : "522",
        "target" : "138",
        "shared_name" : "倉 (interacts with) 麤",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 麤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "970",
        "source" : "522",
        "target" : "196",
        "shared_name" : "倉 (interacts with) 麁",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 麁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "969",
        "source" : "522",
        "target" : "248",
        "shared_name" : "倉 (interacts with) 采",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 采",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "968",
        "source" : "522",
        "target" : "459",
        "shared_name" : "倉 (interacts with) 取",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 取",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "967",
        "source" : "522",
        "target" : "329",
        "shared_name" : "倉 (interacts with) 醋",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 醋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "966",
        "source" : "521",
        "target" : "131",
        "shared_name" : "他 (interacts with) 通",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 通",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "965",
        "source" : "521",
        "target" : "190",
        "shared_name" : "他 (interacts with) 天",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 天",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "964",
        "source" : "521",
        "target" : "405",
        "shared_name" : "他 (interacts with) 土",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 土",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "963",
        "source" : "521",
        "target" : "369",
        "shared_name" : "他 (interacts with) 吐",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 吐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "962",
        "source" : "521",
        "target" : "142",
        "shared_name" : "他 (interacts with) 湯",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 湯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "961",
        "source" : "521",
        "target" : "334",
        "shared_name" : "他 (interacts with) 託",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 託",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "960",
        "source" : "520",
        "target" : "223",
        "shared_name" : "子 (interacts with) 兹",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 兹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "959",
        "source" : "520",
        "target" : "203",
        "shared_name" : "子 (interacts with) 𩛠",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 𩛠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "958",
        "source" : "520",
        "target" : "298",
        "shared_name" : "子 (interacts with) 氏",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 氏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "957",
        "source" : "520",
        "target" : "107",
        "shared_name" : "子 (interacts with) 漸",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 漸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "956",
        "source" : "520",
        "target" : "362",
        "shared_name" : "子 (interacts with) 借",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 借",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "955",
        "source" : "520",
        "target" : "498",
        "shared_name" : "子 (interacts with) 即",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 即",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "954",
        "source" : "520",
        "target" : "417",
        "shared_name" : "子 (interacts with) 則",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 則",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "519",
        "target" : "370",
        "shared_name" : "薄 (interacts with) 蒲",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 蒲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "source" : "519",
        "target" : "246",
        "shared_name" : "薄 (interacts with) 裴",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 裴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "519",
        "target" : "206",
        "shared_name" : "薄 (interacts with) 捕",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 捕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "519",
        "target" : "399",
        "shared_name" : "薄 (interacts with) 步",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 步",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "949",
        "source" : "518",
        "target" : "236",
        "shared_name" : "呼 (interacts with) 花",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 花",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "948",
        "source" : "518",
        "target" : "418",
        "shared_name" : "呼 (interacts with) 荒",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 荒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "947",
        "source" : "518",
        "target" : "213",
        "shared_name" : "呼 (interacts with) 馨",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 馨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "946",
        "source" : "518",
        "target" : "332",
        "shared_name" : "呼 (interacts with) 虎",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 虎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "945",
        "source" : "518",
        "target" : "136",
        "shared_name" : "呼 (interacts with) 海",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 海",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "944",
        "source" : "518",
        "target" : "402",
        "shared_name" : "呼 (interacts with) 火",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 火",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "943",
        "source" : "518",
        "target" : "73",
        "shared_name" : "呼 (interacts with) 呵",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 呵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "942",
        "source" : "517",
        "target" : "133",
        "shared_name" : "五 (interacts with) 吾",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 吾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "941",
        "source" : "517",
        "target" : "276",
        "shared_name" : "五 (interacts with) 兒",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 兒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "940",
        "source" : "517",
        "target" : "368",
        "shared_name" : "五 (interacts with) 俄",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 俄",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "939",
        "source" : "516",
        "target" : "406",
        "shared_name" : "蘇 (interacts with) 先",
        "shared_interaction" : "interacts with",
        "name" : "蘇 (interacts with) 先",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "938",
        "source" : "515",
        "target" : "99",
        "shared_name" : "都 (interacts with) 冬",
        "shared_interaction" : "interacts with",
        "name" : "都 (interacts with) 冬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "937",
        "source" : "515",
        "target" : "412",
        "shared_name" : "都 (interacts with) 當",
        "shared_interaction" : "interacts with",
        "name" : "都 (interacts with) 當",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "936",
        "source" : "513",
        "target" : "419",
        "shared_name" : "奴 (interacts with) 乃",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 乃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "935",
        "source" : "513",
        "target" : "367",
        "shared_name" : "奴 (interacts with) 那",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 那",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "934",
        "source" : "513",
        "target" : "333",
        "shared_name" : "奴 (interacts with) 諾",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 諾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "933",
        "source" : "512",
        "target" : "69",
        "shared_name" : "作 (interacts with) 簪",
        "shared_interaction" : "interacts with",
        "name" : "作 (interacts with) 簪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "932",
        "source" : "511",
        "target" : "263",
        "shared_name" : "私 (interacts with) 胥",
        "shared_interaction" : "interacts with",
        "name" : "私 (interacts with) 胥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "931",
        "source" : "510",
        "target" : "262",
        "shared_name" : "書 (interacts with) 詩",
        "shared_interaction" : "interacts with",
        "name" : "書 (interacts with) 詩",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "930",
        "source" : "510",
        "target" : "187",
        "shared_name" : "書 (interacts with) 賞",
        "shared_interaction" : "interacts with",
        "name" : "書 (interacts with) 賞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "929",
        "source" : "509",
        "target" : "78",
        "shared_name" : "祥 (interacts with) 寺",
        "shared_interaction" : "interacts with",
        "name" : "祥 (interacts with) 寺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "928",
        "source" : "509",
        "target" : "341",
        "shared_name" : "祥 (interacts with) 夕",
        "shared_interaction" : "interacts with",
        "name" : "祥 (interacts with) 夕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "927",
        "source" : "508",
        "target" : "530",
        "shared_name" : "尺 (interacts with) 昌",
        "shared_interaction" : "interacts with",
        "name" : "尺 (interacts with) 昌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "source" : "506",
        "target" : "97",
        "shared_name" : "府 (interacts with) 封",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 封",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "506",
        "target" : "199",
        "shared_name" : "府 (interacts with) 分",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 分",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "source" : "506",
        "target" : "532",
        "shared_name" : "府 (interacts with) 方",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 方",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "506",
        "target" : "277",
        "shared_name" : "府 (interacts with) 并",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 并",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "922",
        "source" : "506",
        "target" : "226",
        "shared_name" : "府 (interacts with) 反",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 反",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "921",
        "source" : "505",
        "target" : "92",
        "shared_name" : "許 (interacts with) 羲",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 羲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "920",
        "source" : "505",
        "target" : "471",
        "shared_name" : "許 (interacts with) 香",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 香",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "919",
        "source" : "505",
        "target" : "225",
        "shared_name" : "許 (interacts with) 休",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 休",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "918",
        "source" : "505",
        "target" : "433",
        "shared_name" : "許 (interacts with) 朽",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 朽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "917",
        "source" : "505",
        "target" : "428",
        "shared_name" : "許 (interacts with) 況",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 況",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "916",
        "source" : "505",
        "target" : "270",
        "shared_name" : "許 (interacts with) 興",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 興",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "915",
        "source" : "504",
        "target" : "232",
        "shared_name" : "魚 (interacts with) 宜",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 宜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "914",
        "source" : "504",
        "target" : "164",
        "shared_name" : "魚 (interacts with) 危",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 危",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "913",
        "source" : "504",
        "target" : "395",
        "shared_name" : "魚 (interacts with) 擬",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 擬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "912",
        "source" : "504",
        "target" : "446",
        "shared_name" : "魚 (interacts with) 語",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 語",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "911",
        "source" : "504",
        "target" : "105",
        "shared_name" : "魚 (interacts with) 玉",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 玉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "910",
        "source" : "503",
        "target" : "355",
        "shared_name" : "於 (interacts with) 委",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 委",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "909",
        "source" : "503",
        "target" : "110",
        "shared_name" : "於 (interacts with) 伊",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 伊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "908",
        "source" : "503",
        "target" : "148",
        "shared_name" : "於 (interacts with) 依",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 依",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "907",
        "source" : "503",
        "target" : "184",
        "shared_name" : "於 (interacts with) 衣",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 衣",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "906",
        "source" : "503",
        "target" : "192",
        "shared_name" : "於 (interacts with) 烟",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 烟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "905",
        "source" : "503",
        "target" : "432",
        "shared_name" : "於 (interacts with) 央",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 央",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "904",
        "source" : "503",
        "target" : "76",
        "shared_name" : "於 (interacts with) 憂",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 憂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "903",
        "source" : "503",
        "target" : "103",
        "shared_name" : "於 (interacts with) 音",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 音",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "902",
        "source" : "503",
        "target" : "486",
        "shared_name" : "於 (interacts with) 握",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 握",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "901",
        "source" : "503",
        "target" : "365",
        "shared_name" : "於 (interacts with) 一",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 一",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "900",
        "source" : "503",
        "target" : "400",
        "shared_name" : "於 (interacts with) 乙",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 乙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "899",
        "source" : "503",
        "target" : "372",
        "shared_name" : "於 (interacts with) 謁",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 謁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "898",
        "source" : "503",
        "target" : "421",
        "shared_name" : "於 (interacts with) 憶",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 憶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "897",
        "source" : "502",
        "target" : "171",
        "shared_name" : "女 (interacts with) 穠",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 穠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "896",
        "source" : "502",
        "target" : "257",
        "shared_name" : "女 (interacts with) 尼",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 尼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "895",
        "source" : "502",
        "target" : "193",
        "shared_name" : "女 (interacts with) 拏",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 拏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "894",
        "source" : "501",
        "target" : "255",
        "shared_name" : "疾 (interacts with) 慈",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 慈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "893",
        "source" : "501",
        "target" : "223",
        "shared_name" : "疾 (interacts with) 兹",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 兹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "892",
        "source" : "501",
        "target" : "81",
        "shared_name" : "疾 (interacts with) 情",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 情",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "891",
        "source" : "501",
        "target" : "308",
        "shared_name" : "疾 (interacts with) 自",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 自",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "890",
        "source" : "501",
        "target" : "383",
        "shared_name" : "疾 (interacts with) 匠",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 匠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "889",
        "source" : "500",
        "target" : "230",
        "shared_name" : "丑 (interacts with) 癡",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 癡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "888",
        "source" : "500",
        "target" : "145",
        "shared_name" : "丑 (interacts with) 抽",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 抽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "887",
        "source" : "500",
        "target" : "267",
        "shared_name" : "丑 (interacts with) 楮",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 楮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "source" : "499",
        "target" : "301",
        "shared_name" : "符 (interacts with) 皮",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 皮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "source" : "499",
        "target" : "246",
        "shared_name" : "符 (interacts with) 裴",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 裴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "source" : "499",
        "target" : "177",
        "shared_name" : "符 (interacts with) 頻",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 頻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "499",
        "target" : "533",
        "shared_name" : "符 (interacts with) 房",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 房",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "882",
        "source" : "499",
        "target" : "424",
        "shared_name" : "符 (interacts with) 防",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 防",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "499",
        "target" : "532",
        "shared_name" : "符 (interacts with) 方",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 方",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "880",
        "source" : "499",
        "target" : "209",
        "shared_name" : "符 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "499",
        "target" : "375",
        "shared_name" : "符 (interacts with) 附",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 附",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "878",
        "source" : "499",
        "target" : "306",
        "shared_name" : "符 (interacts with) 縛",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 縛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "877",
        "source" : "498",
        "target" : "156",
        "shared_name" : "即 (interacts with) 資",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 資",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "876",
        "source" : "498",
        "target" : "384",
        "shared_name" : "即 (interacts with) 將",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 將",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "875",
        "source" : "498",
        "target" : "520",
        "shared_name" : "即 (interacts with) 子",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 子",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "874",
        "source" : "497",
        "target" : "171",
        "shared_name" : "而 (interacts with) 穠",
        "shared_interaction" : "interacts with",
        "name" : "而 (interacts with) 穠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "873",
        "source" : "497",
        "target" : "307",
        "shared_name" : "而 (interacts with) 耳",
        "shared_interaction" : "interacts with",
        "name" : "而 (interacts with) 耳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "872",
        "source" : "495",
        "target" : "539",
        "shared_name" : "九 (interacts with) 居",
        "shared_interaction" : "interacts with",
        "name" : "九 (interacts with) 居",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "871",
        "source" : "494",
        "target" : "208",
        "shared_name" : "七 (interacts with) 親",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 親",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "870",
        "source" : "494",
        "target" : "119",
        "shared_name" : "七 (interacts with) 遷",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 遷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "869",
        "source" : "494",
        "target" : "522",
        "shared_name" : "七 (interacts with) 倉",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 倉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "868",
        "source" : "494",
        "target" : "347",
        "shared_name" : "七 (interacts with) 蒼",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 蒼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "867",
        "source" : "494",
        "target" : "459",
        "shared_name" : "七 (interacts with) 取",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 取",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "866",
        "source" : "492",
        "target" : "325",
        "shared_name" : "楚 (interacts with) 初",
        "shared_interaction" : "interacts with",
        "name" : "楚 (interacts with) 初",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "865",
        "source" : "492",
        "target" : "455",
        "shared_name" : "楚 (interacts with) 叉",
        "shared_interaction" : "interacts with",
        "name" : "楚 (interacts with) 叉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "864",
        "source" : "491",
        "target" : "129",
        "shared_name" : "博 (interacts with) 晡",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 晡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "863",
        "source" : "491",
        "target" : "241",
        "shared_name" : "博 (interacts with) 補",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 補",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "862",
        "source" : "491",
        "target" : "392",
        "shared_name" : "博 (interacts with) 布",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 布",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "861",
        "source" : "491",
        "target" : "349",
        "shared_name" : "博 (interacts with) 卜",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 卜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "860",
        "source" : "491",
        "target" : "326",
        "shared_name" : "博 (interacts with) 伯",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 伯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "859",
        "source" : "491",
        "target" : "84",
        "shared_name" : "博 (interacts with) 百",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 百",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "858",
        "source" : "491",
        "target" : "360",
        "shared_name" : "博 (interacts with) 北",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 北",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "489",
        "target" : "168",
        "shared_name" : "匹 (interacts with) 披",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 披",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "856",
        "source" : "489",
        "target" : "96",
        "shared_name" : "匹 (interacts with) 譬",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 譬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "489",
        "target" : "348",
        "shared_name" : "匹 (interacts with) 偏",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 偏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "854",
        "source" : "488",
        "target" : "77",
        "shared_name" : "吕 (interacts with) 離",
        "shared_interaction" : "interacts with",
        "name" : "吕 (interacts with) 離",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "853",
        "source" : "488",
        "target" : "264",
        "shared_name" : "吕 (interacts with) 良",
        "shared_interaction" : "interacts with",
        "name" : "吕 (interacts with) 良",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "852",
        "source" : "487",
        "target" : "461",
        "shared_name" : "所 (interacts with) 䟽",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 䟽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "851",
        "source" : "487",
        "target" : "265",
        "shared_name" : "所 (interacts with) 踈",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 踈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "850",
        "source" : "487",
        "target" : "470",
        "shared_name" : "所 (interacts with) 山",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 山",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "849",
        "source" : "487",
        "target" : "201",
        "shared_name" : "所 (interacts with) 沙",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 沙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "848",
        "source" : "487",
        "target" : "205",
        "shared_name" : "所 (interacts with) 砂",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 砂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "847",
        "source" : "487",
        "target" : "130",
        "shared_name" : "所 (interacts with) 生",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 生",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "846",
        "source" : "487",
        "target" : "359",
        "shared_name" : "所 (interacts with) 數",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 數",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "845",
        "source" : "487",
        "target" : "321",
        "shared_name" : "所 (interacts with) 色",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 色",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "844",
        "source" : "484",
        "target" : "336",
        "shared_name" : "士 (interacts with) 鉏",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 鉏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "843",
        "source" : "484",
        "target" : "542",
        "shared_name" : "士 (interacts with) 鋤",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 鋤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "842",
        "source" : "484",
        "target" : "261",
        "shared_name" : "士 (interacts with) 牀",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 牀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "841",
        "source" : "484",
        "target" : "90",
        "shared_name" : "士 (interacts with) 崱",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 崱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "840",
        "source" : "483",
        "target" : "170",
        "shared_name" : "章 (interacts with) 支",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 支",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "839",
        "source" : "483",
        "target" : "298",
        "shared_name" : "章 (interacts with) 氏",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 氏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "838",
        "source" : "483",
        "target" : "345",
        "shared_name" : "章 (interacts with) 諸",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 諸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "837",
        "source" : "483",
        "target" : "313",
        "shared_name" : "章 (interacts with) 煑",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 煑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "836",
        "source" : "483",
        "target" : "185",
        "shared_name" : "章 (interacts with) 占",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 占",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "835",
        "source" : "482",
        "target" : "278",
        "shared_name" : "弋 (interacts with) 移",
        "shared_interaction" : "interacts with",
        "name" : "弋 (interacts with) 移",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "834",
        "source" : "482",
        "target" : "463",
        "shared_name" : "弋 (interacts with) 恱",
        "shared_interaction" : "interacts with",
        "name" : "弋 (interacts with) 恱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "833",
        "source" : "481",
        "target" : "381",
        "shared_name" : "薳 (interacts with) 爲",
        "shared_interaction" : "interacts with",
        "name" : "薳 (interacts with) 爲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "832",
        "source" : "479",
        "target" : "403",
        "shared_name" : "是 (interacts with) 成",
        "shared_interaction" : "interacts with",
        "name" : "是 (interacts with) 成",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "478",
        "target" : "210",
        "shared_name" : "彼 (interacts with) 陂",
        "shared_interaction" : "interacts with",
        "name" : "彼 (interacts with) 陂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "830",
        "source" : "477",
        "target" : "272",
        "shared_name" : "旬 (interacts with) 隨",
        "shared_interaction" : "interacts with",
        "name" : "旬 (interacts with) 隨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "829",
        "source" : "476",
        "target" : "435",
        "shared_name" : "巨 (interacts with) 強",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 強",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "828",
        "source" : "476",
        "target" : "215",
        "shared_name" : "巨 (interacts with) 狂",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 狂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "827",
        "source" : "476",
        "target" : "330",
        "shared_name" : "巨 (interacts with) 求",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 求",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "826",
        "source" : "476",
        "target" : "150",
        "shared_name" : "巨 (interacts with) 近",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 近",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "825",
        "source" : "475",
        "target" : "276",
        "shared_name" : "汝 (interacts with) 兒",
        "shared_interaction" : "interacts with",
        "name" : "汝 (interacts with) 兒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "824",
        "source" : "474",
        "target" : "273",
        "shared_name" : "式 (interacts with) 施",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 施",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "823",
        "source" : "474",
        "target" : "149",
        "shared_name" : "式 (interacts with) 商",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 商",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "822",
        "source" : "474",
        "target" : "436",
        "shared_name" : "式 (interacts with) 傷",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 傷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "821",
        "source" : "474",
        "target" : "142",
        "shared_name" : "式 (interacts with) 湯",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 湯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "820",
        "source" : "474",
        "target" : "153",
        "shared_name" : "式 (interacts with) 矢",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 矢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "819",
        "source" : "474",
        "target" : "135",
        "shared_name" : "式 (interacts with) 試",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 試",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "818",
        "source" : "474",
        "target" : "386",
        "shared_name" : "式 (interacts with) 失",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 失",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "817",
        "source" : "473",
        "target" : "380",
        "shared_name" : "武 (interacts with) 彌",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 彌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "816",
        "source" : "473",
        "target" : "231",
        "shared_name" : "武 (interacts with) 眉",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 眉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "815",
        "source" : "473",
        "target" : "441",
        "shared_name" : "武 (interacts with) 無",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 無",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "814",
        "source" : "473",
        "target" : "118",
        "shared_name" : "武 (interacts with) 巫",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 巫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "813",
        "source" : "473",
        "target" : "275",
        "shared_name" : "武 (interacts with) 綿",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 綿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "812",
        "source" : "473",
        "target" : "302",
        "shared_name" : "武 (interacts with) 亡",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 亡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "811",
        "source" : "473",
        "target" : "88",
        "shared_name" : "武 (interacts with) 望",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 望",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "810",
        "source" : "473",
        "target" : "180",
        "shared_name" : "武 (interacts with) 明",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 明",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "809",
        "source" : "473",
        "target" : "293",
        "shared_name" : "武 (interacts with) 名",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 名",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "808",
        "source" : "472",
        "target" : "281",
        "shared_name" : "此 (interacts with) 雌",
        "shared_interaction" : "interacts with",
        "name" : "此 (interacts with) 雌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "807",
        "source" : "469",
        "target" : "540",
        "shared_name" : "人 (interacts with) 如",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 如",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "806",
        "source" : "469",
        "target" : "458",
        "shared_name" : "人 (interacts with) 儒",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 儒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "805",
        "source" : "469",
        "target" : "475",
        "shared_name" : "人 (interacts with) 汝",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 汝",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "804",
        "source" : "466",
        "target" : "398",
        "shared_name" : "竹 (interacts with) 卓",
        "shared_interaction" : "interacts with",
        "name" : "竹 (interacts with) 卓",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "803",
        "source" : "466",
        "target" : "546",
        "shared_name" : "竹 (interacts with) 陟",
        "shared_interaction" : "interacts with",
        "name" : "竹 (interacts with) 陟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "802",
        "source" : "464",
        "target" : "422",
        "shared_name" : "側 (interacts with) 莊",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 莊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "801",
        "source" : "464",
        "target" : "162",
        "shared_name" : "側 (interacts with) 爭",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 爭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "800",
        "source" : "464",
        "target" : "85",
        "shared_name" : "側 (interacts with) 鄒",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 鄒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "799",
        "source" : "464",
        "target" : "69",
        "shared_name" : "側 (interacts with) 簪",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 簪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "798",
        "source" : "464",
        "target" : "357",
        "shared_name" : "側 (interacts with) 阻",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 阻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "797",
        "source" : "462",
        "target" : "160",
        "shared_name" : "旨 (interacts with) 脂",
        "shared_interaction" : "interacts with",
        "name" : "旨 (interacts with) 脂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "796",
        "source" : "457",
        "target" : "316",
        "shared_name" : "視 (interacts with) 余",
        "shared_interaction" : "interacts with",
        "name" : "視 (interacts with) 余",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "795",
        "source" : "454",
        "target" : "412",
        "shared_name" : "丁 (interacts with) 當",
        "shared_interaction" : "interacts with",
        "name" : "丁 (interacts with) 當",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "794",
        "source" : "452",
        "target" : "493",
        "shared_name" : "丘 (interacts with) 曲",
        "shared_interaction" : "interacts with",
        "name" : "丘 (interacts with) 曲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "793",
        "source" : "451",
        "target" : "446",
        "shared_name" : "牛 (interacts with) 語",
        "shared_interaction" : "interacts with",
        "name" : "牛 (interacts with) 語",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "792",
        "source" : "451",
        "target" : "430",
        "shared_name" : "牛 (interacts with) 遇",
        "shared_interaction" : "interacts with",
        "name" : "牛 (interacts with) 遇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "791",
        "source" : "449",
        "target" : "290",
        "shared_name" : "止 (interacts with) 之",
        "shared_interaction" : "interacts with",
        "name" : "止 (interacts with) 之",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "790",
        "source" : "448",
        "target" : "111",
        "shared_name" : "與 (interacts with) 台",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 台",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "789",
        "source" : "448",
        "target" : "426",
        "shared_name" : "與 (interacts with) 羊",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 羊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "788",
        "source" : "448",
        "target" : "378",
        "shared_name" : "與 (interacts with) 詳",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 詳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "787",
        "source" : "448",
        "target" : "482",
        "shared_name" : "與 (interacts with) 弋",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 弋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "786",
        "source" : "448",
        "target" : "382",
        "shared_name" : "與 (interacts with) 翼",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 翼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "785",
        "source" : "447",
        "target" : "289",
        "shared_name" : "市 (interacts with) 時",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 時",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "784",
        "source" : "447",
        "target" : "100",
        "shared_name" : "市 (interacts with) 殊",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 殊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "783",
        "source" : "447",
        "target" : "379",
        "shared_name" : "市 (interacts with) 常",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 常",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "782",
        "source" : "447",
        "target" : "140",
        "shared_name" : "市 (interacts with) 嘗",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 嘗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "781",
        "source" : "447",
        "target" : "496",
        "shared_name" : "市 (interacts with) 蜀",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 蜀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "780",
        "source" : "446",
        "target" : "247",
        "shared_name" : "語 (interacts with) 疑",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 疑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "779",
        "source" : "446",
        "target" : "504",
        "shared_name" : "語 (interacts with) 魚",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 魚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "778",
        "source" : "446",
        "target" : "451",
        "shared_name" : "語 (interacts with) 牛",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 牛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "777",
        "source" : "445",
        "target" : "134",
        "shared_name" : "似 (interacts with) 辭",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 辭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "776",
        "source" : "445",
        "target" : "220",
        "shared_name" : "似 (interacts with) 辝",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 辝",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "775",
        "source" : "445",
        "target" : "300",
        "shared_name" : "似 (interacts with) 徐",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 徐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "774",
        "source" : "445",
        "target" : "378",
        "shared_name" : "似 (interacts with) 詳",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 詳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "773",
        "source" : "445",
        "target" : "509",
        "shared_name" : "似 (interacts with) 祥",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 祥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "772",
        "source" : "441",
        "target" : "285",
        "shared_name" : "無 (interacts with) 文",
        "shared_interaction" : "interacts with",
        "name" : "無 (interacts with) 文",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "771",
        "source" : "441",
        "target" : "95",
        "shared_name" : "無 (interacts with) 美",
        "shared_interaction" : "interacts with",
        "name" : "無 (interacts with) 美",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "770",
        "source" : "440",
        "target" : "282",
        "shared_name" : "雨 (interacts with) 韋",
        "shared_interaction" : "interacts with",
        "name" : "雨 (interacts with) 韋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "769",
        "source" : "440",
        "target" : "377",
        "shared_name" : "雨 (interacts with) 王",
        "shared_interaction" : "interacts with",
        "name" : "雨 (interacts with) 王",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "source" : "439",
        "target" : "200",
        "shared_name" : "芳 (interacts with) 妃",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 妃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "439",
        "target" : "531",
        "shared_name" : "芳 (interacts with) 敷",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 敷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "source" : "439",
        "target" : "374",
        "shared_name" : "芳 (interacts with) 孚",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 孚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "439",
        "target" : "348",
        "shared_name" : "芳 (interacts with) 偏",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 偏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "439",
        "target" : "338",
        "shared_name" : "芳 (interacts with) 撫",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 撫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "438",
        "target" : "389",
        "shared_name" : "甫 (interacts with) 扶",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 扶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "438",
        "target" : "195",
        "shared_name" : "甫 (interacts with) 兵",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 兵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "438",
        "target" : "478",
        "shared_name" : "甫 (interacts with) 彼",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 彼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "760",
        "source" : "437",
        "target" : "250",
        "shared_name" : "舉 (interacts with) 俱",
        "shared_interaction" : "interacts with",
        "name" : "舉 (interacts with) 俱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "759",
        "source" : "437",
        "target" : "495",
        "shared_name" : "舉 (interacts with) 九",
        "shared_interaction" : "interacts with",
        "name" : "舉 (interacts with) 九",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "758",
        "source" : "436",
        "target" : "510",
        "shared_name" : "傷 (interacts with) 書",
        "shared_interaction" : "interacts with",
        "name" : "傷 (interacts with) 書",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "757",
        "source" : "436",
        "target" : "258",
        "shared_name" : "傷 (interacts with) 舒",
        "shared_interaction" : "interacts with",
        "name" : "傷 (interacts with) 舒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "756",
        "source" : "435",
        "target" : "534",
        "shared_name" : "強 (interacts with) 渠",
        "shared_interaction" : "interacts with",
        "name" : "強 (interacts with) 渠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "755",
        "source" : "434",
        "target" : "263",
        "shared_name" : "相 (interacts with) 胥",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 胥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "754",
        "source" : "434",
        "target" : "343",
        "shared_name" : "相 (interacts with) 須",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 須",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "753",
        "source" : "434",
        "target" : "371",
        "shared_name" : "相 (interacts with) 思",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 思",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "752",
        "source" : "434",
        "target" : "541",
        "shared_name" : "相 (interacts with) 息",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 息",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "751",
        "source" : "433",
        "target" : "310",
        "shared_name" : "朽 (interacts with) 虛",
        "shared_interaction" : "interacts with",
        "name" : "朽 (interacts with) 虛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "750",
        "source" : "432",
        "target" : "503",
        "shared_name" : "央 (interacts with) 於",
        "shared_interaction" : "interacts with",
        "name" : "央 (interacts with) 於",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "749",
        "source" : "431",
        "target" : "286",
        "shared_name" : "署 (interacts with) 承",
        "shared_interaction" : "interacts with",
        "name" : "署 (interacts with) 承",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "748",
        "source" : "430",
        "target" : "253",
        "shared_name" : "遇 (interacts with) 虞",
        "shared_interaction" : "interacts with",
        "name" : "遇 (interacts with) 虞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "747",
        "source" : "430",
        "target" : "376",
        "shared_name" : "遇 (interacts with) 愚",
        "shared_interaction" : "interacts with",
        "name" : "遇 (interacts with) 愚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "746",
        "source" : "429",
        "target" : "144",
        "shared_name" : "測 (interacts with) 芻",
        "shared_interaction" : "interacts with",
        "name" : "測 (interacts with) 芻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "745",
        "source" : "427",
        "target" : "89",
        "shared_name" : "其 (interacts with) 衢",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 衢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "744",
        "source" : "427",
        "target" : "476",
        "shared_name" : "其 (interacts with) 巨",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 巨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "743",
        "source" : "427",
        "target" : "150",
        "shared_name" : "其 (interacts with) 近",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 近",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "742",
        "source" : "427",
        "target" : "132",
        "shared_name" : "其 (interacts with) 臼",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 臼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "741",
        "source" : "427",
        "target" : "75",
        "shared_name" : "其 (interacts with) 具",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 具",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "740",
        "source" : "426",
        "target" : "538",
        "shared_name" : "羊 (interacts with) 以",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 以",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "739",
        "source" : "426",
        "target" : "387",
        "shared_name" : "羊 (interacts with) 食",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 食",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "738",
        "source" : "426",
        "target" : "448",
        "shared_name" : "羊 (interacts with) 與",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 與",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "737",
        "source" : "425",
        "target" : "172",
        "shared_name" : "豈 (interacts with) 區",
        "shared_interaction" : "interacts with",
        "name" : "豈 (interacts with) 區",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "736",
        "source" : "425",
        "target" : "251",
        "shared_name" : "豈 (interacts with) 驅",
        "shared_interaction" : "interacts with",
        "name" : "豈 (interacts with) 驅",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "424",
        "target" : "389",
        "shared_name" : "防 (interacts with) 扶",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 扶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "424",
        "target" : "499",
        "shared_name" : "防 (interacts with) 符",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 符",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "424",
        "target" : "211",
        "shared_name" : "防 (interacts with) 苻",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 苻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "732",
        "source" : "423",
        "target" : "219",
        "shared_name" : "仕 (interacts with) 雛",
        "shared_interaction" : "interacts with",
        "name" : "仕 (interacts with) 雛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "731",
        "source" : "423",
        "target" : "249",
        "shared_name" : "仕 (interacts with) 鶵",
        "shared_interaction" : "interacts with",
        "name" : "仕 (interacts with) 鶵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "730",
        "source" : "422",
        "target" : "357",
        "shared_name" : "莊 (interacts with) 阻",
        "shared_interaction" : "interacts with",
        "name" : "莊 (interacts with) 阻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "729",
        "source" : "421",
        "target" : "198",
        "shared_name" : "憶 (interacts with) 紆",
        "shared_interaction" : "interacts with",
        "name" : "憶 (interacts with) 紆",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "728",
        "source" : "420",
        "target" : "547",
        "shared_name" : "同 (interacts with) 徒",
        "shared_interaction" : "interacts with",
        "name" : "同 (interacts with) 徒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "727",
        "source" : "419",
        "target" : "513",
        "shared_name" : "乃 (interacts with) 奴",
        "shared_interaction" : "interacts with",
        "name" : "乃 (interacts with) 奴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "726",
        "source" : "418",
        "target" : "518",
        "shared_name" : "荒 (interacts with) 呼",
        "shared_interaction" : "interacts with",
        "name" : "荒 (interacts with) 呼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "725",
        "source" : "417",
        "target" : "391",
        "shared_name" : "則 (interacts with) 臧",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 臧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "724",
        "source" : "417",
        "target" : "390",
        "shared_name" : "則 (interacts with) 祖",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 祖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "723",
        "source" : "417",
        "target" : "512",
        "shared_name" : "則 (interacts with) 作",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 作",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "722",
        "source" : "416",
        "target" : "526",
        "shared_name" : "落 (interacts with) 盧",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 盧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "721",
        "source" : "416",
        "target" : "234",
        "shared_name" : "落 (interacts with) 來",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 來",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "720",
        "source" : "416",
        "target" : "397",
        "shared_name" : "落 (interacts with) 賴",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 賴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "719",
        "source" : "415",
        "target" : "516",
        "shared_name" : "素 (interacts with) 蘇",
        "shared_interaction" : "interacts with",
        "name" : "素 (interacts with) 蘇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "718",
        "source" : "414",
        "target" : "524",
        "shared_name" : "昨 (interacts with) 徂",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 徂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "717",
        "source" : "414",
        "target" : "324",
        "shared_name" : "昨 (interacts with) 才",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 才",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "716",
        "source" : "414",
        "target" : "67",
        "shared_name" : "昨 (interacts with) 前",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 前",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "715",
        "source" : "414",
        "target" : "514",
        "shared_name" : "昨 (interacts with) 藏",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 藏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "714",
        "source" : "414",
        "target" : "363",
        "shared_name" : "昨 (interacts with) 在",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 在",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "713",
        "source" : "413",
        "target" : "523",
        "shared_name" : "哀 (interacts with) 烏",
        "shared_interaction" : "interacts with",
        "name" : "哀 (interacts with) 烏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "712",
        "source" : "413",
        "target" : "503",
        "shared_name" : "哀 (interacts with) 於",
        "shared_interaction" : "interacts with",
        "name" : "哀 (interacts with) 於",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "711",
        "source" : "412",
        "target" : "515",
        "shared_name" : "當 (interacts with) 都",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 都",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "710",
        "source" : "412",
        "target" : "454",
        "shared_name" : "當 (interacts with) 丁",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 丁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "709",
        "source" : "412",
        "target" : "267",
        "shared_name" : "當 (interacts with) 楮",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 楮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "source" : "411",
        "target" : "331",
        "shared_name" : "普 (interacts with) 滂",
        "shared_interaction" : "interacts with",
        "name" : "普 (interacts with) 滂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "707",
        "source" : "410",
        "target" : "393",
        "shared_name" : "郎 (interacts with) 魯",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 魯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "706",
        "source" : "410",
        "target" : "77",
        "shared_name" : "郎 (interacts with) 離",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 離",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "705",
        "source" : "410",
        "target" : "82",
        "shared_name" : "郎 (interacts with) 練",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 練",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "704",
        "source" : "407",
        "target" : "194",
        "shared_name" : "胡 (interacts with) 何",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 何",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "703",
        "source" : "407",
        "target" : "139",
        "shared_name" : "胡 (interacts with) 黃",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 黃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "702",
        "source" : "407",
        "target" : "490",
        "shared_name" : "胡 (interacts with) 下",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 下",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "701",
        "source" : "407",
        "target" : "352",
        "shared_name" : "胡 (interacts with) 獲",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 獲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "700",
        "source" : "405",
        "target" : "111",
        "shared_name" : "土 (interacts with) 台",
        "shared_interaction" : "interacts with",
        "name" : "土 (interacts with) 台",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "399",
        "target" : "177",
        "shared_name" : "步 (interacts with) 頻",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 頻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "399",
        "target" : "243",
        "shared_name" : "步 (interacts with) 傍",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 傍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "399",
        "target" : "533",
        "shared_name" : "步 (interacts with) 房",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 房",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "696",
        "source" : "394",
        "target" : "527",
        "shared_name" : "公 (interacts with) 古",
        "shared_interaction" : "interacts with",
        "name" : "公 (interacts with) 古",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "695",
        "source" : "393",
        "target" : "410",
        "shared_name" : "魯 (interacts with) 郎",
        "shared_interaction" : "interacts with",
        "name" : "魯 (interacts with) 郎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "694",
        "source" : "392",
        "target" : "101",
        "shared_name" : "布 (interacts with) 班",
        "shared_interaction" : "interacts with",
        "name" : "布 (interacts with) 班",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "693",
        "source" : "392",
        "target" : "408",
        "shared_name" : "布 (interacts with) 邊",
        "shared_interaction" : "interacts with",
        "name" : "布 (interacts with) 邊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "692",
        "source" : "391",
        "target" : "512",
        "shared_name" : "臧 (interacts with) 作",
        "shared_interaction" : "interacts with",
        "name" : "臧 (interacts with) 作",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "389",
        "target" : "176",
        "shared_name" : "扶 (interacts with) 馮",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 馮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "source" : "389",
        "target" : "112",
        "shared_name" : "扶 (interacts with) 父",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 父",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "389",
        "target" : "199",
        "shared_name" : "扶 (interacts with) 分",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 分",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "688",
        "source" : "388",
        "target" : "252",
        "shared_name" : "植 (interacts with) 臣",
        "shared_interaction" : "interacts with",
        "name" : "植 (interacts with) 臣",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "687",
        "source" : "387",
        "target" : "271",
        "shared_name" : "食 (interacts with) 神",
        "shared_interaction" : "interacts with",
        "name" : "食 (interacts with) 神",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "686",
        "source" : "387",
        "target" : "64",
        "shared_name" : "食 (interacts with) 乗",
        "shared_interaction" : "interacts with",
        "name" : "食 (interacts with) 乗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "385",
        "target" : "102",
        "shared_name" : "必 (interacts with) 賔",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 賔",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "385",
        "target" : "342",
        "shared_name" : "必 (interacts with) 卑",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 卑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "385",
        "target" : "114",
        "shared_name" : "必 (interacts with) 𢌿",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 𢌿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "385",
        "target" : "116",
        "shared_name" : "必 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "681",
        "source" : "384",
        "target" : "467",
        "shared_name" : "將 (interacts with) 遵",
        "shared_interaction" : "interacts with",
        "name" : "將 (interacts with) 遵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "680",
        "source" : "384",
        "target" : "453",
        "shared_name" : "將 (interacts with) 醉",
        "shared_interaction" : "interacts with",
        "name" : "將 (interacts with) 醉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "679",
        "source" : "383",
        "target" : "155",
        "shared_name" : "匠 (interacts with) 秦",
        "shared_interaction" : "interacts with",
        "name" : "匠 (interacts with) 秦",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "678",
        "source" : "381",
        "target" : "62",
        "shared_name" : "爲 (interacts with) 筠",
        "shared_interaction" : "interacts with",
        "name" : "爲 (interacts with) 筠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "677",
        "source" : "379",
        "target" : "457",
        "shared_name" : "常 (interacts with) 視",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 視",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "676",
        "source" : "379",
        "target" : "431",
        "shared_name" : "常 (interacts with) 署",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 署",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "675",
        "source" : "379",
        "target" : "124",
        "shared_name" : "常 (interacts with) 寔",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 寔",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "674",
        "source" : "379",
        "target" : "191",
        "shared_name" : "常 (interacts with) 殖",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 殖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "673",
        "source" : "379",
        "target" : "388",
        "shared_name" : "常 (interacts with) 植",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 植",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "672",
        "source" : "378",
        "target" : "477",
        "shared_name" : "詳 (interacts with) 旬",
        "shared_interaction" : "interacts with",
        "name" : "詳 (interacts with) 旬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "671",
        "source" : "378",
        "target" : "445",
        "shared_name" : "詳 (interacts with) 似",
        "shared_interaction" : "interacts with",
        "name" : "詳 (interacts with) 似",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "670",
        "source" : "377",
        "target" : "224",
        "shared_name" : "王 (interacts with) 雲",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 雲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "669",
        "source" : "377",
        "target" : "227",
        "shared_name" : "王 (interacts with) 云",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 云",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "668",
        "source" : "377",
        "target" : "537",
        "shared_name" : "王 (interacts with) 羽",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 羽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "667",
        "source" : "377",
        "target" : "440",
        "shared_name" : "王 (interacts with) 雨",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 雨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "source" : "374",
        "target" : "226",
        "shared_name" : "孚 (interacts with) 反",
        "shared_interaction" : "interacts with",
        "name" : "孚 (interacts with) 反",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "370",
        "target" : "351",
        "shared_name" : "蒲 (interacts with) 並",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 並",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "370",
        "target" : "404",
        "shared_name" : "蒲 (interacts with) 部",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 部",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "370",
        "target" : "243",
        "shared_name" : "蒲 (interacts with) 傍",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 傍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "source" : "370",
        "target" : "292",
        "shared_name" : "蒲 (interacts with) 僕",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 僕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "661",
        "source" : "369",
        "target" : "142",
        "shared_name" : "吐 (interacts with) 湯",
        "shared_interaction" : "interacts with",
        "name" : "吐 (interacts with) 湯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "660",
        "source" : "366",
        "target" : "548",
        "shared_name" : "多 (interacts with) 德",
        "shared_interaction" : "interacts with",
        "name" : "多 (interacts with) 德",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "659",
        "source" : "366",
        "target" : "335",
        "shared_name" : "多 (interacts with) 得",
        "shared_interaction" : "interacts with",
        "name" : "多 (interacts with) 得",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "658",
        "source" : "363",
        "target" : "414",
        "shared_name" : "在 (interacts with) 昨",
        "shared_interaction" : "interacts with",
        "name" : "在 (interacts with) 昨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "657",
        "source" : "357",
        "target" : "464",
        "shared_name" : "阻 (interacts with) 側",
        "shared_interaction" : "interacts with",
        "name" : "阻 (interacts with) 側",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "656",
        "source" : "350",
        "target" : "231",
        "shared_name" : "目 (interacts with) 眉",
        "shared_interaction" : "interacts with",
        "name" : "目 (interacts with) 眉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "655",
        "source" : "347",
        "target" : "303",
        "shared_name" : "蒼 (interacts with) 千",
        "shared_interaction" : "interacts with",
        "name" : "蒼 (interacts with) 千",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "654",
        "source" : "345",
        "target" : "483",
        "shared_name" : "諸 (interacts with) 章",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 章",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "653",
        "source" : "345",
        "target" : "141",
        "shared_name" : "諸 (interacts with) 征",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 征",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "652",
        "source" : "345",
        "target" : "327",
        "shared_name" : "諸 (interacts with) 正",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 正",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "651",
        "source" : "345",
        "target" : "449",
        "shared_name" : "諸 (interacts with) 止",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 止",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "650",
        "source" : "344",
        "target" : "466",
        "shared_name" : "張 (interacts with) 竹",
        "shared_interaction" : "interacts with",
        "name" : "張 (interacts with) 竹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "342",
        "target" : "116",
        "shared_name" : "卑 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "342",
        "target" : "385",
        "shared_name" : "卑 (interacts with) 必",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 必",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "647",
        "source" : "339",
        "target" : "318",
        "shared_name" : "于 (interacts with) 永",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 永",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "646",
        "source" : "339",
        "target" : "381",
        "shared_name" : "于 (interacts with) 爲",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 爲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "645",
        "source" : "339",
        "target" : "377",
        "shared_name" : "于 (interacts with) 王",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 王",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "644",
        "source" : "339",
        "target" : "202",
        "shared_name" : "于 (interacts with) 又",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 又",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "643",
        "source" : "336",
        "target" : "484",
        "shared_name" : "鉏 (interacts with) 士",
        "shared_interaction" : "interacts with",
        "name" : "鉏 (interacts with) 士",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "642",
        "source" : "336",
        "target" : "423",
        "shared_name" : "鉏 (interacts with) 仕",
        "shared_interaction" : "interacts with",
        "name" : "鉏 (interacts with) 仕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "641",
        "source" : "335",
        "target" : "366",
        "shared_name" : "得 (interacts with) 多",
        "shared_interaction" : "interacts with",
        "name" : "得 (interacts with) 多",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "640",
        "source" : "334",
        "target" : "521",
        "shared_name" : "託 (interacts with) 他",
        "shared_interaction" : "interacts with",
        "name" : "託 (interacts with) 他",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "639",
        "source" : "333",
        "target" : "367",
        "shared_name" : "諾 (interacts with) 那",
        "shared_interaction" : "interacts with",
        "name" : "諾 (interacts with) 那",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "638",
        "source" : "332",
        "target" : "73",
        "shared_name" : "虎 (interacts with) 呵",
        "shared_interaction" : "interacts with",
        "name" : "虎 (interacts with) 呵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "source" : "331",
        "target" : "411",
        "shared_name" : "滂 (interacts with) 普",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 普",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "source" : "331",
        "target" : "200",
        "shared_name" : "滂 (interacts with) 妃",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 妃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "635",
        "source" : "327",
        "target" : "345",
        "shared_name" : "正 (interacts with) 諸",
        "shared_interaction" : "interacts with",
        "name" : "正 (interacts with) 諸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "634",
        "source" : "326",
        "target" : "287",
        "shared_name" : "伯 (interacts with) 巴",
        "shared_interaction" : "interacts with",
        "name" : "伯 (interacts with) 巴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "633",
        "source" : "325",
        "target" : "455",
        "shared_name" : "初 (interacts with) 叉",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 叉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "632",
        "source" : "325",
        "target" : "256",
        "shared_name" : "初 (interacts with) 創",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 創",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "631",
        "source" : "325",
        "target" : "146",
        "shared_name" : "初 (interacts with) 瘡",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 瘡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "630",
        "source" : "325",
        "target" : "429",
        "shared_name" : "初 (interacts with) 測",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 測",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "629",
        "source" : "321",
        "target" : "359",
        "shared_name" : "色 (interacts with) 數",
        "shared_interaction" : "interacts with",
        "name" : "色 (interacts with) 數",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "628",
        "source" : "318",
        "target" : "269",
        "shared_name" : "永 (interacts with) 榮",
        "shared_interaction" : "interacts with",
        "name" : "永 (interacts with) 榮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "627",
        "source" : "317",
        "target" : "454",
        "shared_name" : "中 (interacts with) 丁",
        "shared_interaction" : "interacts with",
        "name" : "中 (interacts with) 丁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "626",
        "source" : "316",
        "target" : "68",
        "shared_name" : "余 (interacts with) 營",
        "shared_interaction" : "interacts with",
        "name" : "余 (interacts with) 營",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "625",
        "source" : "316",
        "target" : "448",
        "shared_name" : "余 (interacts with) 與",
        "shared_interaction" : "interacts with",
        "name" : "余 (interacts with) 與",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "624",
        "source" : "314",
        "target" : "415",
        "shared_name" : "桑 (interacts with) 素",
        "shared_interaction" : "interacts with",
        "name" : "桑 (interacts with) 素",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "623",
        "source" : "314",
        "target" : "305",
        "shared_name" : "桑 (interacts with) 速",
        "shared_interaction" : "interacts with",
        "name" : "桑 (interacts with) 速",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "622",
        "source" : "310",
        "target" : "270",
        "shared_name" : "虛 (interacts with) 興",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 興",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "621",
        "source" : "310",
        "target" : "450",
        "shared_name" : "虛 (interacts with) 喜",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 喜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "620",
        "source" : "310",
        "target" : "505",
        "shared_name" : "虛 (interacts with) 許",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 許",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "source" : "306",
        "target" : "259",
        "shared_name" : "縛 (interacts with) 浮",
        "shared_interaction" : "interacts with",
        "name" : "縛 (interacts with) 浮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "618",
        "source" : "299",
        "target" : "173",
        "shared_name" : "知 (interacts with) 柱",
        "shared_interaction" : "interacts with",
        "name" : "知 (interacts with) 柱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "617",
        "source" : "299",
        "target" : "344",
        "shared_name" : "知 (interacts with) 張",
        "shared_interaction" : "interacts with",
        "name" : "知 (interacts with) 張",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "source" : "292",
        "target" : "209",
        "shared_name" : "僕 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "僕 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "615",
        "source" : "291",
        "target" : "528",
        "shared_name" : "康 (interacts with) 苦",
        "shared_interaction" : "interacts with",
        "name" : "康 (interacts with) 苦",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "614",
        "source" : "290",
        "target" : "327",
        "shared_name" : "之 (interacts with) 正",
        "shared_interaction" : "interacts with",
        "name" : "之 (interacts with) 正",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "613",
        "source" : "290",
        "target" : "544",
        "shared_name" : "之 (interacts with) 職",
        "shared_interaction" : "interacts with",
        "name" : "之 (interacts with) 職",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "612",
        "source" : "289",
        "target" : "447",
        "shared_name" : "時 (interacts with) 市",
        "shared_interaction" : "interacts with",
        "name" : "時 (interacts with) 市",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "611",
        "source" : "286",
        "target" : "479",
        "shared_name" : "承 (interacts with) 是",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 是",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "610",
        "source" : "286",
        "target" : "298",
        "shared_name" : "承 (interacts with) 氏",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 氏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "609",
        "source" : "286",
        "target" : "457",
        "shared_name" : "承 (interacts with) 視",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 視",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "608",
        "source" : "285",
        "target" : "480",
        "shared_name" : "文 (interacts with) 靡",
        "shared_interaction" : "interacts with",
        "name" : "文 (interacts with) 靡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "607",
        "source" : "285",
        "target" : "473",
        "shared_name" : "文 (interacts with) 武",
        "shared_interaction" : "interacts with",
        "name" : "文 (interacts with) 武",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "606",
        "source" : "284",
        "target" : "169",
        "shared_name" : "過 (interacts with) 詭",
        "shared_interaction" : "interacts with",
        "name" : "過 (interacts with) 詭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "605",
        "source" : "283",
        "target" : "309",
        "shared_name" : "墟 (interacts with) 綺",
        "shared_interaction" : "interacts with",
        "name" : "墟 (interacts with) 綺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "604",
        "source" : "283",
        "target" : "337",
        "shared_name" : "墟 (interacts with) 起",
        "shared_interaction" : "interacts with",
        "name" : "墟 (interacts with) 起",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "603",
        "source" : "282",
        "target" : "481",
        "shared_name" : "韋 (interacts with) 薳",
        "shared_interaction" : "interacts with",
        "name" : "韋 (interacts with) 薳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "602",
        "source" : "281",
        "target" : "472",
        "shared_name" : "雌 (interacts with) 此",
        "shared_interaction" : "interacts with",
        "name" : "雌 (interacts with) 此",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "source" : "274",
        "target" : "126",
        "shared_name" : "便 (interacts with) 婢",
        "shared_interaction" : "interacts with",
        "name" : "便 (interacts with) 婢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "600",
        "source" : "273",
        "target" : "273",
        "shared_name" : "施 (interacts with) 施",
        "shared_interaction" : "interacts with",
        "name" : "施 (interacts with) 施",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "599",
        "source" : "273",
        "target" : "152",
        "shared_name" : "施 (interacts with) 釋",
        "shared_interaction" : "interacts with",
        "name" : "施 (interacts with) 釋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "598",
        "source" : "271",
        "target" : "113",
        "shared_name" : "神 (interacts with) 實",
        "shared_interaction" : "interacts with",
        "name" : "神 (interacts with) 實",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "597",
        "source" : "269",
        "target" : "456",
        "shared_name" : "榮 (interacts with) 洧",
        "shared_interaction" : "interacts with",
        "name" : "榮 (interacts with) 洧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "596",
        "source" : "265",
        "target" : "296",
        "shared_name" : "踈 (interacts with) 史",
        "shared_interaction" : "interacts with",
        "name" : "踈 (interacts with) 史",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "595",
        "source" : "265",
        "target" : "487",
        "shared_name" : "踈 (interacts with) 所",
        "shared_interaction" : "interacts with",
        "name" : "踈 (interacts with) 所",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "594",
        "source" : "264",
        "target" : "444",
        "shared_name" : "良 (interacts with) 里",
        "shared_interaction" : "interacts with",
        "name" : "良 (interacts with) 里",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "593",
        "source" : "262",
        "target" : "120",
        "shared_name" : "詩 (interacts with) 始",
        "shared_interaction" : "interacts with",
        "name" : "詩 (interacts with) 始",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "592",
        "source" : "261",
        "target" : "442",
        "shared_name" : "牀 (interacts with) 俟",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 俟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "591",
        "source" : "261",
        "target" : "336",
        "shared_name" : "牀 (interacts with) 鉏",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 鉏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "590",
        "source" : "261",
        "target" : "319",
        "shared_name" : "牀 (interacts with) 助",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 助",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "589",
        "source" : "260",
        "target" : "425",
        "shared_name" : "袪 (interacts with) 豈",
        "shared_interaction" : "interacts with",
        "name" : "袪 (interacts with) 豈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "588",
        "source" : "257",
        "target" : "502",
        "shared_name" : "尼 (interacts with) 女",
        "shared_interaction" : "interacts with",
        "name" : "尼 (interacts with) 女",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "587",
        "source" : "256",
        "target" : "492",
        "shared_name" : "創 (interacts with) 楚",
        "shared_interaction" : "interacts with",
        "name" : "創 (interacts with) 楚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "586",
        "source" : "255",
        "target" : "107",
        "shared_name" : "慈 (interacts with) 漸",
        "shared_interaction" : "interacts with",
        "name" : "慈 (interacts with) 漸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "585",
        "source" : "254",
        "target" : "535",
        "shared_name" : "羌 (interacts with) 去",
        "shared_interaction" : "interacts with",
        "name" : "羌 (interacts with) 去",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "584",
        "source" : "247",
        "target" : "517",
        "shared_name" : "疑 (interacts with) 五",
        "shared_interaction" : "interacts with",
        "name" : "疑 (interacts with) 五",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "source" : "246",
        "target" : "404",
        "shared_name" : "裴 (interacts with) 部",
        "shared_interaction" : "interacts with",
        "name" : "裴 (interacts with) 部",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "582",
        "source" : "244",
        "target" : "525",
        "shared_name" : "侯 (interacts with) 戸",
        "shared_interaction" : "interacts with",
        "name" : "侯 (interacts with) 戸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "243",
        "target" : "519",
        "shared_name" : "傍 (interacts with) 薄",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 薄",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "243",
        "target" : "294",
        "shared_name" : "傍 (interacts with) 白",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 白",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "579",
        "source" : "241",
        "target" : "491",
        "shared_name" : "補 (interacts with) 博",
        "shared_interaction" : "interacts with",
        "name" : "補 (interacts with) 博",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "233",
        "target" : "116",
        "shared_name" : "毗 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "毗 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "577",
        "source" : "227",
        "target" : "340",
        "shared_name" : "云 (interacts with) 有",
        "shared_interaction" : "interacts with",
        "name" : "云 (interacts with) 有",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "576",
        "source" : "214",
        "target" : "545",
        "shared_name" : "除 (interacts with) 直",
        "shared_interaction" : "interacts with",
        "name" : "除 (interacts with) 直",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "575",
        "source" : "208",
        "target" : "494",
        "shared_name" : "親 (interacts with) 七",
        "shared_interaction" : "interacts with",
        "name" : "親 (interacts with) 七",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "574",
        "source" : "207",
        "target" : "358",
        "shared_name" : "枯 (interacts with) 可",
        "shared_interaction" : "interacts with",
        "name" : "枯 (interacts with) 可",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "573",
        "source" : "204",
        "target" : "323",
        "shared_name" : "悉 (interacts with) 寫",
        "shared_interaction" : "interacts with",
        "name" : "悉 (interacts with) 寫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "572",
        "source" : "196",
        "target" : "347",
        "shared_name" : "麁 (interacts with) 蒼",
        "shared_interaction" : "interacts with",
        "name" : "麁 (interacts with) 蒼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "571",
        "source" : "187",
        "target" : "311",
        "shared_name" : "賞 (interacts with) 識",
        "shared_interaction" : "interacts with",
        "name" : "賞 (interacts with) 識",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "570",
        "source" : "187",
        "target" : "474",
        "shared_name" : "賞 (interacts with) 式",
        "shared_interaction" : "interacts with",
        "name" : "賞 (interacts with) 式",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "569",
        "source" : "172",
        "target" : "251",
        "shared_name" : "區 (interacts with) 驅",
        "shared_interaction" : "interacts with",
        "name" : "區 (interacts with) 驅",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "568",
        "source" : "158",
        "target" : "229",
        "shared_name" : "詰 (interacts with) 弃",
        "shared_interaction" : "interacts with",
        "name" : "詰 (interacts with) 弃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "567",
        "source" : "156",
        "target" : "362",
        "shared_name" : "資 (interacts with) 借",
        "shared_interaction" : "interacts with",
        "name" : "資 (interacts with) 借",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "566",
        "source" : "155",
        "target" : "501",
        "shared_name" : "秦 (interacts with) 疾",
        "shared_interaction" : "interacts with",
        "name" : "秦 (interacts with) 疾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "565",
        "source" : "150",
        "target" : "535",
        "shared_name" : "近 (interacts with) 去",
        "shared_interaction" : "interacts with",
        "name" : "近 (interacts with) 去",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "564",
        "source" : "147",
        "target" : "214",
        "shared_name" : "遟 (interacts with) 除",
        "shared_interaction" : "interacts with",
        "name" : "遟 (interacts with) 除",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "563",
        "source" : "146",
        "target" : "492",
        "shared_name" : "瘡 (interacts with) 楚",
        "shared_interaction" : "interacts with",
        "name" : "瘡 (interacts with) 楚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "562",
        "source" : "142",
        "target" : "369",
        "shared_name" : "湯 (interacts with) 吐",
        "shared_interaction" : "interacts with",
        "name" : "湯 (interacts with) 吐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "561",
        "source" : "133",
        "target" : "242",
        "shared_name" : "吾 (interacts with) 研",
        "shared_interaction" : "interacts with",
        "name" : "吾 (interacts with) 研",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "126",
        "target" : "274",
        "shared_name" : "婢 (interacts with) 便",
        "shared_interaction" : "interacts with",
        "name" : "婢 (interacts with) 便",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "559",
        "source" : "118",
        "target" : "88",
        "shared_name" : "巫 (interacts with) 望",
        "shared_interaction" : "interacts with",
        "name" : "巫 (interacts with) 望",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "558",
        "source" : "113",
        "target" : "64",
        "shared_name" : "實 (interacts with) 乗",
        "shared_interaction" : "interacts with",
        "name" : "實 (interacts with) 乗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "557",
        "source" : "110",
        "target" : "297",
        "shared_name" : "伊 (interacts with) 挹",
        "shared_interaction" : "interacts with",
        "name" : "伊 (interacts with) 挹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "source" : "96",
        "target" : "489",
        "shared_name" : "譬 (interacts with) 匹",
        "shared_interaction" : "interacts with",
        "name" : "譬 (interacts with) 匹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "94",
        "target" : "312",
        "shared_name" : "鄙 (interacts with) 筆",
        "shared_interaction" : "interacts with",
        "name" : "鄙 (interacts with) 筆",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "554",
        "source" : "74",
        "target" : "536",
        "shared_name" : "慕 (interacts with) 莫",
        "shared_interaction" : "interacts with",
        "name" : "慕 (interacts with) 莫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "553",
        "source" : "74",
        "target" : "122",
        "shared_name" : "慕 (interacts with) 摸",
        "shared_interaction" : "interacts with",
        "name" : "慕 (interacts with) 摸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "552",
        "source" : "72",
        "target" : "485",
        "shared_name" : "場 (interacts with) 宅",
        "shared_interaction" : "interacts with",
        "name" : "場 (interacts with) 宅",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "551",
        "source" : "66",
        "target" : "529",
        "shared_name" : "林 (interacts with) 力",
        "shared_interaction" : "interacts with",
        "name" : "林 (interacts with) 力",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "550",
        "source" : "65",
        "target" : "543",
        "shared_name" : "恥 (interacts with) 敕",
        "shared_interaction" : "interacts with",
        "name" : "恥 (interacts with) 敕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "549",
        "source" : "64",
        "target" : "387",
        "shared_name" : "乗 (interacts with) 食",
        "shared_interaction" : "interacts with",
        "name" : "乗 (interacts with) 食",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 549,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"guangyun.gml_1": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "guangyun.gml_1",
    "name" : "guangyun.gml_1",
    "SUID" : 2342,
    "__Annotations" : [ ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "2441",
        "shared_name" : "識2",
        "name" : "識2",
        "reading" : "ɕĭək",
        "SUID" : 2441,
        "label" : "識2",
        "selected" : false
      },
      "position" : {
        "x" : -804.0630806015438,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2440",
        "shared_name" : "植2",
        "name" : "植2",
        "reading" : "ʑĭək",
        "SUID" : 2440,
        "label" : "植2",
        "selected" : false
      },
      "position" : {
        "x" : 1985.9803976593257,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2439",
        "shared_name" : "食2",
        "name" : "食2",
        "reading" : "dʑʰĭək",
        "SUID" : 2439,
        "label" : "食2",
        "selected" : false
      },
      "position" : {
        "x" : -775.986993645022,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2438",
        "shared_name" : "借2",
        "name" : "借2",
        "reading" : "tsĭɛk",
        "SUID" : 2438,
        "label" : "借2",
        "selected" : false
      },
      "position" : {
        "x" : -1413.2967762537178,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2437",
        "shared_name" : "作3",
        "name" : "作3",
        "reading" : "tsɑk",
        "SUID" : 2437,
        "label" : "作3",
        "selected" : false
      },
      "position" : {
        "x" : -843.2967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2436",
        "shared_name" : "摸2",
        "name" : "摸2",
        "reading" : "mɑk",
        "SUID" : 2436,
        "label" : "摸2",
        "selected" : false
      },
      "position" : {
        "x" : 1808.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2435",
        "shared_name" : "比5",
        "name" : "比5",
        "reading" : "bʰĭĕt",
        "SUID" : 2435,
        "label" : "比5",
        "selected" : false
      },
      "position" : {
        "x" : -1495.0630806015438,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2434",
        "shared_name" : "占2",
        "name" : "占2",
        "reading" : "tɕĭɛm˩˥",
        "SUID" : 2434,
        "label" : "占2",
        "selected" : false
      },
      "position" : {
        "x" : 284.4369193984562,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2433",
        "shared_name" : "興2",
        "name" : "興2",
        "reading" : "xĭəŋ˩˥",
        "SUID" : 2433,
        "label" : "興2",
        "selected" : false
      },
      "position" : {
        "x" : 104.49126722454321,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2432",
        "shared_name" : "乗2",
        "name" : "乗2",
        "reading" : "dʑʰĭəŋ˩˥",
        "SUID" : 2432,
        "label" : "乗2",
        "selected" : false
      },
      "position" : {
        "x" : -870.986993645022,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2431",
        "shared_name" : "正2",
        "name" : "正2",
        "reading" : "tɕĭɛŋ˩˥",
        "SUID" : 2431,
        "label" : "正2",
        "selected" : false
      },
      "position" : {
        "x" : 428.1562010619723,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2430",
        "shared_name" : "湯3",
        "name" : "湯3",
        "reading" : "tʰɑŋ˩˥",
        "SUID" : 2430,
        "label" : "湯3",
        "selected" : false
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2429",
        "shared_name" : "當2",
        "name" : "當2",
        "reading" : "tɑŋ˩˥",
        "SUID" : 2429,
        "label" : "當2",
        "selected" : false
      },
      "position" : {
        "x" : 1235.4369193984562,
        "y" : -390.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2428",
        "shared_name" : "藏2",
        "name" : "藏2",
        "reading" : "dzʰɑŋ˩˥",
        "SUID" : 2428,
        "label" : "藏2",
        "selected" : false
      },
      "position" : {
        "x" : -1231.5630806015438,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2427",
        "shared_name" : "傍2",
        "name" : "傍2",
        "reading" : "bʰɑŋ˩˥",
        "SUID" : 2427,
        "label" : "傍2",
        "selected" : false
      },
      "position" : {
        "x" : -65.56308060154379,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2426",
        "shared_name" : "狂2",
        "name" : "狂2",
        "reading" : "gʰĭwaŋ˩˥",
        "SUID" : 2426,
        "label" : "狂2",
        "selected" : false
      },
      "position" : {
        "x" : 1251.4695280941082,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2425",
        "shared_name" : "王2",
        "name" : "王2",
        "reading" : "ĭwaŋ˩˥",
        "SUID" : 2425,
        "label" : "王2",
        "selected" : false
      },
      "position" : {
        "x" : -216.53047190589177,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2424",
        "shared_name" : "望2",
        "name" : "望2",
        "reading" : "mĭwaŋ˩˥",
        "SUID" : 2424,
        "label" : "望2",
        "selected" : false
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2423",
        "shared_name" : "張2",
        "name" : "張2",
        "reading" : "ţĭaŋ˩˥",
        "SUID" : 2423,
        "label" : "張2",
        "selected" : false
      },
      "position" : {
        "x" : 1425.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2422",
        "shared_name" : "呵2",
        "name" : "呵2",
        "reading" : "xɑ˩˥",
        "SUID" : 2422,
        "label" : "呵2",
        "selected" : false
      },
      "position" : {
        "x" : -1257.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2421",
        "shared_name" : "那2",
        "name" : "那2",
        "reading" : "nɑ˩˥",
        "SUID" : 2421,
        "label" : "那2",
        "selected" : false
      },
      "position" : {
        "x" : 967.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2420",
        "shared_name" : "作2",
        "name" : "作2",
        "reading" : "tsɑ˩˥",
        "SUID" : 2420,
        "label" : "作2",
        "selected" : false
      },
      "position" : {
        "x" : -938.2967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2419",
        "shared_name" : "便2",
        "name" : "便2",
        "reading" : "bʰĭɛn˩˥",
        "SUID" : 2419,
        "label" : "便2",
        "selected" : false
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : -971.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2418",
        "shared_name" : "偏2",
        "name" : "偏2",
        "reading" : "pʰĭɛn˩˥",
        "SUID" : 2418,
        "label" : "偏2",
        "selected" : false
      },
      "position" : {
        "x" : -920.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2417",
        "shared_name" : "近2",
        "name" : "近2",
        "reading" : "gʰĭən˩˥",
        "SUID" : 2417,
        "label" : "近2",
        "selected" : false
      },
      "position" : {
        "x" : 1393.9695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2416",
        "shared_name" : "分2",
        "name" : "分2",
        "reading" : "bʰĭuən˩˥",
        "SUID" : 2416,
        "label" : "分2",
        "selected" : false
      },
      "position" : {
        "x" : -946.041341471109,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2415",
        "shared_name" : "妃2",
        "name" : "妃2",
        "reading" : "pʰuɒi˩˥",
        "SUID" : 2415,
        "label" : "妃2",
        "selected" : false
      },
      "position" : {
        "x" : 1446.4369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2414",
        "shared_name" : "離3",
        "name" : "離3",
        "reading" : "liei˩˥",
        "SUID" : 2414,
        "label" : "離3",
        "selected" : false
      },
      "position" : {
        "x" : -1326.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2413",
        "shared_name" : "苦2",
        "name" : "苦2",
        "reading" : "kʰu˩˥",
        "SUID" : 2413,
        "label" : "苦2",
        "selected" : false
      },
      "position" : {
        "x" : 979.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2412",
        "shared_name" : "吐2",
        "name" : "吐2",
        "reading" : "tʰu˩˥",
        "SUID" : 2412,
        "label" : "吐2",
        "selected" : false
      },
      "position" : {
        "x" : -661.5630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2411",
        "shared_name" : "驅2",
        "name" : "驅2",
        "reading" : "kʰĭu˩˥",
        "SUID" : 2411,
        "label" : "驅2",
        "selected" : false
      },
      "position" : {
        "x" : 682.4369193984562,
        "y" : -971.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2410",
        "shared_name" : "數2",
        "name" : "數2",
        "reading" : "ʃĭu˩˥",
        "SUID" : 2410,
        "label" : "數2",
        "selected" : false
      },
      "position" : {
        "x" : 1955.4369193984562,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2409",
        "shared_name" : "楚2",
        "name" : "楚2",
        "reading" : "ʧʰĭo˩˥",
        "SUID" : 2409,
        "label" : "楚2",
        "selected" : false
      },
      "position" : {
        "x" : 494.4369193984562,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2408",
        "shared_name" : "與3",
        "name" : "與3",
        "reading" : "jĭo˩˥",
        "SUID" : 2408,
        "label" : "與3",
        "selected" : false
      },
      "position" : {
        "x" : -728.486993645022,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2407",
        "shared_name" : "阻2",
        "name" : "阻2",
        "reading" : "ʧĭo˩˥",
        "SUID" : 2407,
        "label" : "阻2",
        "selected" : false
      },
      "position" : {
        "x" : -730.5630806015438,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2406",
        "shared_name" : "除2",
        "name" : "除2",
        "reading" : "ɖʰĭo˩˥",
        "SUID" : 2406,
        "label" : "除2",
        "selected" : false
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2405",
        "shared_name" : "去2",
        "name" : "去2",
        "reading" : "kʰĭo˩˥",
        "SUID" : 2405,
        "label" : "去2",
        "selected" : false
      },
      "position" : {
        "x" : 860.4369193984562,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2404",
        "shared_name" : "語2",
        "name" : "語2",
        "reading" : "ŋĭo˩˥",
        "SUID" : 2404,
        "label" : "語2",
        "selected" : false
      },
      "position" : {
        "x" : 971.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2403",
        "shared_name" : "思2",
        "name" : "思2",
        "reading" : "sĭə˩˥",
        "SUID" : 2403,
        "label" : "思2",
        "selected" : false
      },
      "position" : {
        "x" : -31.041341471109035,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2402",
        "shared_name" : "比4",
        "name" : "比4",
        "reading" : "pi˩˥",
        "SUID" : 2402,
        "label" : "比4",
        "selected" : false
      },
      "position" : {
        "x" : 55.43691939845621,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2401",
        "shared_name" : "比3",
        "name" : "比3",
        "reading" : "bʰi˩˥",
        "SUID" : 2401,
        "label" : "比3",
        "selected" : false
      },
      "position" : {
        "x" : -1590.0630806015438,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2400",
        "shared_name" : "視2",
        "name" : "視2",
        "reading" : "ʑi˩˥",
        "SUID" : 2400,
        "label" : "視2",
        "selected" : false
      },
      "position" : {
        "x" : 1605.9803976593257,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2399",
        "shared_name" : "施2",
        "name" : "施2",
        "reading" : "ɕĭe˩˥",
        "SUID" : 2399,
        "label" : "施2",
        "selected" : false
      },
      "position" : {
        "x" : -1041.5630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2398",
        "shared_name" : "爲2",
        "name" : "爲2",
        "reading" : "ĭwe˩˥",
        "SUID" : 2398,
        "label" : "爲2",
        "selected" : false
      },
      "position" : {
        "x" : -311.5304719058918,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2397",
        "shared_name" : "離2",
        "name" : "離2",
        "reading" : "lĭe˩˥",
        "SUID" : 2397,
        "label" : "離2",
        "selected" : false
      },
      "position" : {
        "x" : -254.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2396",
        "shared_name" : "封2",
        "name" : "封2",
        "reading" : "pĭwoŋ˩˥",
        "SUID" : 2396,
        "label" : "封2",
        "selected" : false
      },
      "position" : {
        "x" : 26.023875920195223,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2395",
        "shared_name" : "漸2",
        "name" : "漸2",
        "reading" : "dzʰĭɛm˥",
        "SUID" : 2395,
        "label" : "漸2",
        "selected" : false
      },
      "position" : {
        "x" : -133.5630806015438,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2394",
        "shared_name" : "取2",
        "name" : "取2",
        "reading" : "tsʰəu˥",
        "SUID" : 2394,
        "label" : "取2",
        "selected" : false
      },
      "position" : {
        "x" : 1898.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2393",
        "shared_name" : "部2",
        "name" : "部2",
        "reading" : "bʰəu˥",
        "SUID" : 2393,
        "label" : "部2",
        "selected" : false
      },
      "position" : {
        "x" : -160.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2392",
        "shared_name" : "蒼2",
        "name" : "蒼2",
        "reading" : "tsʰɑŋ˥",
        "SUID" : 2392,
        "label" : "蒼2",
        "selected" : false
      },
      "position" : {
        "x" : 1708.9803976593257,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2391",
        "shared_name" : "反2",
        "name" : "反2",
        "reading" : "pĭwɐn˥",
        "SUID" : 2391,
        "label" : "反2",
        "selected" : false
      },
      "position" : {
        "x" : -64.51960234067428,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2390",
        "shared_name" : "楷2",
        "name" : "楷2",
        "reading" : "kʰɐi˥",
        "SUID" : 2390,
        "label" : "楷2",
        "selected" : false
      },
      "position" : {
        "x" : 789.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2389",
        "shared_name" : "楮2",
        "name" : "楮2",
        "reading" : "tu˥",
        "SUID" : 2389,
        "label" : "楮2",
        "selected" : false
      },
      "position" : {
        "x" : 1325.9369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2388",
        "shared_name" : "土2",
        "name" : "土2",
        "reading" : "dʰu˥",
        "SUID" : 2388,
        "label" : "土2",
        "selected" : false
      },
      "position" : {
        "x" : 2137.436919398456,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2387",
        "shared_name" : "柱2",
        "name" : "柱2",
        "reading" : "ţĭu˥",
        "SUID" : 2387,
        "label" : "柱2",
        "selected" : false
      },
      "position" : {
        "x" : 1330.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2386",
        "shared_name" : "父2",
        "name" : "父2",
        "reading" : "bʰĭu˥",
        "SUID" : 2386,
        "label" : "父2",
        "selected" : false
      },
      "position" : {
        "x" : -1041.041341471109,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2385",
        "shared_name" : "鉏2",
        "name" : "鉏2",
        "reading" : "dʒʰĭo˥",
        "SUID" : 2385,
        "label" : "鉏2",
        "selected" : false
      },
      "position" : {
        "x" : -877.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2384",
        "shared_name" : "胥2",
        "name" : "胥2",
        "reading" : "sĭo˥",
        "SUID" : 2384,
        "label" : "胥2",
        "selected" : false
      },
      "position" : {
        "x" : -627.5630806015438,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2383",
        "shared_name" : "與2",
        "name" : "與2",
        "reading" : "jĭo˥",
        "SUID" : 2383,
        "label" : "與2",
        "selected" : false
      },
      "position" : {
        "x" : -1685.0630806015438,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2382",
        "shared_name" : "俟2",
        "name" : "俟2",
        "reading" : "dʐʰĭə˥",
        "SUID" : 2382,
        "label" : "俟2",
        "selected" : false
      },
      "position" : {
        "x" : -972.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2381",
        "shared_name" : "比2",
        "name" : "比2",
        "reading" : "pi˥",
        "SUID" : 2381,
        "label" : "比2",
        "selected" : false
      },
      "position" : {
        "x" : -134.5630806015438,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2380",
        "shared_name" : "跪2",
        "name" : "跪2",
        "reading" : "gʰĭwe˥",
        "SUID" : 2380,
        "label" : "跪2",
        "selected" : false
      },
      "position" : {
        "x" : 1156.4695280941082,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2379",
        "shared_name" : "披2",
        "name" : "披2",
        "reading" : "pʰĭe˥",
        "SUID" : 2379,
        "label" : "披2",
        "selected" : false
      },
      "position" : {
        "x" : -1110.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2378",
        "shared_name" : "氏3",
        "name" : "氏3",
        "reading" : "ʑĭe˥",
        "SUID" : 2378,
        "label" : "氏3",
        "selected" : false
      },
      "position" : {
        "x" : 1700.9803976593257,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2377",
        "shared_name" : "平3",
        "name" : "平3",
        "reading" : "pʰĭwɐm˥˩",
        "SUID" : 2377,
        "label" : "平3",
        "selected" : false
      },
      "position" : {
        "x" : 29.43691939845621,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2376",
        "shared_name" : "簪2",
        "name" : "簪2",
        "reading" : "tsɒm˥˩",
        "SUID" : 2376,
        "label" : "簪2",
        "selected" : false
      },
      "position" : {
        "x" : -1128.2967762537178,
        "y" : -390.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2375",
        "shared_name" : "區2",
        "name" : "區2",
        "reading" : "ʔəu˥˩",
        "SUID" : 2375,
        "label" : "區2",
        "selected" : false
      },
      "position" : {
        "x" : 1212.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2374",
        "shared_name" : "馮2",
        "name" : "馮2",
        "reading" : "bʰĭəŋ˩",
        "SUID" : 2374,
        "label" : "馮2",
        "selected" : false
      },
      "position" : {
        "x" : -1136.041341471109,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2373",
        "shared_name" : "丁2",
        "name" : "丁2",
        "reading" : "tieŋ˥˩",
        "SUID" : 2373,
        "label" : "丁2",
        "selected" : false
      },
      "position" : {
        "x" : 1230.9369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2372",
        "shared_name" : "氏2",
        "name" : "氏2",
        "reading" : "tsĭɛŋ˥˩",
        "SUID" : 2372,
        "label" : "氏2",
        "selected" : false
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2371",
        "shared_name" : "平2",
        "name" : "平2",
        "reading" : "bʰĭɐŋ˩",
        "SUID" : 2371,
        "label" : "平2",
        "selected" : false
      },
      "position" : {
        "x" : 86.31570011679264,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2370",
        "shared_name" : "房2",
        "name" : "房2",
        "reading" : "bʰɑŋ˩",
        "SUID" : 2370,
        "label" : "房2",
        "selected" : false
      },
      "position" : {
        "x" : 277.9695280941082,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2369",
        "shared_name" : "湯2",
        "name" : "湯2",
        "reading" : "tʰɑŋ˥˩",
        "SUID" : 2369,
        "label" : "湯2",
        "selected" : false
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2368",
        "shared_name" : "方2",
        "name" : "方2",
        "reading" : "pĭwaŋ˥˩",
        "SUID" : 2368,
        "label" : "方2",
        "selected" : false
      },
      "position" : {
        "x" : -254.51960234067428,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2367",
        "shared_name" : "詳2",
        "name" : "詳2",
        "reading" : "zĭaŋ˩",
        "SUID" : 2367,
        "label" : "詳2",
        "selected" : false
      },
      "position" : {
        "x" : -1199.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2366",
        "shared_name" : "余2",
        "name" : "余2",
        "reading" : "ʑĭa˩",
        "SUID" : 2366,
        "label" : "余2",
        "selected" : false
      },
      "position" : {
        "x" : 1795.9803976593257,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2365",
        "shared_name" : "叉2",
        "name" : "叉2",
        "reading" : "ʧʰa˥˩",
        "SUID" : 2365,
        "label" : "叉2",
        "selected" : false
      },
      "position" : {
        "x" : 399.4369193984562,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2364",
        "shared_name" : "諸2",
        "name" : "諸2",
        "reading" : "tɕĭa˥˩",
        "SUID" : 2364,
        "label" : "諸2",
        "selected" : false
      },
      "position" : {
        "x" : 390.4695280941082,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2363",
        "shared_name" : "池2",
        "name" : "池2",
        "reading" : "dʰɑ˩",
        "SUID" : 2363,
        "label" : "池2",
        "selected" : false
      },
      "position" : {
        "x" : 1757.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2362",
        "shared_name" : "烟2",
        "name" : "烟2",
        "reading" : "ʔien˥˩",
        "SUID" : 2362,
        "label" : "烟2",
        "selected" : false
      },
      "position" : {
        "x" : 1117.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2361",
        "shared_name" : "頻2",
        "name" : "頻2",
        "reading" : "dzʰæn˩",
        "SUID" : 2361,
        "label" : "頻2",
        "selected" : false
      },
      "position" : {
        "x" : 182.96952809410823,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2360",
        "shared_name" : "眉2",
        "name" : "眉2",
        "reading" : "dzʰæn˩",
        "SUID" : 2360,
        "label" : "眉2",
        "selected" : false
      },
      "position" : {
        "x" : 1903.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2359",
        "shared_name" : "台2",
        "name" : "台2",
        "reading" : "tʰɒi˥˩",
        "SUID" : 2359,
        "label" : "台2",
        "selected" : false
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2358",
        "shared_name" : "裴2",
        "name" : "裴2",
        "reading" : "bʰuɒi˩",
        "SUID" : 2358,
        "label" : "裴2",
        "selected" : false
      },
      "position" : {
        "x" : 40.46952809410823,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2357",
        "shared_name" : "兒2",
        "name" : "兒2",
        "reading" : "ŋiei˩",
        "SUID" : 2357,
        "label" : "兒2",
        "selected" : false
      },
      "position" : {
        "x" : 470.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2356",
        "shared_name" : "於2",
        "name" : "於2",
        "reading" : "ʔu˥˩",
        "SUID" : 2356,
        "label" : "於2",
        "selected" : false
      },
      "position" : {
        "x" : 927.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2355",
        "shared_name" : "扶2",
        "name" : "扶2",
        "reading" : "pĭu˥˩",
        "SUID" : 2355,
        "label" : "扶2",
        "selected" : false
      },
      "position" : {
        "x" : -729.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2354",
        "shared_name" : "兹2",
        "name" : "兹2",
        "reading" : "tsĭə˥˩",
        "SUID" : 2354,
        "label" : "兹2",
        "selected" : false
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2353",
        "shared_name" : "其2",
        "name" : "其2",
        "reading" : "kĭə˥˩",
        "SUID" : 2353,
        "label" : "其2",
        "selected" : false
      },
      "position" : {
        "x" : 927.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2352",
        "shared_name" : "穠2",
        "name" : "穠2",
        "reading" : "nʑĭwoŋ˩",
        "SUID" : 2352,
        "label" : "穠2",
        "selected" : false
      },
      "position" : {
        "x" : 367.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "62",
        "shared_name" : "筠",
        "color" : "#96c864",
        "name" : "筠",
        "reading" : "ĭwĕn˩",
        "SUID" : 62,
        "label" : "筠",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -607.5630806015438,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "63",
        "shared_name" : "愛",
        "color" : "#96c864",
        "name" : "愛",
        "reading" : "ʔɒi˩˥",
        "SUID" : 63,
        "label" : "愛",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1307.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "64",
        "shared_name" : "乗",
        "color" : "#6496c8",
        "name" : "乗",
        "reading" : "dʑʰĭəŋ˩",
        "SUID" : 64,
        "label" : "乗",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -775.986993645022,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "65",
        "shared_name" : "恥",
        "color" : "#9664c8",
        "name" : "恥",
        "reading" : "ţʰĭə˥",
        "SUID" : 65,
        "label" : "恥",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 534.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "66",
        "shared_name" : "林",
        "color" : "#6464c8",
        "name" : "林",
        "reading" : "lĭĕm˩",
        "SUID" : 66,
        "label" : "林",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -539.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "67",
        "shared_name" : "前",
        "color" : "#c89664",
        "name" : "前",
        "reading" : "dzʰien˩",
        "SUID" : 67,
        "label" : "前",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -1041.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "68",
        "shared_name" : "營",
        "color" : "#c86464",
        "name" : "營",
        "reading" : "jĭwɛŋ˩",
        "SUID" : 68,
        "label" : "營",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1780.0630806015438,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "69",
        "shared_name" : "簪",
        "color" : "#9664c8",
        "name" : "簪",
        "reading" : "ʧĭĕm˥˩",
        "SUID" : 69,
        "label" : "簪",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -445.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "70",
        "shared_name" : "楷",
        "color" : "#c89664",
        "name" : "楷",
        "reading" : "kɐi˥˩",
        "SUID" : 70,
        "label" : "楷",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : -376.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "弼",
        "color" : "#c8c864",
        "name" : "弼",
        "reading" : "bʰĭĕt",
        "SUID" : 71,
        "label" : "弼",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1162.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "72",
        "shared_name" : "場",
        "color" : "#9664c8",
        "name" : "場",
        "reading" : "ɖʰĭaŋ˩",
        "SUID" : 72,
        "label" : "場",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1257.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "73",
        "shared_name" : "呵",
        "color" : "#c89664",
        "name" : "呵",
        "reading" : "xɑ˥˩",
        "SUID" : 73,
        "label" : "呵",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "74",
        "shared_name" : "慕",
        "color" : "#64c896",
        "name" : "慕",
        "reading" : "mu˩˥",
        "SUID" : 74,
        "label" : "慕",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1808.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "75",
        "shared_name" : "具",
        "color" : "#c89664",
        "name" : "具",
        "reading" : "gʰĭu˩˥",
        "SUID" : 75,
        "label" : "具",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1050.4369193984562,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "76",
        "shared_name" : "憂",
        "color" : "#96c864",
        "name" : "憂",
        "reading" : "ʔĭəu˥˩",
        "SUID" : 76,
        "label" : "憂",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1390.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "77",
        "shared_name" : "離",
        "color" : "#6464c8",
        "name" : "離",
        "reading" : "lĭe˩",
        "SUID" : 77,
        "label" : "離",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -492.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "78",
        "shared_name" : "寺",
        "color" : "#6496c8",
        "name" : "寺",
        "reading" : "zĭə˩˥",
        "SUID" : 78,
        "label" : "寺",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1151.5304719058915,
        "y" : -1552.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "79",
        "shared_name" : "厠",
        "color" : "",
        "name" : "厠",
        "reading" : "",
        "SUID" : 79,
        "label" : "厠",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -151.5630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "80",
        "shared_name" : "傾",
        "color" : "#c89664",
        "name" : "傾",
        "reading" : "kʰĭwɛŋ˥˩",
        "SUID" : 80,
        "label" : "傾",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1014.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "81",
        "shared_name" : "情",
        "color" : "#c89664",
        "name" : "情",
        "reading" : "dzʰĭɛŋ˩",
        "SUID" : 81,
        "label" : "情",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : 56.43691939845621,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "82",
        "shared_name" : "練",
        "color" : "#6464c8",
        "name" : "練",
        "reading" : "lien˩˥",
        "SUID" : 82,
        "label" : "練",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : -1231.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "83",
        "shared_name" : "查",
        "color" : "",
        "name" : "查",
        "reading" : "",
        "SUID" : 83,
        "label" : "查",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : -30.56308060154379,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "84",
        "shared_name" : "百",
        "color" : "#c8c864",
        "name" : "百",
        "reading" : "pɐk",
        "SUID" : 84,
        "label" : "百",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -661.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "85",
        "shared_name" : "鄒",
        "color" : "#9664c8",
        "name" : "鄒",
        "reading" : "ʧĭəu˥˩",
        "SUID" : 85,
        "label" : "鄒",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -540.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "86",
        "shared_name" : "陀",
        "color" : "#9664c8",
        "name" : "陀",
        "reading" : "dʰɑ˩",
        "SUID" : 86,
        "label" : "陀",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 1662.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "shared_name" : "拂",
        "color" : "#c8c864",
        "name" : "拂",
        "reading" : "pʰĭuət",
        "SUID" : 87,
        "label" : "拂",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1330.4978632102395,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "88",
        "shared_name" : "望",
        "color" : "#64c896",
        "name" : "望",
        "reading" : "mĭwaŋ˩",
        "SUID" : 88,
        "label" : "望",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "89",
        "shared_name" : "衢",
        "color" : "#c89664",
        "name" : "衢",
        "reading" : "gʰĭu˩",
        "SUID" : 89,
        "label" : "衢",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 765.4369193984562,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "90",
        "shared_name" : "崱",
        "color" : "#9664c8",
        "name" : "崱",
        "reading" : "dʒʰĭək",
        "SUID" : 90,
        "label" : "崱",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -755.541341471109,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "91",
        "shared_name" : "辛",
        "color" : "#6496c8",
        "name" : "辛",
        "reading" : "sĭĕn˥˩",
        "SUID" : 91,
        "label" : "辛",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -247.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "92",
        "shared_name" : "羲",
        "color" : "#c89664",
        "name" : "羲",
        "reading" : "xĭe˥˩",
        "SUID" : 92,
        "label" : "羲",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -370.5087327754568,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "93",
        "shared_name" : "徵",
        "color" : "#9664c8",
        "name" : "徵",
        "reading" : "ţĭə˥",
        "SUID" : 93,
        "label" : "徵",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1947.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "鄙",
        "color" : "#c8c864",
        "name" : "鄙",
        "reading" : "pi˥",
        "SUID" : 94,
        "label" : "鄙",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -824.5196023406743,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "95",
        "shared_name" : "美",
        "color" : "#64c896",
        "name" : "美",
        "reading" : "mi˥",
        "SUID" : 95,
        "label" : "美",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1483.4722252140202,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "shared_name" : "譬",
        "color" : "#c8c864",
        "name" : "譬",
        "reading" : "pʰĭe˩˥",
        "SUID" : 96,
        "label" : "譬",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1015.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "shared_name" : "封",
        "color" : "#c8c864",
        "name" : "封",
        "reading" : "pĭwoŋ˥˩",
        "SUID" : 97,
        "label" : "封",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -444.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "98",
        "shared_name" : "內",
        "color" : "",
        "name" : "內",
        "reading" : "",
        "SUID" : 98,
        "label" : "內",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 90.43691939845621,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "99",
        "shared_name" : "冬",
        "color" : "#9664c8",
        "name" : "冬",
        "reading" : "tuoŋ˥˩",
        "SUID" : 99,
        "label" : "冬",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 1183.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "100",
        "shared_name" : "殊",
        "color" : "#9664c8",
        "name" : "殊",
        "reading" : "ʑĭu˩",
        "SUID" : 100,
        "label" : "殊",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1610.4369193984562,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "101",
        "shared_name" : "班",
        "color" : "#c8c864",
        "name" : "班",
        "reading" : "pan˥˩",
        "SUID" : 101,
        "label" : "班",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -994.0630806015438,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "賔",
        "color" : "#c8c864",
        "name" : "賔",
        "reading" : "pĭĕn˥˩",
        "SUID" : 102,
        "label" : "賔",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -229.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "103",
        "shared_name" : "音",
        "color" : "#96c864",
        "name" : "音",
        "reading" : "ʔĭĕm˥˩",
        "SUID" : 103,
        "label" : "音",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1485.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "104",
        "shared_name" : "格",
        "color" : "#c89664",
        "name" : "格",
        "reading" : "kɐk",
        "SUID" : 104,
        "label" : "格",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 193.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "105",
        "shared_name" : "玉",
        "color" : "#64c8c8",
        "name" : "玉",
        "reading" : "ŋĭwok",
        "SUID" : 105,
        "label" : "玉",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 876.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "106",
        "shared_name" : "佇",
        "color" : "#9664c8",
        "name" : "佇",
        "reading" : "ɖʰĭo˥",
        "SUID" : 106,
        "label" : "佇",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1162.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "107",
        "shared_name" : "漸",
        "color" : "#c89664",
        "name" : "漸",
        "reading" : "tsĭɛm˥˩",
        "SUID" : 107,
        "label" : "漸",
        "community" : 34,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "108",
        "shared_name" : "紀",
        "color" : "#c89664",
        "name" : "紀",
        "reading" : "kĭə˥",
        "SUID" : 108,
        "label" : "紀",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1117.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "109",
        "shared_name" : "冝",
        "color" : "",
        "name" : "冝",
        "reading" : "",
        "SUID" : 109,
        "label" : "冝",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 211.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "110",
        "shared_name" : "伊",
        "color" : "#96c864",
        "name" : "伊",
        "reading" : "ʔi˥˩",
        "SUID" : 110,
        "label" : "伊",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 915.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "111",
        "shared_name" : "台",
        "color" : "#9664c8",
        "name" : "台",
        "reading" : "jĭə˩",
        "SUID" : 111,
        "label" : "台",
        "community" : 31,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : -1590.0630806015438,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "shared_name" : "父",
        "color" : "#c8c864",
        "name" : "父",
        "reading" : "pĭu˥",
        "SUID" : 112,
        "label" : "父",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -68.97612407980478,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "113",
        "shared_name" : "實",
        "color" : "#6496c8",
        "name" : "實",
        "reading" : "dʑʰĭĕt",
        "SUID" : 113,
        "label" : "實",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -870.986993645022,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "shared_name" : "𢌿",
        "color" : "#c8c864",
        "name" : "𢌿",
        "reading" : "pi˩˥",
        "SUID" : 114,
        "label" : "𢌿",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -39.56308060154379,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "115",
        "shared_name" : "鷖",
        "color" : "#96c864",
        "name" : "鷖",
        "reading" : "ʔiei˥˩",
        "SUID" : 115,
        "label" : "鷖",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 832.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "shared_name" : "比",
        "color" : "#c8c864",
        "name" : "比",
        "reading" : "bʰi˩",
        "SUID" : 116,
        "label" : "比",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "117",
        "shared_name" : "猪",
        "color" : "#9664c8",
        "name" : "猪",
        "reading" : "ţĭo˥˩",
        "SUID" : 117,
        "label" : "猪",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1662.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "118",
        "shared_name" : "巫",
        "color" : "#64c896",
        "name" : "巫",
        "reading" : "mĭu˩",
        "SUID" : 118,
        "label" : "巫",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "119",
        "shared_name" : "遷",
        "color" : "#9664c8",
        "name" : "遷",
        "reading" : "tsʰĭɛn˥˩",
        "SUID" : 119,
        "label" : "遷",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 1618.4369193984562,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "120",
        "shared_name" : "始",
        "color" : "#6496c8",
        "name" : "始",
        "reading" : "ɕĭə˥",
        "SUID" : 120,
        "label" : "始",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -899.0630806015438,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "121",
        "shared_name" : "司",
        "color" : "#6496c8",
        "name" : "司",
        "reading" : "sĭə˥˩",
        "SUID" : 121,
        "label" : "司",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -342.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "122",
        "shared_name" : "摸",
        "color" : "#64c896",
        "name" : "摸",
        "reading" : "mu˩",
        "SUID" : 122,
        "label" : "摸",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1523.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "123",
        "shared_name" : "唐",
        "color" : "#9664c8",
        "name" : "唐",
        "reading" : "dʰɑŋ˩",
        "SUID" : 123,
        "label" : "唐",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 1852.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "124",
        "shared_name" : "寔",
        "color" : "#9664c8",
        "name" : "寔",
        "reading" : "ʑĭək",
        "SUID" : 124,
        "label" : "寔",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1795.9803976593257,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "125",
        "shared_name" : "連",
        "color" : "#6464c8",
        "name" : "連",
        "reading" : "lĭɛn˩",
        "SUID" : 125,
        "label" : "連",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -634.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "shared_name" : "婢",
        "color" : "#c8c864",
        "name" : "婢",
        "reading" : "bʰĭe˥",
        "SUID" : 126,
        "label" : "婢",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "127",
        "shared_name" : "吉",
        "color" : "#c89664",
        "name" : "吉",
        "reading" : "kĭĕt",
        "SUID" : 127,
        "label" : "吉",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1402.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "128",
        "shared_name" : "堂",
        "color" : "#9664c8",
        "name" : "堂",
        "reading" : "dʰɑŋ˩",
        "SUID" : 128,
        "label" : "堂",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 1947.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "129",
        "shared_name" : "晡",
        "color" : "#c8c864",
        "name" : "晡",
        "reading" : "pu˥˩",
        "SUID" : 129,
        "label" : "晡",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -1136.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "130",
        "shared_name" : "生",
        "color" : "#6496c8",
        "name" : "生",
        "reading" : "ʃɐŋ˩˥",
        "SUID" : 130,
        "label" : "生",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1765.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "131",
        "shared_name" : "通",
        "color" : "#9664c8",
        "name" : "通",
        "reading" : "tʰuŋ˥˩",
        "SUID" : 131,
        "label" : "通",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "132",
        "shared_name" : "臼",
        "color" : "#c89664",
        "name" : "臼",
        "reading" : "gʰĭəu˥",
        "SUID" : 132,
        "label" : "臼",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 955.4369193984562,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "133",
        "shared_name" : "吾",
        "color" : "#64c8c8",
        "name" : "吾",
        "reading" : "ŋa˩",
        "SUID" : 133,
        "label" : "吾",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : 375.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "134",
        "shared_name" : "辭",
        "color" : "#6496c8",
        "name" : "辭",
        "reading" : "zĭə˩",
        "SUID" : 134,
        "label" : "辭",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1484.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "135",
        "shared_name" : "試",
        "color" : "#6496c8",
        "name" : "試",
        "reading" : "ɕĭə˩˥",
        "SUID" : 135,
        "label" : "試",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -471.5630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "136",
        "shared_name" : "海",
        "color" : "#c89664",
        "name" : "海",
        "reading" : "xɒi˥",
        "SUID" : 136,
        "label" : "海",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "137",
        "shared_name" : "犲",
        "color" : "",
        "name" : "犲",
        "reading" : "",
        "SUID" : 137,
        "label" : "犲",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 332.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "138",
        "shared_name" : "麤",
        "color" : "#9664c8",
        "name" : "麤",
        "reading" : "tsʰu˥˩",
        "SUID" : 138,
        "label" : "麤",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1613.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "139",
        "shared_name" : "黃",
        "color" : "#96c864",
        "name" : "黃",
        "reading" : "ɣuɑŋ˩",
        "SUID" : 139,
        "label" : "黃",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 320.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "140",
        "shared_name" : "嘗",
        "color" : "#9664c8",
        "name" : "嘗",
        "reading" : "ʑĭaŋ˩",
        "SUID" : 140,
        "label" : "嘗",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1981.5238759201952,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "141",
        "shared_name" : "征",
        "color" : "#9664c8",
        "name" : "征",
        "reading" : "tɕĭɛŋ˥˩",
        "SUID" : 141,
        "label" : "征",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 295.4695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "142",
        "shared_name" : "湯",
        "color" : "#9664c8",
        "name" : "湯",
        "reading" : "ɕĭaŋ˥˩",
        "SUID" : 142,
        "label" : "湯",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -661.5630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "143",
        "shared_name" : "洛",
        "color" : "#6464c8",
        "name" : "洛",
        "reading" : "lɑk",
        "SUID" : 143,
        "label" : "洛",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 318.9369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "144",
        "shared_name" : "芻",
        "color" : "#9664c8",
        "name" : "芻",
        "reading" : "ʧʰĭu˥˩",
        "SUID" : 144,
        "label" : "芻",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 589.4369193984562,
        "y" : 190.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "145",
        "shared_name" : "抽",
        "color" : "#9664c8",
        "name" : "抽",
        "reading" : "ţʰĭəu˥˩",
        "SUID" : 145,
        "label" : "抽",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 655.9586585288912,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "146",
        "shared_name" : "瘡",
        "color" : "#9664c8",
        "name" : "瘡",
        "reading" : "ʧʰĭaŋ˥˩",
        "SUID" : 146,
        "label" : "瘡",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 494.4369193984562,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "147",
        "shared_name" : "遟",
        "color" : "#9664c8",
        "name" : "遟",
        "reading" : "ɖʰi˩˥",
        "SUID" : 147,
        "label" : "遟",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "148",
        "shared_name" : "依",
        "color" : "#96c864",
        "name" : "依",
        "reading" : "ʔĭəi˥˩",
        "SUID" : 148,
        "label" : "依",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1010.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "149",
        "shared_name" : "商",
        "color" : "#6496c8",
        "name" : "商",
        "reading" : "ɕĭaŋ˥˩",
        "SUID" : 149,
        "label" : "商",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -899.0630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "150",
        "shared_name" : "近",
        "color" : "#c89664",
        "name" : "近",
        "reading" : "gʰĭən˥",
        "SUID" : 150,
        "label" : "近",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 860.4369193984562,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "151",
        "shared_name" : "仍",
        "color" : "#64c8c8",
        "name" : "仍",
        "reading" : "nʑĭəŋ˩",
        "SUID" : 151,
        "label" : "仍",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 699.9369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "152",
        "shared_name" : "釋",
        "color" : "#6496c8",
        "name" : "釋",
        "reading" : "ɕĭɛk",
        "SUID" : 152,
        "label" : "釋",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -946.5630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "153",
        "shared_name" : "矢",
        "color" : "#6496c8",
        "name" : "矢",
        "reading" : "ɕi˥",
        "SUID" : 153,
        "label" : "矢",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -566.5630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "154",
        "shared_name" : "追",
        "color" : "#9664c8",
        "name" : "追",
        "reading" : "ţwi˥˩",
        "SUID" : 154,
        "label" : "追",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1472.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "155",
        "shared_name" : "秦",
        "color" : "#c89664",
        "name" : "秦",
        "reading" : "dzʰĭĕn˩",
        "SUID" : 155,
        "label" : "秦",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : 56.43691939845621,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "156",
        "shared_name" : "資",
        "color" : "#c89664",
        "name" : "資",
        "reading" : "tsi˥˩",
        "SUID" : 156,
        "label" : "資",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1413.2967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "157",
        "shared_name" : "几",
        "color" : "#c89664",
        "name" : "几",
        "reading" : "ki˥",
        "SUID" : 157,
        "label" : "几",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1022.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "158",
        "shared_name" : "詰",
        "color" : "#c89664",
        "name" : "詰",
        "reading" : "kʰĭĕt",
        "SUID" : 158,
        "label" : "詰",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1394.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "159",
        "shared_name" : "雖",
        "color" : "#6496c8",
        "name" : "雖",
        "reading" : "swi˥˩",
        "SUID" : 159,
        "label" : "雖",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -532.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "160",
        "shared_name" : "脂",
        "color" : "#9664c8",
        "name" : "脂",
        "reading" : "tɕi˥˩",
        "SUID" : 160,
        "label" : "脂",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 549.6779401924073,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "161",
        "shared_name" : "卿",
        "color" : "#c89664",
        "name" : "卿",
        "reading" : "kʰĭɐŋ˥˩",
        "SUID" : 161,
        "label" : "卿",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 919.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "162",
        "shared_name" : "爭",
        "color" : "#9664c8",
        "name" : "爭",
        "reading" : "ʧæŋ˥˩",
        "SUID" : 162,
        "label" : "爭",
        "community" : 42,
        "selected" : false,
        "group" : "tsr "
      },
      "position" : {
        "x" : -635.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "163",
        "shared_name" : "規",
        "color" : "#c89664",
        "name" : "規",
        "reading" : "kĭwe˥˩",
        "SUID" : 163,
        "label" : "規",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 832.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "164",
        "shared_name" : "危",
        "color" : "#64c8c8",
        "name" : "危",
        "reading" : "ŋĭwe˩",
        "SUID" : 164,
        "label" : "危",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 686.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "165",
        "shared_name" : "窺",
        "color" : "#c89664",
        "name" : "窺",
        "reading" : "kʰĭwe˥˩",
        "SUID" : 165,
        "label" : "窺",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 397.4369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "166",
        "shared_name" : "馳",
        "color" : "#9664c8",
        "name" : "馳",
        "reading" : "ɖʰĭe˩",
        "SUID" : 166,
        "label" : "馳",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "167",
        "shared_name" : "奇",
        "color" : "#c89664",
        "name" : "奇",
        "reading" : "kĭe˥˩",
        "SUID" : 167,
        "label" : "奇",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 737.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "shared_name" : "披",
        "color" : "#c8c864",
        "name" : "披",
        "reading" : "pʰĭe˥˩",
        "SUID" : 168,
        "label" : "披",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "169",
        "shared_name" : "詭",
        "color" : "#c89664",
        "name" : "詭",
        "reading" : "kĭwe˥",
        "SUID" : 169,
        "label" : "詭",
        "community" : 11,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : -91.56308060154379,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "170",
        "shared_name" : "支",
        "color" : "#9664c8",
        "name" : "支",
        "reading" : "tɕĭe˥˩",
        "SUID" : 170,
        "label" : "支",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : -0.5630806015437884,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "171",
        "shared_name" : "穠",
        "color" : "#64c8c8",
        "name" : "穠",
        "reading" : "ɳĭwoŋ˩",
        "SUID" : 171,
        "label" : "穠",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -799.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "172",
        "shared_name" : "區",
        "color" : "#96c864",
        "name" : "區",
        "reading" : "kʰĭu˥˩",
        "SUID" : 172,
        "label" : "區",
        "community" : 50,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 682.4369193984562,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "173",
        "shared_name" : "柱",
        "color" : "#9664c8",
        "name" : "柱",
        "reading" : "ɖʰĭu˥",
        "SUID" : 173,
        "label" : "柱",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1067.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "174",
        "shared_name" : "乎",
        "color" : "#96c864",
        "name" : "乎",
        "reading" : "ɣu˩",
        "SUID" : 174,
        "label" : "乎",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 521.4695280941082,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "175",
        "shared_name" : "干",
        "color" : "#c89664",
        "name" : "干",
        "reading" : "kɑn˥˩",
        "SUID" : 175,
        "label" : "干",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -186.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "shared_name" : "馮",
        "color" : "#c8c864",
        "name" : "馮",
        "reading" : "bʰĭuŋ˩",
        "SUID" : 176,
        "label" : "馮",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "shared_name" : "頻",
        "color" : "#c8c864",
        "name" : "頻",
        "reading" : "bʰĭĕn˩",
        "SUID" : 177,
        "label" : "頻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "shared_name" : "徧",
        "color" : "#c8c864",
        "name" : "徧",
        "reading" : "pien˩˥",
        "SUID" : 178,
        "label" : "徧",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : 121.02387592019522,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "shared_name" : "峯",
        "color" : "#c8c864",
        "name" : "峯",
        "reading" : "pʰĭwoŋ˥˩",
        "SUID" : 179,
        "label" : "峯",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "180",
        "shared_name" : "明",
        "color" : "#64c896",
        "name" : "明",
        "reading" : "mĭɐŋ˩",
        "SUID" : 180,
        "label" : "明",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1257.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "181",
        "shared_name" : "兼",
        "color" : "#c89664",
        "name" : "兼",
        "reading" : "kiem˩˥",
        "SUID" : 181,
        "label" : "兼",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 3.4369193984562116,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "182",
        "shared_name" : "青",
        "color" : "",
        "name" : "青",
        "reading" : "",
        "SUID" : 182,
        "label" : "青",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 453.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "183",
        "shared_name" : "謙",
        "color" : "#c89664",
        "name" : "謙",
        "reading" : "kʰiem˥˩",
        "SUID" : 183,
        "label" : "謙",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 694.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "184",
        "shared_name" : "衣",
        "color" : "#96c864",
        "name" : "衣",
        "reading" : "ʔĭəi˩˥",
        "SUID" : 184,
        "label" : "衣",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1105.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "185",
        "shared_name" : "占",
        "color" : "#9664c8",
        "name" : "占",
        "reading" : "tɕĭɛm˥˩",
        "SUID" : 185,
        "label" : "占",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 454.6779401924073,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "186",
        "shared_name" : "謨",
        "color" : "#64c896",
        "name" : "謨",
        "reading" : "mu˩",
        "SUID" : 186,
        "label" : "謨",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1618.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "187",
        "shared_name" : "賞",
        "color" : "#6496c8",
        "name" : "賞",
        "reading" : "ɕĭaŋ˥",
        "SUID" : 187,
        "label" : "賞",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -804.0630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "188",
        "shared_name" : "欽",
        "color" : "#c89664",
        "name" : "欽",
        "reading" : "kʰĭĕm˥˩",
        "SUID" : 188,
        "label" : "欽",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1204.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "shared_name" : "丕",
        "color" : "#c8c864",
        "name" : "丕",
        "reading" : "pʰi˥˩",
        "SUID" : 189,
        "label" : "丕",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "190",
        "shared_name" : "天",
        "color" : "#9664c8",
        "name" : "天",
        "reading" : "tʰien˥˩",
        "SUID" : 190,
        "label" : "天",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "191",
        "shared_name" : "殖",
        "color" : "#9664c8",
        "name" : "殖",
        "reading" : "ʑĭək",
        "SUID" : 191,
        "label" : "殖",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1890.9803976593257,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "192",
        "shared_name" : "烟",
        "color" : "#96c864",
        "name" : "烟",
        "reading" : "ʔĭĕn˥˩",
        "SUID" : 192,
        "label" : "烟",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1200.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "193",
        "shared_name" : "拏",
        "color" : "#64c8c8",
        "name" : "拏",
        "reading" : "ɳa˩",
        "SUID" : 193,
        "label" : "拏",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -609.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "194",
        "shared_name" : "何",
        "color" : "#96c864",
        "name" : "何",
        "reading" : "ɣɑ˥",
        "SUID" : 194,
        "label" : "何",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 225.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "shared_name" : "兵",
        "color" : "#c8c864",
        "name" : "兵",
        "reading" : "pĭɐŋ˥˩",
        "SUID" : 195,
        "label" : "兵",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -634.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "196",
        "shared_name" : "麁",
        "color" : "#9664c8",
        "name" : "麁",
        "reading" : "tsʰu˥˩",
        "SUID" : 196,
        "label" : "麁",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 1708.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "197",
        "shared_name" : "各",
        "color" : "#c89664",
        "name" : "各",
        "reading" : "kɑk",
        "SUID" : 197,
        "label" : "各",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : 98.43691939845621,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "198",
        "shared_name" : "紆",
        "color" : "#96c864",
        "name" : "紆",
        "reading" : "ʔĭu˥˩",
        "SUID" : 198,
        "label" : "紆",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1960.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "shared_name" : "分",
        "color" : "#c8c864",
        "name" : "分",
        "reading" : "pĭuən˥˩",
        "SUID" : 199,
        "label" : "分",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -349.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "妃",
        "color" : "#c8c864",
        "name" : "妃",
        "reading" : "pʰĭwəi˥˩",
        "SUID" : 200,
        "label" : "妃",
        "community" : 55,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1626.5304719058918,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "201",
        "shared_name" : "沙",
        "color" : "#6496c8",
        "name" : "沙",
        "reading" : "ʃa˩˥",
        "SUID" : 201,
        "label" : "沙",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1575.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "202",
        "shared_name" : "又",
        "color" : "#96c864",
        "name" : "又",
        "reading" : "ĭəu˩˥",
        "SUID" : 202,
        "label" : "又",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -121.53047190589177,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "203",
        "shared_name" : "𩛠",
        "color" : "#9664c8",
        "name" : "𩛠",
        "reading" : "tsĭuɑ˥˩",
        "SUID" : 203,
        "label" : "𩛠",
        "community" : 23,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "204",
        "shared_name" : "悉",
        "color" : "#6496c8",
        "name" : "悉",
        "reading" : "sĭĕt",
        "SUID" : 204,
        "label" : "悉",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 253.9586585288912,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "205",
        "shared_name" : "砂",
        "color" : "#6496c8",
        "name" : "砂",
        "reading" : "ʃa˥˩",
        "SUID" : 205,
        "label" : "砂",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1670.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "捕",
        "color" : "#c8c864",
        "name" : "捕",
        "reading" : "bʰu˩˥",
        "SUID" : 206,
        "label" : "捕",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 135.46952809410823,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "207",
        "shared_name" : "枯",
        "color" : "#c89664",
        "name" : "枯",
        "reading" : "kʰu˥˩",
        "SUID" : 207,
        "label" : "枯",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 409.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "208",
        "shared_name" : "親",
        "color" : "#9664c8",
        "name" : "親",
        "reading" : "tsʰĭĕn˩˥",
        "SUID" : 208,
        "label" : "親",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 1523.4369193984562,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "shared_name" : "平",
        "color" : "#c8c864",
        "name" : "平",
        "reading" : "bʰĭɛn˩",
        "SUID" : 209,
        "label" : "平",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1257.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "陂",
        "color" : "#c8c864",
        "name" : "陂",
        "reading" : "pĭe˩˥",
        "SUID" : 210,
        "label" : "陂",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -539.5196023406743,
        "y" : -971.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "shared_name" : "苻",
        "color" : "#c8c864",
        "name" : "苻",
        "reading" : "bʰĭu˩",
        "SUID" : 211,
        "label" : "苻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -919.5196023406743,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "212",
        "shared_name" : "治",
        "color" : "#9664c8",
        "name" : "治",
        "reading" : "ɖʰĭə˩˥",
        "SUID" : 212,
        "label" : "治",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "213",
        "shared_name" : "馨",
        "color" : "#c89664",
        "name" : "馨",
        "reading" : "xieŋ˥˩",
        "SUID" : 213,
        "label" : "馨",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "214",
        "shared_name" : "除",
        "color" : "#9664c8",
        "name" : "除",
        "reading" : "ɖʰĭo˩",
        "SUID" : 214,
        "label" : "除",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "215",
        "shared_name" : "狂",
        "color" : "#c89664",
        "name" : "狂",
        "reading" : "gʰĭwaŋ˩",
        "SUID" : 215,
        "label" : "狂",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1203.9695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "216",
        "shared_name" : "持",
        "color" : "#9664c8",
        "name" : "持",
        "reading" : "ɖʰĭə˩",
        "SUID" : 216,
        "label" : "持",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "217",
        "shared_name" : "牽",
        "color" : "#c89664",
        "name" : "牽",
        "reading" : "kʰien˩˥",
        "SUID" : 217,
        "label" : "牽",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 504.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "218",
        "shared_name" : "姑",
        "color" : "#c89664",
        "name" : "姑",
        "reading" : "ku˥˩",
        "SUID" : 218,
        "label" : "姑",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -566.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "219",
        "shared_name" : "雛",
        "color" : "#9664c8",
        "name" : "雛",
        "reading" : "dʒʰĭu˩",
        "SUID" : 219,
        "label" : "雛",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1209.5630806015438,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "220",
        "shared_name" : "辝",
        "color" : "#6496c8",
        "name" : "辝",
        "reading" : "zĭə˩",
        "SUID" : 220,
        "label" : "辝",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1389.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "221",
        "shared_name" : "空",
        "color" : "#c89664",
        "name" : "空",
        "reading" : "kʰuŋ˩˥",
        "SUID" : 221,
        "label" : "空",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 314.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "222",
        "shared_name" : "模",
        "color" : "#64c896",
        "name" : "模",
        "reading" : "mu˩",
        "SUID" : 222,
        "label" : "模",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1428.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "223",
        "shared_name" : "兹",
        "color" : "#c89664",
        "name" : "兹",
        "reading" : "dzʰĭə˩",
        "SUID" : 223,
        "label" : "兹",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -38.56308060154379,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "224",
        "shared_name" : "雲",
        "color" : "#96c864",
        "name" : "雲",
        "reading" : "ĭuən˩",
        "SUID" : 224,
        "label" : "雲",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -512.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "225",
        "shared_name" : "休",
        "color" : "#c89664",
        "name" : "休",
        "reading" : "xĭəu˥˩",
        "SUID" : 225,
        "label" : "休",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -180.5087327754568,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "shared_name" : "反",
        "color" : "#c8c864",
        "name" : "反",
        "reading" : "pʰĭwɐn˥˩",
        "SUID" : 226,
        "label" : "反",
        "community" : 10,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1531.5304719058918,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "227",
        "shared_name" : "云",
        "color" : "#96c864",
        "name" : "云",
        "reading" : "ĭuən˩",
        "SUID" : 227,
        "label" : "云",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -417.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "228",
        "shared_name" : "珍",
        "color" : "#9664c8",
        "name" : "珍",
        "reading" : "ţĭĕn˥˩",
        "SUID" : 228,
        "label" : "珍",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1757.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "229",
        "shared_name" : "弃",
        "color" : "#c89664",
        "name" : "弃",
        "reading" : "kʰi˩˥",
        "SUID" : 229,
        "label" : "弃",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1394.9369193984562,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "230",
        "shared_name" : "癡",
        "color" : "#9664c8",
        "name" : "癡",
        "reading" : "ţʰĭə˥˩",
        "SUID" : 230,
        "label" : "癡",
        "community" : 41,
        "selected" : false,
        "group" : "trh j"
      },
      "position" : {
        "x" : 560.9586585288912,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "231",
        "shared_name" : "眉",
        "color" : "#64c896",
        "name" : "眉",
        "reading" : "mi˩",
        "SUID" : 231,
        "label" : "眉",
        "community" : 33,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "232",
        "shared_name" : "宜",
        "color" : "#64c8c8",
        "name" : "宜",
        "reading" : "ŋĭe˩",
        "SUID" : 232,
        "label" : "宜",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 591.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "毗",
        "color" : "#c8c864",
        "name" : "毗",
        "reading" : "bʰi˩",
        "SUID" : 233,
        "label" : "毗",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "234",
        "shared_name" : "來",
        "color" : "#6464c8",
        "name" : "來",
        "reading" : "lɒi˩",
        "SUID" : 234,
        "label" : "來",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 176.4369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "235",
        "shared_name" : "夷",
        "color" : "#c86464",
        "name" : "夷",
        "reading" : "ji˩",
        "SUID" : 235,
        "label" : "夷",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "236",
        "shared_name" : "花",
        "color" : "#c89664",
        "name" : "花",
        "reading" : "xwa˥˩",
        "SUID" : 236,
        "label" : "花",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "237",
        "shared_name" : "懷",
        "color" : "#96c864",
        "name" : "懷",
        "reading" : "ɣwɐi˩",
        "SUID" : 237,
        "label" : "懷",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 616.4695280941082,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "238",
        "shared_name" : "丈",
        "color" : "#9664c8",
        "name" : "丈",
        "reading" : "ɖʰĭaŋ˥",
        "SUID" : 238,
        "label" : "丈",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -972.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "239",
        "shared_name" : "乖",
        "color" : "#c89664",
        "name" : "乖",
        "reading" : "kwɐi˥˩",
        "SUID" : 239,
        "label" : "乖",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -281.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "240",
        "shared_name" : "佳",
        "color" : "#c89664",
        "name" : "佳",
        "reading" : "kai˥˩",
        "SUID" : 240,
        "label" : "佳",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -471.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "241",
        "shared_name" : "補",
        "color" : "#c8c864",
        "name" : "補",
        "reading" : "pu˥",
        "SUID" : 241,
        "label" : "補",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -1041.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "242",
        "shared_name" : "研",
        "color" : "#64c8c8",
        "name" : "研",
        "reading" : "ŋien˩˥",
        "SUID" : 242,
        "label" : "研",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : 375.4369193984562,
        "y" : -390.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "shared_name" : "傍",
        "color" : "#c8c864",
        "name" : "傍",
        "reading" : "bʰɑŋ˩",
        "SUID" : 243,
        "label" : "傍",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 164.73583244193446,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "244",
        "shared_name" : "侯",
        "color" : "#96c864",
        "name" : "侯",
        "reading" : "ɣəu˩",
        "SUID" : 244,
        "label" : "侯",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 711.4695280941082,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "245",
        "shared_name" : "安",
        "color" : "#96c864",
        "name" : "安",
        "reading" : "ʔɑn˥˩",
        "SUID" : 245,
        "label" : "安",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1022.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "shared_name" : "裴",
        "color" : "#c8c864",
        "name" : "裴",
        "reading" : "bʰĭwəi˩",
        "SUID" : 246,
        "label" : "裴",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "247",
        "shared_name" : "疑",
        "color" : "#64c8c8",
        "name" : "疑",
        "reading" : "ŋĭə˩",
        "SUID" : 247,
        "label" : "疑",
        "community" : 44,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 470.4369193984562,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "248",
        "shared_name" : "采",
        "color" : "#9664c8",
        "name" : "采",
        "reading" : "tsʰɒi˥",
        "SUID" : 248,
        "label" : "采",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1803.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "249",
        "shared_name" : "鶵",
        "color" : "#9664c8",
        "name" : "鶵",
        "reading" : "dʒʰĭu˩",
        "SUID" : 249,
        "label" : "鶵",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1114.5630806015438,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "250",
        "shared_name" : "俱",
        "color" : "#c89664",
        "name" : "俱",
        "reading" : "kĭu˥˩",
        "SUID" : 250,
        "label" : "俱",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1212.4369193984562,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "251",
        "shared_name" : "驅",
        "color" : "#c89664",
        "name" : "驅",
        "reading" : "kʰĭu˥˩",
        "SUID" : 251,
        "label" : "驅",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 777.4369193984562,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "252",
        "shared_name" : "臣",
        "color" : "#9664c8",
        "name" : "臣",
        "reading" : "ʑĭĕn˩",
        "SUID" : 252,
        "label" : "臣",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -782.5630806015438,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "253",
        "shared_name" : "虞",
        "color" : "#64c8c8",
        "name" : "虞",
        "reading" : "ŋĭu˩",
        "SUID" : 253,
        "label" : "虞",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 1019.4586585288912,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "254",
        "shared_name" : "羌",
        "color" : "#c89664",
        "name" : "羌",
        "reading" : "kʰĭaŋ˥˩",
        "SUID" : 254,
        "label" : "羌",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 824.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "255",
        "shared_name" : "慈",
        "color" : "#c89664",
        "name" : "慈",
        "reading" : "dzʰĭə˩",
        "SUID" : 255,
        "label" : "慈",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : -133.5630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "256",
        "shared_name" : "創",
        "color" : "#9664c8",
        "name" : "創",
        "reading" : "ʧʰĭaŋ˩˥",
        "SUID" : 256,
        "label" : "創",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 555.1977889636737,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "257",
        "shared_name" : "尼",
        "color" : "#64c8c8",
        "name" : "尼",
        "reading" : "ɳi˩",
        "SUID" : 257,
        "label" : "尼",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -704.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "258",
        "shared_name" : "舒",
        "color" : "#6496c8",
        "name" : "舒",
        "reading" : "ɕĭo˥˩",
        "SUID" : 258,
        "label" : "舒",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -756.5630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "shared_name" : "浮",
        "color" : "#c8c864",
        "name" : "浮",
        "reading" : "bʰĭəu˩",
        "SUID" : 259,
        "label" : "浮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : 276.3157001167924,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "260",
        "shared_name" : "袪",
        "color" : "#c89664",
        "name" : "袪",
        "reading" : "kʰĭo˥˩",
        "SUID" : 260,
        "label" : "袪",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 729.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "261",
        "shared_name" : "牀",
        "color" : "#9664c8",
        "name" : "牀",
        "reading" : "dʒʰĭaŋ˩",
        "SUID" : 261,
        "label" : "牀",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -877.0630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "262",
        "shared_name" : "詩",
        "color" : "#6496c8",
        "name" : "詩",
        "reading" : "ɕĭə˥˩",
        "SUID" : 262,
        "label" : "詩",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -899.0630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "263",
        "shared_name" : "胥",
        "color" : "#6496c8",
        "name" : "胥",
        "reading" : "sĭo˥˩",
        "SUID" : 263,
        "label" : "胥",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -221.04134147110904,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "264",
        "shared_name" : "良",
        "color" : "#6464c8",
        "name" : "良",
        "reading" : "lĭaŋ˩",
        "SUID" : 264,
        "label" : "良",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -397.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "265",
        "shared_name" : "踈",
        "color" : "#6496c8",
        "name" : "踈",
        "reading" : "ʃĭo˥˩",
        "SUID" : 265,
        "label" : "踈",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : 1385.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "266",
        "shared_name" : "曁",
        "color" : "#c89664",
        "name" : "曁",
        "reading" : "kĭət",
        "SUID" : 266,
        "label" : "曁",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1307.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "267",
        "shared_name" : "楮",
        "color" : "#9664c8",
        "name" : "楮",
        "reading" : "ţʰĭo˥",
        "SUID" : 267,
        "label" : "楮",
        "community" : 41,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 750.9586585288912,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "268",
        "shared_name" : "豬",
        "color" : "#9664c8",
        "name" : "豬",
        "reading" : "ţĭo˥˩",
        "SUID" : 268,
        "label" : "豬",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1567.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "269",
        "shared_name" : "榮",
        "color" : "#96c864",
        "name" : "榮",
        "reading" : "ĭwɐŋ˩",
        "SUID" : 269,
        "label" : "榮",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -406.53047190589155,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "270",
        "shared_name" : "興",
        "color" : "#c89664",
        "name" : "興",
        "reading" : "xĭəŋ˥˩",
        "SUID" : 270,
        "label" : "興",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -445.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "271",
        "shared_name" : "神",
        "color" : "#6496c8",
        "name" : "神",
        "reading" : "dʑʰĭĕn˩",
        "SUID" : 271,
        "label" : "神",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -870.986993645022,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "272",
        "shared_name" : "隨",
        "color" : "#6496c8",
        "name" : "隨",
        "reading" : "zĭwe˩",
        "SUID" : 272,
        "label" : "隨",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1579.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "273",
        "shared_name" : "施",
        "color" : "#6496c8",
        "name" : "施",
        "reading" : "ɕĭe˥˩",
        "SUID" : 273,
        "label" : "施",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -994.0630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "便",
        "color" : "#c8c864",
        "name" : "便",
        "reading" : "bʰĭɛn˩",
        "SUID" : 274,
        "label" : "便",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "275",
        "shared_name" : "綿",
        "color" : "#64c896",
        "name" : "綿",
        "reading" : "mĭɛn˩",
        "SUID" : 275,
        "label" : "綿",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "276",
        "shared_name" : "兒",
        "color" : "#64c8c8",
        "name" : "兒",
        "reading" : "nʑĭe˩",
        "SUID" : 276,
        "label" : "兒",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 652.4369193984562,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "shared_name" : "并",
        "color" : "#c8c864",
        "name" : "并",
        "reading" : "pĭɛŋ˥˩",
        "SUID" : 277,
        "label" : "并",
        "community" : 2,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -159.51960234067428,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "278",
        "shared_name" : "移",
        "color" : "#c86464",
        "name" : "移",
        "reading" : "jĭe˩",
        "SUID" : 278,
        "label" : "移",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1108.486993645022,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "279",
        "shared_name" : "斯",
        "color" : "#6496c8",
        "name" : "斯",
        "reading" : "sĭe˥˩",
        "SUID" : 279,
        "label" : "斯",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -722.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "280",
        "shared_name" : "池",
        "color" : "#9664c8",
        "name" : "池",
        "reading" : "ɖʰĭe˩",
        "SUID" : 280,
        "label" : "池",
        "community" : 30,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "281",
        "shared_name" : "雌",
        "color" : "#9664c8",
        "name" : "雌",
        "reading" : "tsʰĭe˥˩",
        "SUID" : 281,
        "label" : "雌",
        "community" : 59,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : -272.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "282",
        "shared_name" : "韋",
        "color" : "#96c864",
        "name" : "韋",
        "reading" : "ĭwəi˩",
        "SUID" : 282,
        "label" : "韋",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -607.5630806015438,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "283",
        "shared_name" : "墟",
        "color" : "#c89664",
        "name" : "墟",
        "reading" : "kʰĭo˥˩",
        "SUID" : 283,
        "label" : "墟",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 587.4369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "284",
        "shared_name" : "過",
        "color" : "#c89664",
        "name" : "過",
        "reading" : "kuɑ˩˥",
        "SUID" : 284,
        "label" : "過",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -91.56308060154379,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "285",
        "shared_name" : "文",
        "color" : "#64c896",
        "name" : "文",
        "reading" : "mĭuən˩",
        "SUID" : 285,
        "label" : "文",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1635.8511240798048,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "286",
        "shared_name" : "承",
        "color" : "#9664c8",
        "name" : "承",
        "reading" : "ʑĭəŋ˩",
        "SUID" : 286,
        "label" : "承",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1700.9803976593257,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "287",
        "shared_name" : "巴",
        "color" : "#c8c864",
        "name" : "巴",
        "reading" : "pa˥˩",
        "SUID" : 287,
        "label" : "巴",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -756.5630806015438,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "288",
        "shared_name" : "歩",
        "color" : "",
        "name" : "歩",
        "reading" : "",
        "SUID" : 288,
        "label" : "歩",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 574.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "289",
        "shared_name" : "時",
        "color" : "#9664c8",
        "name" : "時",
        "reading" : "ʑĭə˩",
        "SUID" : 289,
        "label" : "時",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1515.4369193984562,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "290",
        "shared_name" : "之",
        "color" : "#9664c8",
        "name" : "之",
        "reading" : "tɕĭə˥˩",
        "SUID" : 290,
        "label" : "之",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 488.9170706271898,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "291",
        "shared_name" : "康",
        "color" : "#c89664",
        "name" : "康",
        "reading" : "kʰɑŋ˥˩",
        "SUID" : 291,
        "label" : "康",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 599.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "shared_name" : "僕",
        "color" : "#c8c864",
        "name" : "僕",
        "reading" : "bʰuok",
        "SUID" : 292,
        "label" : "僕",
        "community" : 25,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 29.43691939845621,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "293",
        "shared_name" : "名",
        "color" : "#64c896",
        "name" : "名",
        "reading" : "mĭɛŋ˩",
        "SUID" : 293,
        "label" : "名",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1162.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "shared_name" : "白",
        "color" : "#c8c864",
        "name" : "白",
        "reading" : "bʰɐk",
        "SUID" : 294,
        "label" : "白",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 241.5021367897607,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "295",
        "shared_name" : "勒",
        "color" : "#6464c8",
        "name" : "勒",
        "reading" : "lək",
        "SUID" : 295,
        "label" : "勒",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 413.9369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "296",
        "shared_name" : "史",
        "color" : "#6496c8",
        "name" : "史",
        "reading" : "ʃĭə˥",
        "SUID" : 296,
        "label" : "史",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : 1385.4369193984562,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "297",
        "shared_name" : "挹",
        "color" : "#96c864",
        "name" : "挹",
        "reading" : "ʔĭĕp",
        "SUID" : 297,
        "label" : "挹",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 915.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "298",
        "shared_name" : "氏",
        "color" : "#9664c8",
        "name" : "氏",
        "reading" : "tɕĭe˥˩",
        "SUID" : 298,
        "label" : "氏",
        "community" : 23,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 94.43691939845621,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "299",
        "shared_name" : "知",
        "color" : "#9664c8",
        "name" : "知",
        "reading" : "ţĭe˥˩",
        "SUID" : 299,
        "label" : "知",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1377.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "300",
        "shared_name" : "徐",
        "color" : "#6496c8",
        "name" : "徐",
        "reading" : "zĭo˩",
        "SUID" : 300,
        "label" : "徐",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1294.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "shared_name" : "皮",
        "color" : "#c8c864",
        "name" : "皮",
        "reading" : "bʰĭe˩",
        "SUID" : 301,
        "label" : "皮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "302",
        "shared_name" : "亡",
        "color" : "#64c896",
        "name" : "亡",
        "reading" : "mĭwaŋ˩",
        "SUID" : 302,
        "label" : "亡",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "303",
        "shared_name" : "千",
        "color" : "#9664c8",
        "name" : "千",
        "reading" : "tsʰien˥˩",
        "SUID" : 303,
        "label" : "千",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 2088.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "304",
        "shared_name" : "恪",
        "color" : "#c89664",
        "name" : "恪",
        "reading" : "kʰɑk",
        "SUID" : 304,
        "label" : "恪",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 1074.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "305",
        "shared_name" : "速",
        "color" : "#6496c8",
        "name" : "速",
        "reading" : "suk",
        "SUID" : 305,
        "label" : "速",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 158.95865852889096,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "shared_name" : "縛",
        "color" : "#c8c864",
        "name" : "縛",
        "reading" : "bʰĭwak",
        "SUID" : 306,
        "label" : "縛",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : 276.3157001167924,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "307",
        "shared_name" : "耳",
        "color" : "#64c8c8",
        "name" : "耳",
        "reading" : "nʑĭə˥",
        "SUID" : 307,
        "label" : "耳",
        "community" : 39,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 462.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "308",
        "shared_name" : "自",
        "color" : "#c89664",
        "name" : "自",
        "reading" : "dzʰi˩˥",
        "SUID" : 308,
        "label" : "自",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : 151.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "309",
        "shared_name" : "綺",
        "color" : "#c89664",
        "name" : "綺",
        "reading" : "kʰĭe˥",
        "SUID" : 309,
        "label" : "綺",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 539.9369193984562,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "310",
        "shared_name" : "虛",
        "color" : "#c89664",
        "name" : "虛",
        "reading" : "xĭo˥˩",
        "SUID" : 310,
        "label" : "虛",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -350.5630806015438,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "311",
        "shared_name" : "識",
        "color" : "#9664c8",
        "name" : "識",
        "reading" : "tɕĭə˩˥",
        "SUID" : 311,
        "label" : "識",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 644.6779401924073,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "筆",
        "color" : "#c8c864",
        "name" : "筆",
        "reading" : "pĭĕt",
        "SUID" : 312,
        "label" : "筆",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -824.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "313",
        "shared_name" : "煑",
        "color" : "#9664c8",
        "name" : "煑",
        "reading" : "tɕĭo˥",
        "SUID" : 313,
        "label" : "煑",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 189.4369193984562,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "314",
        "shared_name" : "桑",
        "color" : "#6496c8",
        "name" : "桑",
        "reading" : "sɑŋ˥˩",
        "SUID" : 314,
        "label" : "桑",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 111.45865852889096,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "315",
        "shared_name" : "特",
        "color" : "#9664c8",
        "name" : "特",
        "reading" : "dʰək",
        "SUID" : 315,
        "label" : "特",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 2327.436919398456,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "316",
        "shared_name" : "余",
        "color" : "#c86464",
        "name" : "余",
        "reading" : "jĭo˩",
        "SUID" : 316,
        "label" : "余",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "317",
        "shared_name" : "中",
        "color" : "#9664c8",
        "name" : "中",
        "reading" : "ţĭuŋ˩˥",
        "SUID" : 317,
        "label" : "中",
        "community" : 46,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1235.4369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "318",
        "shared_name" : "永",
        "color" : "#96c864",
        "name" : "永",
        "reading" : "ĭwɐŋ˥",
        "SUID" : 318,
        "label" : "永",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -406.53047190589155,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "319",
        "shared_name" : "助",
        "color" : "#9664c8",
        "name" : "助",
        "reading" : "dʒʰĭo˩˥",
        "SUID" : 319,
        "label" : "助",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -782.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "320",
        "shared_name" : "客",
        "color" : "#c89664",
        "name" : "客",
        "reading" : "kʰɐk",
        "SUID" : 320,
        "label" : "客",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 1169.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "321",
        "shared_name" : "色",
        "color" : "#6496c8",
        "name" : "色",
        "reading" : "ʃĭək",
        "SUID" : 321,
        "label" : "色",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : 1955.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "322",
        "shared_name" : "乞",
        "color" : "#c89664",
        "name" : "乞",
        "reading" : "kʰĭət",
        "SUID" : 322,
        "label" : "乞",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1489.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "323",
        "shared_name" : "寫",
        "color" : "#6496c8",
        "name" : "寫",
        "reading" : "sĭa˥",
        "SUID" : 323,
        "label" : "寫",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : 253.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "324",
        "shared_name" : "才",
        "color" : "#c89664",
        "name" : "才",
        "reading" : "dzʰɒi˩",
        "SUID" : 324,
        "label" : "才",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -1136.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "325",
        "shared_name" : "初",
        "color" : "#9664c8",
        "name" : "初",
        "reading" : "ʧʰĭo˥˩",
        "SUID" : 325,
        "label" : "初",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 494.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "326",
        "shared_name" : "伯",
        "color" : "#c8c864",
        "name" : "伯",
        "reading" : "pɐk",
        "SUID" : 326,
        "label" : "伯",
        "community" : 14,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -756.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "327",
        "shared_name" : "正",
        "color" : "#9664c8",
        "name" : "正",
        "reading" : "tɕĭɛŋ˥˩",
        "SUID" : 327,
        "label" : "正",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 390.4695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "328",
        "shared_name" : "縷",
        "color" : "#6464c8",
        "name" : "縷",
        "reading" : "lĭu˥",
        "SUID" : 328,
        "label" : "縷",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -349.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "329",
        "shared_name" : "醋",
        "color" : "#9664c8",
        "name" : "醋",
        "reading" : "tsʰu˩˥",
        "SUID" : 329,
        "label" : "醋",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1993.9803976593257,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "330",
        "shared_name" : "求",
        "color" : "#c89664",
        "name" : "求",
        "reading" : "gʰĭəu˩",
        "SUID" : 330,
        "label" : "求",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1298.9695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "shared_name" : "滂",
        "color" : "#c8c864",
        "name" : "滂",
        "reading" : "pʰɑŋ˥˩",
        "SUID" : 331,
        "label" : "滂",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : 1446.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "332",
        "shared_name" : "虎",
        "color" : "#c89664",
        "name" : "虎",
        "reading" : "xu˥",
        "SUID" : 332,
        "label" : "虎",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "333",
        "shared_name" : "諾",
        "color" : "#64c8c8",
        "name" : "諾",
        "reading" : "nɑk",
        "SUID" : 333,
        "label" : "諾",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : 1062.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "334",
        "shared_name" : "託",
        "color" : "#9664c8",
        "name" : "託",
        "reading" : "tʰɑk",
        "SUID" : 334,
        "label" : "託",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "335",
        "shared_name" : "得",
        "color" : "#9664c8",
        "name" : "得",
        "reading" : "tək",
        "SUID" : 335,
        "label" : "得",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -393.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "336",
        "shared_name" : "鉏",
        "color" : "#9664c8",
        "name" : "鉏",
        "reading" : "dʒʰĭo˩",
        "SUID" : 336,
        "label" : "鉏",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1162.0630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "337",
        "shared_name" : "起",
        "color" : "#c89664",
        "name" : "起",
        "reading" : "kʰĭə˥",
        "SUID" : 337,
        "label" : "起",
        "community" : 57,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 634.9369193984562,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "撫",
        "color" : "#c8c864",
        "name" : "撫",
        "reading" : "pʰĭu˥",
        "SUID" : 338,
        "label" : "撫",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1341.5304719058918,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "339",
        "shared_name" : "于",
        "color" : "#96c864",
        "name" : "于",
        "reading" : "ĭu˩",
        "SUID" : 339,
        "label" : "于",
        "community" : 6,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : -264.0304719058918,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "340",
        "shared_name" : "有",
        "color" : "#96c864",
        "name" : "有",
        "reading" : "ĭəu˥",
        "SUID" : 340,
        "label" : "有",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -417.5630806015438,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "341",
        "shared_name" : "夕",
        "color" : "#6496c8",
        "name" : "夕",
        "reading" : "zĭɛk",
        "SUID" : 341,
        "label" : "夕",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1056.5304719058915,
        "y" : -1552.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "卑",
        "color" : "#c8c864",
        "name" : "卑",
        "reading" : "dzʰæn˩",
        "SUID" : 342,
        "label" : "卑",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -134.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "343",
        "shared_name" : "須",
        "color" : "#6496c8",
        "name" : "須",
        "reading" : "sĭu˥˩",
        "SUID" : 343,
        "label" : "須",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -126.04134147110904,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "344",
        "shared_name" : "張",
        "color" : "#9664c8",
        "name" : "張",
        "reading" : "ţĭaŋ˥˩",
        "SUID" : 344,
        "label" : "張",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1852.9369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "345",
        "shared_name" : "諸",
        "color" : "#9664c8",
        "name" : "諸",
        "reading" : "tɕĭo˥˩",
        "SUID" : 345,
        "label" : "諸",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 342.9695280941082,
        "y" : -2242.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "346",
        "shared_name" : "崇",
        "color" : "#9664c8",
        "name" : "崇",
        "reading" : "dʒʰĭuŋ˩",
        "SUID" : 346,
        "label" : "崇",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1067.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "347",
        "shared_name" : "蒼",
        "color" : "#9664c8",
        "name" : "蒼",
        "reading" : "tsʰɑŋ˥˩",
        "SUID" : 347,
        "label" : "蒼",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 2088.9803976593257,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "偏",
        "color" : "#c8c864",
        "name" : "偏",
        "reading" : "pʰĭɛn˥˩",
        "SUID" : 348,
        "label" : "偏",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1436.5304719058918,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "349",
        "shared_name" : "卜",
        "color" : "#c8c864",
        "name" : "卜",
        "reading" : "puk",
        "SUID" : 349,
        "label" : "卜",
        "community" : 14,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -851.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "350",
        "shared_name" : "目",
        "color" : "#64c896",
        "name" : "目",
        "reading" : "mĭuk",
        "SUID" : 350,
        "label" : "目",
        "community" : 33,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : 1903.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "shared_name" : "並",
        "color" : "#c8c864",
        "name" : "並",
        "reading" : "bʰieŋ˥",
        "SUID" : 351,
        "label" : "並",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -255.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "352",
        "shared_name" : "獲",
        "color" : "#96c864",
        "name" : "獲",
        "reading" : "ɣwæk",
        "SUID" : 352,
        "label" : "獲",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 510.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "353",
        "shared_name" : "跪",
        "color" : "#c89664",
        "name" : "跪",
        "reading" : "kʰĭwe˥",
        "SUID" : 353,
        "label" : "跪",
        "community" : 4,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1299.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "354",
        "shared_name" : "墜",
        "color" : "#9664c8",
        "name" : "墜",
        "reading" : "ɖʰwi˩˥",
        "SUID" : 354,
        "label" : "墜",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -877.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "355",
        "shared_name" : "委",
        "color" : "#96c864",
        "name" : "委",
        "reading" : "ʔĭwe˥",
        "SUID" : 355,
        "label" : "委",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 820.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "356",
        "shared_name" : "充",
        "color" : "#9664c8",
        "name" : "充",
        "reading" : "tɕʰĭuŋ˥˩",
        "SUID" : 356,
        "label" : "充",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "357",
        "shared_name" : "阻",
        "color" : "#9664c8",
        "name" : "阻",
        "reading" : "ʧĭo˥",
        "SUID" : 357,
        "label" : "阻",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -350.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "358",
        "shared_name" : "可",
        "color" : "#c89664",
        "name" : "可",
        "reading" : "kʰɑ˥",
        "SUID" : 358,
        "label" : "可",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 409.4369193984562,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "359",
        "shared_name" : "數",
        "color" : "#6496c8",
        "name" : "數",
        "reading" : "ʃɔk",
        "SUID" : 359,
        "label" : "數",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1860.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "360",
        "shared_name" : "北",
        "color" : "#c8c864",
        "name" : "北",
        "reading" : "pək",
        "SUID" : 360,
        "label" : "北",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -566.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "361",
        "shared_name" : "母",
        "color" : "#64c896",
        "name" : "母",
        "reading" : "məu˥",
        "SUID" : 361,
        "label" : "母",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1713.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "362",
        "shared_name" : "借",
        "color" : "#c89664",
        "name" : "借",
        "reading" : "tsĭa˩˥",
        "SUID" : 362,
        "label" : "借",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1447.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "363",
        "shared_name" : "在",
        "color" : "#c89664",
        "name" : "在",
        "reading" : "dzʰɒi˩˥",
        "SUID" : 363,
        "label" : "在",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -851.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "364",
        "shared_name" : "度",
        "color" : "#9664c8",
        "name" : "度",
        "reading" : "dʰɑk",
        "SUID" : 364,
        "label" : "度",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 2232.436919398456,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "365",
        "shared_name" : "一",
        "color" : "#96c864",
        "name" : "一",
        "reading" : "ʔĭĕt",
        "SUID" : 365,
        "label" : "一",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1675.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "366",
        "shared_name" : "多",
        "color" : "#9664c8",
        "name" : "多",
        "reading" : "tɑ˥˩",
        "SUID" : 366,
        "label" : "多",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -441.0630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "367",
        "shared_name" : "那",
        "color" : "#64c8c8",
        "name" : "那",
        "reading" : "nɑ˩",
        "SUID" : 367,
        "label" : "那",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : 1062.4369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "368",
        "shared_name" : "俄",
        "color" : "#64c8c8",
        "name" : "俄",
        "reading" : "ŋɑ˩",
        "SUID" : 368,
        "label" : "俄",
        "community" : 44,
        "selected" : false,
        "group" : "ng "
      },
      "position" : {
        "x" : 565.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "369",
        "shared_name" : "吐",
        "color" : "#9664c8",
        "name" : "吐",
        "reading" : "tʰu˥",
        "SUID" : 369,
        "label" : "吐",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "蒲",
        "color" : "#c8c864",
        "name" : "蒲",
        "reading" : "bʰu˩",
        "SUID" : 370,
        "label" : "蒲",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -113.06308060154379,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "371",
        "shared_name" : "思",
        "color" : "#6496c8",
        "name" : "思",
        "reading" : "sĭə˥˩",
        "SUID" : 371,
        "label" : "思",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -437.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "372",
        "shared_name" : "謁",
        "color" : "#96c864",
        "name" : "謁",
        "reading" : "ʔĭɐt",
        "SUID" : 372,
        "label" : "謁",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1865.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "373",
        "shared_name" : "虚",
        "color" : "#c89664",
        "name" : "虚",
        "reading" : "kʰĭo˥˩",
        "SUID" : 373,
        "label" : "虚",
        "community" : 4,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : 492.4369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "孚",
        "color" : "#c8c864",
        "name" : "孚",
        "reading" : "pʰĭu˥˩",
        "SUID" : 374,
        "label" : "孚",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1531.5304719058918,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "附",
        "color" : "#c8c864",
        "name" : "附",
        "reading" : "bʰĭu˩˥",
        "SUID" : 375,
        "label" : "附",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : 181.31570011679264,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "376",
        "shared_name" : "愚",
        "color" : "#64c8c8",
        "name" : "愚",
        "reading" : "ŋĭu˩",
        "SUID" : 376,
        "label" : "愚",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 1114.4586585288912,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "377",
        "shared_name" : "王",
        "color" : "#96c864",
        "name" : "王",
        "reading" : "ĭwaŋ˩",
        "SUID" : 377,
        "label" : "王",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -417.5630806015438,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "378",
        "shared_name" : "詳",
        "color" : "#6496c8",
        "name" : "詳",
        "reading" : "jĭaŋ˩",
        "SUID" : 378,
        "label" : "詳",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1436.5304719058915,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "379",
        "shared_name" : "常",
        "color" : "#9664c8",
        "name" : "常",
        "reading" : "ʑĭaŋ˩",
        "SUID" : 379,
        "label" : "常",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1795.9803976593257,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "380",
        "shared_name" : "彌",
        "color" : "#64c896",
        "name" : "彌",
        "reading" : "mĭe˩",
        "SUID" : 380,
        "label" : "彌",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1827.5630806015438,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "381",
        "shared_name" : "爲",
        "color" : "#96c864",
        "name" : "爲",
        "reading" : "ĭwe˩",
        "SUID" : 381,
        "label" : "爲",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -607.5630806015438,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "382",
        "shared_name" : "翼",
        "color" : "#c86464",
        "name" : "翼",
        "reading" : "jĭək",
        "SUID" : 382,
        "label" : "翼",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -965.986993645022,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "383",
        "shared_name" : "匠",
        "color" : "#c89664",
        "name" : "匠",
        "reading" : "dzʰĭaŋ˩˥",
        "SUID" : 383,
        "label" : "匠",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : 246.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "384",
        "shared_name" : "將",
        "color" : "#c89664",
        "name" : "將",
        "reading" : "tsĭaŋ˥˩",
        "SUID" : 384,
        "label" : "將",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1270.7967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "shared_name" : "必",
        "color" : "#c8c864",
        "name" : "必",
        "reading" : "pĭĕt",
        "SUID" : 385,
        "label" : "必",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -87.06308060154379,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "386",
        "shared_name" : "失",
        "color" : "#6496c8",
        "name" : "失",
        "reading" : "ɕĭĕt",
        "SUID" : 386,
        "label" : "失",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -376.5630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "387",
        "shared_name" : "食",
        "color" : "#6496c8",
        "name" : "食",
        "reading" : "jĭə˩˥",
        "SUID" : 387,
        "label" : "食",
        "community" : 53,
        "selected" : false,
        "group" : "zy j"
      },
      "position" : {
        "x" : -823.486993645022,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "388",
        "shared_name" : "植",
        "color" : "#9664c8",
        "name" : "植",
        "reading" : "ɖʰĭə˩˥",
        "SUID" : 388,
        "label" : "植",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : -782.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "shared_name" : "扶",
        "color" : "#c8c864",
        "name" : "扶",
        "reading" : "bʰĭu˩",
        "SUID" : 389,
        "label" : "扶",
        "community" : 2,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1041.041341471109,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "390",
        "shared_name" : "祖",
        "color" : "#c89664",
        "name" : "祖",
        "reading" : "tsu˥",
        "SUID" : 390,
        "label" : "祖",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1033.2967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "391",
        "shared_name" : "臧",
        "color" : "#c89664",
        "name" : "臧",
        "reading" : "tsɑŋ˥˩",
        "SUID" : 391,
        "label" : "臧",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1128.2967762537178,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "392",
        "shared_name" : "布",
        "color" : "#c8c864",
        "name" : "布",
        "reading" : "pu˩˥",
        "SUID" : 392,
        "label" : "布",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -946.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "393",
        "shared_name" : "魯",
        "color" : "#6464c8",
        "name" : "魯",
        "reading" : "lu˥",
        "SUID" : 393,
        "label" : "魯",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : -1421.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "394",
        "shared_name" : "公",
        "color" : "#c89664",
        "name" : "公",
        "reading" : "kuŋ˥˩",
        "SUID" : 394,
        "label" : "公",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -661.5630806015438,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "395",
        "shared_name" : "擬",
        "color" : "#64c8c8",
        "name" : "擬",
        "reading" : "ŋĭə˥",
        "SUID" : 395,
        "label" : "擬",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 781.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "396",
        "shared_name" : "口",
        "color" : "#c89664",
        "name" : "口",
        "reading" : "kʰəu˥",
        "SUID" : 396,
        "label" : "口",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 884.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "397",
        "shared_name" : "賴",
        "color" : "#6464c8",
        "name" : "賴",
        "reading" : "lɑi˩˥",
        "SUID" : 397,
        "label" : "賴",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 271.4369193984562,
        "y" : 1709.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "398",
        "shared_name" : "卓",
        "color" : "#9664c8",
        "name" : "卓",
        "reading" : "ţɔk",
        "SUID" : 398,
        "label" : "卓",
        "community" : 19,
        "selected" : false,
        "group" : "tr "
      },
      "position" : {
        "x" : 1301.8499628767172,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "shared_name" : "步",
        "color" : "#c8c864",
        "name" : "步",
        "reading" : "bʰu˩˥",
        "SUID" : 399,
        "label" : "步",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 230.46952809410823,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "400",
        "shared_name" : "乙",
        "color" : "#96c864",
        "name" : "乙",
        "reading" : "ʔĭĕt",
        "SUID" : 400,
        "label" : "乙",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1770.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "401",
        "shared_name" : "妳",
        "color" : "",
        "name" : "妳",
        "reading" : "",
        "SUID" : 401,
        "label" : "妳",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 695.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "402",
        "shared_name" : "火",
        "color" : "#c89664",
        "name" : "火",
        "reading" : "xuɑ˥",
        "SUID" : 402,
        "label" : "火",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1352.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "403",
        "shared_name" : "成",
        "color" : "#9664c8",
        "name" : "成",
        "reading" : "ʑĭɛŋ˩",
        "SUID" : 403,
        "label" : "成",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1605.9803976593257,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "部",
        "color" : "#c8c864",
        "name" : "部",
        "reading" : "bʰu˥",
        "SUID" : 404,
        "label" : "部",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "405",
        "shared_name" : "土",
        "color" : "#9664c8",
        "name" : "土",
        "reading" : "tʰu˥",
        "SUID" : 405,
        "label" : "土",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "406",
        "shared_name" : "先",
        "color" : "#6496c8",
        "name" : "先",
        "reading" : "sien˩˥",
        "SUID" : 406,
        "label" : "先",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 63.958658528890965,
        "y" : -390.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "407",
        "shared_name" : "胡",
        "color" : "#96c864",
        "name" : "胡",
        "reading" : "ɣu˩",
        "SUID" : 407,
        "label" : "胡",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 367.9369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "408",
        "shared_name" : "邊",
        "color" : "#c8c864",
        "name" : "邊",
        "reading" : "pien˥˩",
        "SUID" : 408,
        "label" : "邊",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -899.0630806015438,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "409",
        "shared_name" : "杜",
        "color" : "#9664c8",
        "name" : "杜",
        "reading" : "dʰu˥",
        "SUID" : 409,
        "label" : "杜",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 2042.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "410",
        "shared_name" : "郎",
        "color" : "#6464c8",
        "name" : "郎",
        "reading" : "lɑŋ˩",
        "SUID" : 410,
        "label" : "郎",
        "community" : 13,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : -1326.5630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "shared_name" : "普",
        "color" : "#c8c864",
        "name" : "普",
        "reading" : "pʰu˥",
        "SUID" : 411,
        "label" : "普",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : 1446.4369193984562,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "412",
        "shared_name" : "當",
        "color" : "#9664c8",
        "name" : "當",
        "reading" : "tɑŋ˥˩",
        "SUID" : 412,
        "label" : "當",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 1278.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "413",
        "shared_name" : "哀",
        "color" : "#96c864",
        "name" : "哀",
        "reading" : "ʔɒi˥˩",
        "SUID" : 413,
        "label" : "哀",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 927.4369193984562,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "414",
        "shared_name" : "昨",
        "color" : "#c89664",
        "name" : "昨",
        "reading" : "dzʰɑk",
        "SUID" : 414,
        "label" : "昨",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -1041.5630806015438,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "415",
        "shared_name" : "素",
        "color" : "#6496c8",
        "name" : "素",
        "reading" : "su˩˥",
        "SUID" : 415,
        "label" : "素",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 63.958658528890965,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "416",
        "shared_name" : "落",
        "color" : "#6464c8",
        "name" : "落",
        "reading" : "lɑk",
        "SUID" : 416,
        "label" : "落",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 223.9369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "417",
        "shared_name" : "則",
        "color" : "#c89664",
        "name" : "則",
        "reading" : "tsək",
        "SUID" : 417,
        "label" : "則",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -985.7967762537178,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "418",
        "shared_name" : "荒",
        "color" : "#c89664",
        "name" : "荒",
        "reading" : "xuɑŋ˩˥",
        "SUID" : 418,
        "label" : "荒",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "419",
        "shared_name" : "乃",
        "color" : "#64c8c8",
        "name" : "乃",
        "reading" : "nɒi˥",
        "SUID" : 419,
        "label" : "乃",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : 872.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "420",
        "shared_name" : "同",
        "color" : "#9664c8",
        "name" : "同",
        "reading" : "dʰuŋ˩",
        "SUID" : 420,
        "label" : "同",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 1567.4369193984562,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "421",
        "shared_name" : "憶",
        "color" : "#96c864",
        "name" : "憶",
        "reading" : "ʔĭək",
        "SUID" : 421,
        "label" : "憶",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1960.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "422",
        "shared_name" : "莊",
        "color" : "#9664c8",
        "name" : "莊",
        "reading" : "ʧĭaŋ˥˩",
        "SUID" : 422,
        "label" : "莊",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -730.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "423",
        "shared_name" : "仕",
        "color" : "#9664c8",
        "name" : "仕",
        "reading" : "dʒʰĭə˥",
        "SUID" : 423,
        "label" : "仕",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1162.0630806015438,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "shared_name" : "防",
        "color" : "#c8c864",
        "name" : "防",
        "reading" : "bʰĭwaŋ˩˥",
        "SUID" : 424,
        "label" : "防",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -980.2804719058917,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "425",
        "shared_name" : "豈",
        "color" : "#c89664",
        "name" : "豈",
        "reading" : "kʰĭəi˥",
        "SUID" : 425,
        "label" : "豈",
        "community" : 50,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 729.9369193984562,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "426",
        "shared_name" : "羊",
        "color" : "#c86464",
        "name" : "羊",
        "reading" : "jĭaŋ˩",
        "SUID" : 426,
        "label" : "羊",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -823.486993645022,
        "y" : -2242.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "427",
        "shared_name" : "其",
        "color" : "#c89664",
        "name" : "其",
        "reading" : "gʰĭə˩",
        "SUID" : 427,
        "label" : "其",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 907.9369193984562,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "428",
        "shared_name" : "況",
        "color" : "#c89664",
        "name" : "況",
        "reading" : "xĭwaŋ˩˥",
        "SUID" : 428,
        "label" : "況",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : 9.491267224543208,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "429",
        "shared_name" : "測",
        "color" : "#9664c8",
        "name" : "測",
        "reading" : "ʧʰĭək",
        "SUID" : 429,
        "label" : "測",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 589.4369193984562,
        "y" : 75.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "430",
        "shared_name" : "遇",
        "color" : "#64c8c8",
        "name" : "遇",
        "reading" : "ŋĭu˩˥",
        "SUID" : 430,
        "label" : "遇",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 1066.9586585288912,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "431",
        "shared_name" : "署",
        "color" : "#9664c8",
        "name" : "署",
        "reading" : "ʑĭo˩˥",
        "SUID" : 431,
        "label" : "署",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1700.9803976593257,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "432",
        "shared_name" : "央",
        "color" : "#96c864",
        "name" : "央",
        "reading" : "ʔĭaŋ˥˩",
        "SUID" : 432,
        "label" : "央",
        "community" : 1,
        "selected" : false,
        "group" : "' j"
      },
      "position" : {
        "x" : 1295.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "433",
        "shared_name" : "朽",
        "color" : "#c89664",
        "name" : "朽",
        "reading" : "xĭəu˥",
        "SUID" : 433,
        "label" : "朽",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -85.50873277545679,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "434",
        "shared_name" : "相",
        "color" : "#6496c8",
        "name" : "相",
        "reading" : "sĭaŋ˩˥",
        "SUID" : 434,
        "label" : "相",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -126.04134147110904,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "435",
        "shared_name" : "強",
        "color" : "#c89664",
        "name" : "強",
        "reading" : "gʰĭaŋ˩",
        "SUID" : 435,
        "label" : "強",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1108.9695280941082,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "436",
        "shared_name" : "傷",
        "color" : "#6496c8",
        "name" : "傷",
        "reading" : "ɕĭaŋ˩˥",
        "SUID" : 436,
        "label" : "傷",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -804.0630806015438,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "437",
        "shared_name" : "舉",
        "color" : "#c89664",
        "name" : "舉",
        "reading" : "kĭo˥",
        "SUID" : 437,
        "label" : "舉",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1212.4369193984562,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "甫",
        "color" : "#c8c864",
        "name" : "甫",
        "reading" : "pĭu˥",
        "SUID" : 438,
        "label" : "甫",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -634.5196023406743,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "shared_name" : "芳",
        "color" : "#c8c864",
        "name" : "芳",
        "reading" : "pʰĭwaŋ˥˩",
        "SUID" : 439,
        "label" : "芳",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1484.0304719058918,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "440",
        "shared_name" : "雨",
        "color" : "#96c864",
        "name" : "雨",
        "reading" : "ĭu˩˥",
        "SUID" : 440,
        "label" : "雨",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -512.5630806015438,
        "y" : -2242.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "441",
        "shared_name" : "無",
        "color" : "#64c896",
        "name" : "無",
        "reading" : "mĭu˩",
        "SUID" : 441,
        "label" : "無",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1559.6616746469124,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "442",
        "shared_name" : "俟",
        "color" : "#6496c8",
        "name" : "俟",
        "reading" : "gʰĭəi˩",
        "SUID" : 442,
        "label" : "俟",
        "community" : 18,
        "selected" : false,
        "group" : "zr j"
      },
      "position" : {
        "x" : 1061.4695280941082,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "443",
        "shared_name" : "赤",
        "color" : "#9664c8",
        "name" : "赤",
        "reading" : "tɕʰĭɛk",
        "SUID" : 443,
        "label" : "赤",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "444",
        "shared_name" : "里",
        "color" : "#6464c8",
        "name" : "里",
        "reading" : "lĭə˥",
        "SUID" : 444,
        "label" : "里",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -397.0630806015438,
        "y" : 656.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "445",
        "shared_name" : "似",
        "color" : "#6496c8",
        "name" : "似",
        "reading" : "zĭə˥",
        "SUID" : 445,
        "label" : "似",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1294.0304719058915,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "446",
        "shared_name" : "語",
        "color" : "#64c8c8",
        "name" : "語",
        "reading" : "ŋĭo˥",
        "SUID" : 446,
        "label" : "語",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 734.4586585288912,
        "y" : -850.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "447",
        "shared_name" : "市",
        "color" : "#9664c8",
        "name" : "市",
        "reading" : "ʑĭə˥",
        "SUID" : 447,
        "label" : "市",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1795.9803976593257,
        "y" : -2242.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "448",
        "shared_name" : "與",
        "color" : "#c86464",
        "name" : "與",
        "reading" : "jĭo˩",
        "SUID" : 448,
        "label" : "與",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1248.7587327754568,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "449",
        "shared_name" : "止",
        "color" : "#9664c8",
        "name" : "止",
        "reading" : "tɕĭə˥",
        "SUID" : 449,
        "label" : "止",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 488.9170706271898,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "450",
        "shared_name" : "喜",
        "color" : "#c89664",
        "name" : "喜",
        "reading" : "xĭə˥",
        "SUID" : 450,
        "label" : "喜",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -350.5630806015438,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "451",
        "shared_name" : "牛",
        "color" : "#64c8c8",
        "name" : "牛",
        "reading" : "ŋĭəu˩",
        "SUID" : 451,
        "label" : "牛",
        "community" : 43,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 1019.4586585288912,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "452",
        "shared_name" : "丘",
        "color" : "#c89664",
        "name" : "丘",
        "reading" : "kʰĭəu˥˩",
        "SUID" : 452,
        "label" : "丘",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1109.9369193984562,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "453",
        "shared_name" : "醉",
        "color" : "#c89664",
        "name" : "醉",
        "reading" : "tswi˩˥",
        "SUID" : 453,
        "label" : "醉",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1223.2967762537178,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "454",
        "shared_name" : "丁",
        "color" : "#9664c8",
        "name" : "丁",
        "reading" : "ţæŋ˥˩",
        "SUID" : 454,
        "label" : "丁",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 1235.4369193984562,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "455",
        "shared_name" : "叉",
        "color" : "#9664c8",
        "name" : "叉",
        "reading" : "ʧʰai˥˩",
        "SUID" : 455,
        "label" : "叉",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh "
      },
      "position" : {
        "x" : 615.9586585288912,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "456",
        "shared_name" : "洧",
        "color" : "#96c864",
        "name" : "洧",
        "reading" : "wi˥",
        "SUID" : 456,
        "label" : "洧",
        "community" : 56,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -406.53047190589155,
        "y" : -1552.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "457",
        "shared_name" : "視",
        "color" : "#9664c8",
        "name" : "視",
        "reading" : "ʑi˥",
        "SUID" : 457,
        "label" : "視",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1795.9803976593257,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "458",
        "shared_name" : "儒",
        "color" : "#64c8c8",
        "name" : "儒",
        "reading" : "nʑĭu˩",
        "SUID" : 458,
        "label" : "儒",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 557.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "459",
        "shared_name" : "取",
        "color" : "#9664c8",
        "name" : "取",
        "reading" : "tsʰĭu˥",
        "SUID" : 459,
        "label" : "取",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 2183.9803976593257,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "460",
        "shared_name" : "處",
        "color" : "#9664c8",
        "name" : "處",
        "reading" : "tɕʰĭo˩˥",
        "SUID" : 460,
        "label" : "處",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : -1732.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "461",
        "shared_name" : "䟽",
        "color" : "#6496c8",
        "name" : "䟽",
        "reading" : "ʃĭo˩˥",
        "SUID" : 461,
        "label" : "䟽",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1290.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "462",
        "shared_name" : "旨",
        "color" : "#9664c8",
        "name" : "旨",
        "reading" : "tɕi˥",
        "SUID" : 462,
        "label" : "旨",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 549.6779401924073,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "463",
        "shared_name" : "恱",
        "color" : "#c86464",
        "name" : "恱",
        "reading" : "jĭwɛt",
        "SUID" : 463,
        "label" : "恱",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1013.486993645022,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "464",
        "shared_name" : "側",
        "color" : "#9664c8",
        "name" : "側",
        "reading" : "ʧĭək",
        "SUID" : 464,
        "label" : "側",
        "community" : 42,
        "selected" : false,
        "group" : "tsr j"
      },
      "position" : {
        "x" : -540.5630806015438,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "465",
        "shared_name" : "叱",
        "color" : "",
        "name" : "叱",
        "reading" : "",
        "SUID" : 465,
        "label" : "叱",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 816.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "466",
        "shared_name" : "竹",
        "color" : "#9664c8",
        "name" : "竹",
        "reading" : "ţĭuk",
        "SUID" : 466,
        "label" : "竹",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1458.6434411375867,
        "y" : -850.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "467",
        "shared_name" : "遵",
        "color" : "#c89664",
        "name" : "遵",
        "reading" : "tsĭuĕn˥˩",
        "SUID" : 467,
        "label" : "遵",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1318.2967762537178,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "468",
        "shared_name" : "姊",
        "color" : "",
        "name" : "姊",
        "reading" : "",
        "SUID" : 468,
        "label" : "姊",
        "selected" : false,
        "group" : ""
      },
      "position" : {
        "x" : 937.4369193984562,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "469",
        "shared_name" : "人",
        "color" : "#64c8c8",
        "name" : "人",
        "reading" : "nʑĭĕn˩",
        "SUID" : 469,
        "label" : "人",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 604.9369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "470",
        "shared_name" : "山",
        "color" : "#6496c8",
        "name" : "山",
        "reading" : "ʃæn˥˩",
        "SUID" : 470,
        "label" : "山",
        "community" : 21,
        "selected" : false,
        "group" : "sr "
      },
      "position" : {
        "x" : 1480.4369193984562,
        "y" : 892.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "471",
        "shared_name" : "香",
        "color" : "#c89664",
        "name" : "香",
        "reading" : "xĭaŋ˥˩",
        "SUID" : 471,
        "label" : "香",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -275.5087327754568,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "472",
        "shared_name" : "此",
        "color" : "#9664c8",
        "name" : "此",
        "reading" : "tsʰĭe˥",
        "SUID" : 472,
        "label" : "此",
        "community" : 59,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : -272.5630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "473",
        "shared_name" : "武",
        "color" : "#64c896",
        "name" : "武",
        "reading" : "mĭu˥",
        "SUID" : 473,
        "label" : "武",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1495.0630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "474",
        "shared_name" : "式",
        "color" : "#6496c8",
        "name" : "式",
        "reading" : "ɕĭək",
        "SUID" : 474,
        "label" : "式",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -661.5630806015438,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "475",
        "shared_name" : "汝",
        "color" : "#64c8c8",
        "name" : "汝",
        "reading" : "nʑĭo˥",
        "SUID" : 475,
        "label" : "汝",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 652.4369193984562,
        "y" : 541.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "476",
        "shared_name" : "巨",
        "color" : "#c89664",
        "name" : "巨",
        "reading" : "gʰĭo˥",
        "SUID" : 476,
        "label" : "巨",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1251.4695280941082,
        "y" : -2242.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "477",
        "shared_name" : "旬",
        "color" : "#6496c8",
        "name" : "旬",
        "reading" : "zĭuĕn˩",
        "SUID" : 477,
        "label" : "旬",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1579.0304719058915,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "shared_name" : "彼",
        "color" : "#c8c864",
        "name" : "彼",
        "reading" : "pĭe˥",
        "SUID" : 478,
        "label" : "彼",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -539.5196023406743,
        "y" : -1086.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "479",
        "shared_name" : "是",
        "color" : "#9664c8",
        "name" : "是",
        "reading" : "ʑĭe˥",
        "SUID" : 479,
        "label" : "是",
        "community" : 20,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 1605.9803976593257,
        "y" : -1782.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "480",
        "shared_name" : "靡",
        "color" : "#64c896",
        "name" : "靡",
        "reading" : "mĭe˥",
        "SUID" : 480,
        "label" : "靡",
        "community" : 8,
        "selected" : false,
        "group" : "m j"
      },
      "position" : {
        "x" : -1776.6391675580655,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "481",
        "shared_name" : "薳",
        "color" : "#96c864",
        "name" : "薳",
        "reading" : "ĭwe˥",
        "SUID" : 481,
        "label" : "薳",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -607.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "482",
        "shared_name" : "弋",
        "color" : "#c86464",
        "name" : "弋",
        "reading" : "jĭək",
        "SUID" : 482,
        "label" : "弋",
        "community" : 58,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1060.986993645022,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "483",
        "shared_name" : "章",
        "color" : "#9664c8",
        "name" : "章",
        "reading" : "tɕĭaŋ˥˩",
        "SUID" : 483,
        "label" : "章",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 141.9369193984562,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "484",
        "shared_name" : "士",
        "color" : "#9664c8",
        "name" : "士",
        "reading" : "dʒʰĭə˥",
        "SUID" : 484,
        "label" : "士",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -972.0630806015438,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "485",
        "shared_name" : "宅",
        "color" : "#9664c8",
        "name" : "宅",
        "reading" : "ɖʰɐk",
        "SUID" : 485,
        "label" : "宅",
        "community" : 9,
        "selected" : false,
        "group" : "dr "
      },
      "position" : {
        "x" : -1257.5630806015438,
        "y" : 1007.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "486",
        "shared_name" : "握",
        "color" : "#96c864",
        "name" : "握",
        "reading" : "ʔɔk",
        "SUID" : 486,
        "label" : "握",
        "community" : 1,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1580.4369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "487",
        "shared_name" : "所",
        "color" : "#6496c8",
        "name" : "所",
        "reading" : "ʃĭo˥",
        "SUID" : 487,
        "label" : "所",
        "community" : 21,
        "selected" : false,
        "group" : "sr j"
      },
      "position" : {
        "x" : 1622.9369193984562,
        "y" : 777.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "488",
        "shared_name" : "吕",
        "color" : "#6464c8",
        "name" : "吕",
        "reading" : "lĭo˥",
        "SUID" : 488,
        "label" : "吕",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -444.5630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "shared_name" : "匹",
        "color" : "#c8c864",
        "name" : "匹",
        "reading" : "pʰĭĕt",
        "SUID" : 489,
        "label" : "匹",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1015.5630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "490",
        "shared_name" : "下",
        "color" : "#96c864",
        "name" : "下",
        "reading" : "ɣa˩˥",
        "SUID" : 490,
        "label" : "下",
        "community" : 28,
        "selected" : false,
        "group" : "h "
      },
      "position" : {
        "x" : 415.4369193984562,
        "y" : 1358.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "491",
        "shared_name" : "博",
        "color" : "#c8c864",
        "name" : "博",
        "reading" : "puɑk",
        "SUID" : 491,
        "label" : "博",
        "community" : 14,
        "selected" : false,
        "group" : "p "
      },
      "position" : {
        "x" : -851.5630806015438,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "492",
        "shared_name" : "楚",
        "color" : "#9664c8",
        "name" : "楚",
        "reading" : "ʧʰĭo˥",
        "SUID" : 492,
        "label" : "楚",
        "community" : 35,
        "selected" : false,
        "group" : "tsrh j"
      },
      "position" : {
        "x" : 555.1977889636737,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "493",
        "shared_name" : "曲",
        "color" : "#c89664",
        "name" : "曲",
        "reading" : "kʰĭwok",
        "SUID" : 493,
        "label" : "曲",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 1109.9369193984562,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "494",
        "shared_name" : "七",
        "color" : "#9664c8",
        "name" : "七",
        "reading" : "tsʰĭĕt",
        "SUID" : 494,
        "label" : "七",
        "community" : 12,
        "selected" : false,
        "group" : "tsh j"
      },
      "position" : {
        "x" : 1803.9803976593257,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "495",
        "shared_name" : "九",
        "color" : "#c89664",
        "name" : "九",
        "reading" : "kĭəu˥",
        "SUID" : 495,
        "label" : "九",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1069.9369193984562,
        "y" : -269.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "496",
        "shared_name" : "蜀",
        "color" : "#9664c8",
        "name" : "蜀",
        "reading" : "ʑĭwok",
        "SUID" : 496,
        "label" : "蜀",
        "community" : 49,
        "selected" : false,
        "group" : "dzy j"
      },
      "position" : {
        "x" : 2076.523875920195,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "497",
        "shared_name" : "而",
        "color" : "#64c8c8",
        "name" : "而",
        "reading" : "nʑĭə˩",
        "SUID" : 497,
        "label" : "而",
        "community" : 39,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 414.9369193984562,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "498",
        "shared_name" : "即",
        "color" : "#c89664",
        "name" : "即",
        "reading" : "tsĭək",
        "SUID" : 498,
        "label" : "即",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1342.0467762537178,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "499",
        "shared_name" : "符",
        "color" : "#c8c864",
        "name" : "符",
        "reading" : "bʰĭu˩",
        "SUID" : 499,
        "label" : "符",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -980.2804719058917,
        "y" : -1431.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "500",
        "shared_name" : "丑",
        "color" : "#9664c8",
        "name" : "丑",
        "reading" : "ţʰĭəu˥",
        "SUID" : 500,
        "label" : "丑",
        "community" : 41,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : 655.9586585288912,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "501",
        "shared_name" : "疾",
        "color" : "#c89664",
        "name" : "疾",
        "reading" : "dzʰĭĕt",
        "SUID" : 501,
        "label" : "疾",
        "community" : 34,
        "selected" : false,
        "group" : "dz j"
      },
      "position" : {
        "x" : 56.43691939845621,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "502",
        "shared_name" : "女",
        "color" : "#64c8c8",
        "name" : "女",
        "reading" : "ɳĭo˩˥",
        "SUID" : 502,
        "label" : "女",
        "community" : 39,
        "selected" : false,
        "group" : "nr j"
      },
      "position" : {
        "x" : -704.5630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "503",
        "shared_name" : "於",
        "color" : "#96c864",
        "name" : "於",
        "reading" : "ʔĭo˥˩",
        "SUID" : 503,
        "label" : "於",
        "community" : 1,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1390.4369193984562,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "504",
        "shared_name" : "魚",
        "color" : "#64c8c8",
        "name" : "魚",
        "reading" : "ŋĭo˩",
        "SUID" : 504,
        "label" : "魚",
        "community" : 47,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 734.4586585288912,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "505",
        "shared_name" : "許",
        "color" : "#c89664",
        "name" : "許",
        "reading" : "xĭo˥",
        "SUID" : 505,
        "label" : "許",
        "community" : 29,
        "selected" : false,
        "group" : "x j"
      },
      "position" : {
        "x" : -133.0087327754568,
        "y" : 1243.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "府",
        "color" : "#c8c864",
        "name" : "府",
        "reading" : "pĭu˥",
        "SUID" : 506,
        "label" : "府",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -254.51960234067428,
        "y" : -1201.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "507",
        "shared_name" : "餘",
        "color" : "#c86464",
        "name" : "餘",
        "reading" : "jĭo˩",
        "SUID" : 507,
        "label" : "餘",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "508",
        "shared_name" : "尺",
        "color" : "#9664c8",
        "name" : "尺",
        "reading" : "tɕʰĭɛk",
        "SUID" : 508,
        "label" : "尺",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "509",
        "shared_name" : "祥",
        "color" : "#6496c8",
        "name" : "祥",
        "reading" : "zĭaŋ˩",
        "SUID" : 509,
        "label" : "祥",
        "community" : 24,
        "selected" : false,
        "group" : "z j"
      },
      "position" : {
        "x" : -1104.0304719058915,
        "y" : -1667.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "510",
        "shared_name" : "書",
        "color" : "#6496c8",
        "name" : "書",
        "reading" : "ɕĭo˥˩",
        "SUID" : 510,
        "label" : "書",
        "community" : 3,
        "selected" : false,
        "group" : "sy j"
      },
      "position" : {
        "x" : -851.5630806015438,
        "y" : -39.197573656845634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "511",
        "shared_name" : "私",
        "color" : "#6496c8",
        "name" : "私",
        "reading" : "si˥˩",
        "SUID" : 511,
        "label" : "私",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -627.5630806015438,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "512",
        "shared_name" : "作",
        "color" : "#c89664",
        "name" : "作",
        "reading" : "tsu˩˥",
        "SUID" : 512,
        "label" : "作",
        "community" : 51,
        "selected" : false,
        "group" : "ts "
      },
      "position" : {
        "x" : -1128.2967762537178,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "513",
        "shared_name" : "奴",
        "color" : "#64c8c8",
        "name" : "奴",
        "reading" : "nu˩",
        "SUID" : 513,
        "label" : "奴",
        "community" : 52,
        "selected" : false,
        "group" : "n "
      },
      "position" : {
        "x" : 967.4369193984562,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "514",
        "shared_name" : "藏",
        "color" : "#c89664",
        "name" : "藏",
        "reading" : "dzʰɑŋ˩",
        "SUID" : 514,
        "label" : "藏",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -946.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "515",
        "shared_name" : "都",
        "color" : "#9664c8",
        "name" : "都",
        "reading" : "tu˥˩",
        "SUID" : 515,
        "label" : "都",
        "community" : 46,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : 1230.9369193984562,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "516",
        "shared_name" : "蘇",
        "color" : "#6496c8",
        "name" : "蘇",
        "reading" : "su˥˩",
        "SUID" : 516,
        "label" : "蘇",
        "community" : 48,
        "selected" : false,
        "group" : "s "
      },
      "position" : {
        "x" : 63.958658528890965,
        "y" : -505.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "517",
        "shared_name" : "五",
        "color" : "#64c8c8",
        "name" : "五",
        "reading" : "ŋu˥",
        "SUID" : 517,
        "label" : "五",
        "community" : 44,
        "selected" : false,
        "group" : "ng j"
      },
      "position" : {
        "x" : 470.4369193984562,
        "y" : -620.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "518",
        "shared_name" : "呼",
        "color" : "#c89664",
        "name" : "呼",
        "reading" : "xu˥˩",
        "SUID" : 518,
        "label" : "呼",
        "community" : 32,
        "selected" : false,
        "group" : "x "
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "薄",
        "color" : "#c8c864",
        "name" : "薄",
        "reading" : "bʰuɑk",
        "SUID" : 519,
        "label" : "薄",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : 87.96952809410823,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "520",
        "shared_name" : "子",
        "color" : "#c89664",
        "name" : "子",
        "reading" : "tsĭə˥",
        "SUID" : 520,
        "label" : "子",
        "community" : 23,
        "selected" : false,
        "group" : "ts j"
      },
      "position" : {
        "x" : -1542.5630806015438,
        "y" : -850.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "521",
        "shared_name" : "他",
        "color" : "#9664c8",
        "name" : "他",
        "reading" : "tʰɑ˥˩",
        "SUID" : 521,
        "label" : "他",
        "community" : 31,
        "selected" : false,
        "group" : "th "
      },
      "position" : {
        "x" : -1590.0630806015438,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "522",
        "shared_name" : "倉",
        "color" : "#9664c8",
        "name" : "倉",
        "reading" : "tsʰɑŋ˥˩",
        "SUID" : 522,
        "label" : "倉",
        "community" : 12,
        "selected" : false,
        "group" : "tsh "
      },
      "position" : {
        "x" : 1803.9803976593257,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "523",
        "shared_name" : "烏",
        "color" : "#96c864",
        "name" : "烏",
        "reading" : "ʔu˥˩",
        "SUID" : 523,
        "label" : "烏",
        "community" : 40,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 1069.9369193984562,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "524",
        "shared_name" : "徂",
        "color" : "#c89664",
        "name" : "徂",
        "reading" : "dzʰu˩",
        "SUID" : 524,
        "label" : "徂",
        "community" : 37,
        "selected" : false,
        "group" : "dz "
      },
      "position" : {
        "x" : -1231.5630806015438,
        "y" : 1594.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "525",
        "shared_name" : "戸",
        "color" : "#c86464",
        "name" : "戸",
        "reading" : "ɣu˥",
        "SUID" : 525,
        "label" : "戸",
        "community" : 28,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : 568.9695280941082,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "526",
        "shared_name" : "盧",
        "color" : "#6464c8",
        "name" : "盧",
        "reading" : "lu˩",
        "SUID" : 526,
        "label" : "盧",
        "community" : 36,
        "selected" : false,
        "group" : "l "
      },
      "position" : {
        "x" : 318.9369193984562,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "527",
        "shared_name" : "古",
        "color" : "#c89664",
        "name" : "古",
        "reading" : "ku˥",
        "SUID" : 527,
        "label" : "古",
        "community" : 11,
        "selected" : false,
        "group" : "k "
      },
      "position" : {
        "x" : -234.0630806015438,
        "y" : 777.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "528",
        "shared_name" : "苦",
        "color" : "#c89664",
        "name" : "苦",
        "reading" : "kʰu˥",
        "SUID" : 528,
        "label" : "苦",
        "community" : 15,
        "selected" : false,
        "group" : "kh "
      },
      "position" : {
        "x" : 741.9369193984562,
        "y" : 777.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "529",
        "shared_name" : "力",
        "color" : "#6464c8",
        "name" : "力",
        "reading" : "lĭək",
        "SUID" : 529,
        "label" : "力",
        "community" : 13,
        "selected" : false,
        "group" : "l j"
      },
      "position" : {
        "x" : -444.5630806015438,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "530",
        "shared_name" : "昌",
        "color" : "#9664c8",
        "name" : "昌",
        "reading" : "tɕʰĭaŋ˥˩",
        "SUID" : 530,
        "label" : "昌",
        "community" : 45,
        "selected" : false,
        "group" : "tsyh j"
      },
      "position" : {
        "x" : -1685.0630806015438,
        "y" : 1830.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "敷",
        "color" : "#c8c864",
        "name" : "敷",
        "reading" : "pʰĭu˥˩",
        "SUID" : 531,
        "label" : "敷",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1637.5630806015438,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "shared_name" : "方",
        "color" : "#c8c864",
        "name" : "方",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 532,
        "label" : "方",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -161.74786321023953,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "shared_name" : "房",
        "color" : "#c8c864",
        "name" : "房",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 533,
        "label" : "房",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1400.0630806015438,
        "y" : -1316.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "534",
        "shared_name" : "渠",
        "color" : "#c89664",
        "name" : "渠",
        "reading" : "gʰĭo˩",
        "SUID" : 534,
        "label" : "渠",
        "community" : 17,
        "selected" : false,
        "group" : "g j"
      },
      "position" : {
        "x" : 1108.9695280941082,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "535",
        "shared_name" : "去",
        "color" : "#c89664",
        "name" : "去",
        "reading" : "kʰĭo˥",
        "SUID" : 535,
        "label" : "去",
        "community" : 4,
        "selected" : false,
        "group" : "kh j"
      },
      "position" : {
        "x" : 967.4369193984562,
        "y" : -1431.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "536",
        "shared_name" : "莫",
        "color" : "#64c896",
        "name" : "莫",
        "reading" : "mɑk",
        "SUID" : 536,
        "label" : "莫",
        "community" : 33,
        "selected" : false,
        "group" : "m "
      },
      "position" : {
        "x" : 1665.9369193984562,
        "y" : 1128.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "537",
        "shared_name" : "羽",
        "color" : "#96c864",
        "name" : "羽",
        "reading" : "ĭu˩˥",
        "SUID" : 537,
        "label" : "羽",
        "community" : 6,
        "selected" : false,
        "group" : "h j"
      },
      "position" : {
        "x" : -264.0304719058918,
        "y" : -2012.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "538",
        "shared_name" : "以",
        "color" : "#c86464",
        "name" : "以",
        "reading" : "jĭə˥",
        "SUID" : 538,
        "label" : "以",
        "community" : 27,
        "selected" : false,
        "group" : "y j"
      },
      "position" : {
        "x" : -1685.0630806015438,
        "y" : -2127.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "539",
        "shared_name" : "居",
        "color" : "#c89664",
        "name" : "居",
        "reading" : "kĭo˥˩",
        "SUID" : 539,
        "label" : "居",
        "community" : 22,
        "selected" : false,
        "group" : "k j"
      },
      "position" : {
        "x" : 1069.9369193984562,
        "y" : -154.19757365684563
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "540",
        "shared_name" : "如",
        "color" : "#64c8c8",
        "name" : "如",
        "reading" : "nʑĭo˩˥",
        "SUID" : 540,
        "label" : "如",
        "community" : 38,
        "selected" : false,
        "group" : "ny j"
      },
      "position" : {
        "x" : 604.9369193984562,
        "y" : 311.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "541",
        "shared_name" : "息",
        "color" : "#6496c8",
        "name" : "息",
        "reading" : "sĭək",
        "SUID" : 541,
        "label" : "息",
        "community" : 7,
        "selected" : false,
        "group" : "s j"
      },
      "position" : {
        "x" : -342.5630806015438,
        "y" : -850.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "542",
        "shared_name" : "鋤",
        "color" : "#9664c8",
        "name" : "鋤",
        "reading" : "dʒʰĭo˩",
        "SUID" : 542,
        "label" : "鋤",
        "community" : 18,
        "selected" : false,
        "group" : "dzr j"
      },
      "position" : {
        "x" : -1067.0630806015438,
        "y" : 426.80242634315437
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "543",
        "shared_name" : "敕",
        "color" : "#96c864",
        "name" : "敕",
        "reading" : "ţʰĭək",
        "SUID" : 543,
        "label" : "敕",
        "community" : 41,
        "selected" : false,
        "group" : "' "
      },
      "position" : {
        "x" : 595.1977889636737,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "544",
        "shared_name" : "職",
        "color" : "#9664c8",
        "name" : "職",
        "reading" : "tɕĭək",
        "SUID" : 544,
        "label" : "職",
        "community" : 5,
        "selected" : false,
        "group" : "tsy j"
      },
      "position" : {
        "x" : 549.6779401924073,
        "y" : -1897.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "545",
        "shared_name" : "直",
        "color" : "#9664c8",
        "name" : "直",
        "reading" : "ɖʰĭək",
        "SUID" : 545,
        "label" : "直",
        "community" : 9,
        "selected" : false,
        "group" : "dr j"
      },
      "position" : {
        "x" : -1305.0630806015438,
        "y" : 777.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "546",
        "shared_name" : "陟",
        "color" : "#9664c8",
        "name" : "陟",
        "reading" : "ţĭək",
        "SUID" : 546,
        "label" : "陟",
        "community" : 19,
        "selected" : false,
        "group" : "tr j"
      },
      "position" : {
        "x" : 1615.4369193984562,
        "y" : -735.1975736568456
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "547",
        "shared_name" : "徒",
        "color" : "#9664c8",
        "name" : "徒",
        "reading" : "dʰu˩",
        "SUID" : 547,
        "label" : "徒",
        "community" : 30,
        "selected" : false,
        "group" : "d "
      },
      "position" : {
        "x" : 1947.4369193984562,
        "y" : 1479.8024263431544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "548",
        "shared_name" : "德",
        "color" : "#9664c8",
        "name" : "德",
        "reading" : "tək",
        "SUID" : 548,
        "label" : "德",
        "community" : 54,
        "selected" : false,
        "group" : "t "
      },
      "position" : {
        "x" : -488.5630806015438,
        "y" : 1945.8024263431544
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "3008",
        "source" : "64",
        "target" : "2439",
        "shared_name" : "乗 (interacts with) 食2",
        "shared_interaction" : "interacts with",
        "name" : "乗 (interacts with) 食2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3007",
        "source" : "65",
        "target" : "543",
        "shared_name" : "恥 (interacts with) 敕",
        "shared_interaction" : "interacts with",
        "name" : "恥 (interacts with) 敕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3007,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3006",
        "source" : "66",
        "target" : "529",
        "shared_name" : "林 (interacts with) 力",
        "shared_interaction" : "interacts with",
        "name" : "林 (interacts with) 力",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3006,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3005",
        "source" : "72",
        "target" : "485",
        "shared_name" : "場 (interacts with) 宅",
        "shared_interaction" : "interacts with",
        "name" : "場 (interacts with) 宅",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3004",
        "source" : "74",
        "target" : "2436",
        "shared_name" : "慕 (interacts with) 摸2",
        "shared_interaction" : "interacts with",
        "name" : "慕 (interacts with) 摸2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3004,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3003",
        "source" : "74",
        "target" : "536",
        "shared_name" : "慕 (interacts with) 莫",
        "shared_interaction" : "interacts with",
        "name" : "慕 (interacts with) 莫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3002",
        "source" : "94",
        "target" : "312",
        "shared_name" : "鄙 (interacts with) 筆",
        "shared_interaction" : "interacts with",
        "name" : "鄙 (interacts with) 筆",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3001",
        "source" : "96",
        "target" : "489",
        "shared_name" : "譬 (interacts with) 匹",
        "shared_interaction" : "interacts with",
        "name" : "譬 (interacts with) 匹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3001,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "3000",
        "source" : "110",
        "target" : "297",
        "shared_name" : "伊 (interacts with) 挹",
        "shared_interaction" : "interacts with",
        "name" : "伊 (interacts with) 挹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 3000,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2999",
        "source" : "113",
        "target" : "2432",
        "shared_name" : "實 (interacts with) 乗2",
        "shared_interaction" : "interacts with",
        "name" : "實 (interacts with) 乗2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2998",
        "source" : "118",
        "target" : "2424",
        "shared_name" : "巫 (interacts with) 望2",
        "shared_interaction" : "interacts with",
        "name" : "巫 (interacts with) 望2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2998,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2997",
        "source" : "126",
        "target" : "2419",
        "shared_name" : "婢 (interacts with) 便2",
        "shared_interaction" : "interacts with",
        "name" : "婢 (interacts with) 便2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2996",
        "source" : "133",
        "target" : "242",
        "shared_name" : "吾 (interacts with) 研",
        "shared_interaction" : "interacts with",
        "name" : "吾 (interacts with) 研",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2995",
        "source" : "142",
        "target" : "2412",
        "shared_name" : "湯 (interacts with) 吐2",
        "shared_interaction" : "interacts with",
        "name" : "湯 (interacts with) 吐2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2995,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2994",
        "source" : "146",
        "target" : "2409",
        "shared_name" : "瘡 (interacts with) 楚2",
        "shared_interaction" : "interacts with",
        "name" : "瘡 (interacts with) 楚2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2994,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2993",
        "source" : "147",
        "target" : "2406",
        "shared_name" : "遟 (interacts with) 除2",
        "shared_interaction" : "interacts with",
        "name" : "遟 (interacts with) 除2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2992",
        "source" : "150",
        "target" : "2405",
        "shared_name" : "近 (interacts with) 去2",
        "shared_interaction" : "interacts with",
        "name" : "近 (interacts with) 去2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2992,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2991",
        "source" : "155",
        "target" : "501",
        "shared_name" : "秦 (interacts with) 疾",
        "shared_interaction" : "interacts with",
        "name" : "秦 (interacts with) 疾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2990",
        "source" : "156",
        "target" : "2438",
        "shared_name" : "資 (interacts with) 借2",
        "shared_interaction" : "interacts with",
        "name" : "資 (interacts with) 借2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2990,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2989",
        "source" : "158",
        "target" : "229",
        "shared_name" : "詰 (interacts with) 弃",
        "shared_interaction" : "interacts with",
        "name" : "詰 (interacts with) 弃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2989,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2988",
        "source" : "172",
        "target" : "2411",
        "shared_name" : "區 (interacts with) 驅2",
        "shared_interaction" : "interacts with",
        "name" : "區 (interacts with) 驅2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2988,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2987",
        "source" : "187",
        "target" : "474",
        "shared_name" : "賞 (interacts with) 式",
        "shared_interaction" : "interacts with",
        "name" : "賞 (interacts with) 式",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2986",
        "source" : "187",
        "target" : "2441",
        "shared_name" : "賞 (interacts with) 識2",
        "shared_interaction" : "interacts with",
        "name" : "賞 (interacts with) 識2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2986,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2985",
        "source" : "196",
        "target" : "2392",
        "shared_name" : "麁 (interacts with) 蒼2",
        "shared_interaction" : "interacts with",
        "name" : "麁 (interacts with) 蒼2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2984",
        "source" : "204",
        "target" : "323",
        "shared_name" : "悉 (interacts with) 寫",
        "shared_interaction" : "interacts with",
        "name" : "悉 (interacts with) 寫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2983",
        "source" : "207",
        "target" : "358",
        "shared_name" : "枯 (interacts with) 可",
        "shared_interaction" : "interacts with",
        "name" : "枯 (interacts with) 可",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2983,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2982",
        "source" : "208",
        "target" : "494",
        "shared_name" : "親 (interacts with) 七",
        "shared_interaction" : "interacts with",
        "name" : "親 (interacts with) 七",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2981",
        "source" : "214",
        "target" : "545",
        "shared_name" : "除 (interacts with) 直",
        "shared_interaction" : "interacts with",
        "name" : "除 (interacts with) 直",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2980",
        "source" : "227",
        "target" : "340",
        "shared_name" : "云 (interacts with) 有",
        "shared_interaction" : "interacts with",
        "name" : "云 (interacts with) 有",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2980,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2979",
        "source" : "233",
        "target" : "2435",
        "shared_name" : "毗 (interacts with) 比5",
        "shared_interaction" : "interacts with",
        "name" : "毗 (interacts with) 比5",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2978",
        "source" : "233",
        "target" : "2401",
        "shared_name" : "毗 (interacts with) 比3",
        "shared_interaction" : "interacts with",
        "name" : "毗 (interacts with) 比3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2977",
        "source" : "241",
        "target" : "491",
        "shared_name" : "補 (interacts with) 博",
        "shared_interaction" : "interacts with",
        "name" : "補 (interacts with) 博",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2977,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2976",
        "source" : "243",
        "target" : "294",
        "shared_name" : "傍 (interacts with) 白",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 白",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2976,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2975",
        "source" : "243",
        "target" : "519",
        "shared_name" : "傍 (interacts with) 薄",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 薄",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2974",
        "source" : "244",
        "target" : "525",
        "shared_name" : "侯 (interacts with) 戸",
        "shared_interaction" : "interacts with",
        "name" : "侯 (interacts with) 戸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2974,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2973",
        "source" : "246",
        "target" : "404",
        "shared_name" : "裴 (interacts with) 部",
        "shared_interaction" : "interacts with",
        "name" : "裴 (interacts with) 部",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2972",
        "source" : "247",
        "target" : "517",
        "shared_name" : "疑 (interacts with) 五",
        "shared_interaction" : "interacts with",
        "name" : "疑 (interacts with) 五",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2971",
        "source" : "254",
        "target" : "535",
        "shared_name" : "羌 (interacts with) 去",
        "shared_interaction" : "interacts with",
        "name" : "羌 (interacts with) 去",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2970",
        "source" : "255",
        "target" : "2395",
        "shared_name" : "慈 (interacts with) 漸2",
        "shared_interaction" : "interacts with",
        "name" : "慈 (interacts with) 漸2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2970,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2969",
        "source" : "256",
        "target" : "492",
        "shared_name" : "創 (interacts with) 楚",
        "shared_interaction" : "interacts with",
        "name" : "創 (interacts with) 楚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2968",
        "source" : "257",
        "target" : "502",
        "shared_name" : "尼 (interacts with) 女",
        "shared_interaction" : "interacts with",
        "name" : "尼 (interacts with) 女",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2967",
        "source" : "260",
        "target" : "425",
        "shared_name" : "袪 (interacts with) 豈",
        "shared_interaction" : "interacts with",
        "name" : "袪 (interacts with) 豈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2966",
        "source" : "261",
        "target" : "319",
        "shared_name" : "牀 (interacts with) 助",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 助",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2965",
        "source" : "261",
        "target" : "2385",
        "shared_name" : "牀 (interacts with) 鉏2",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 鉏2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2964",
        "source" : "261",
        "target" : "2382",
        "shared_name" : "牀 (interacts with) 俟2",
        "shared_interaction" : "interacts with",
        "name" : "牀 (interacts with) 俟2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2964,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2963",
        "source" : "262",
        "target" : "120",
        "shared_name" : "詩 (interacts with) 始",
        "shared_interaction" : "interacts with",
        "name" : "詩 (interacts with) 始",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2962",
        "source" : "264",
        "target" : "444",
        "shared_name" : "良 (interacts with) 里",
        "shared_interaction" : "interacts with",
        "name" : "良 (interacts with) 里",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2961",
        "source" : "265",
        "target" : "487",
        "shared_name" : "踈 (interacts with) 所",
        "shared_interaction" : "interacts with",
        "name" : "踈 (interacts with) 所",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2960",
        "source" : "265",
        "target" : "296",
        "shared_name" : "踈 (interacts with) 史",
        "shared_interaction" : "interacts with",
        "name" : "踈 (interacts with) 史",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2959",
        "source" : "269",
        "target" : "456",
        "shared_name" : "榮 (interacts with) 洧",
        "shared_interaction" : "interacts with",
        "name" : "榮 (interacts with) 洧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2959,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2958",
        "source" : "271",
        "target" : "113",
        "shared_name" : "神 (interacts with) 實",
        "shared_interaction" : "interacts with",
        "name" : "神 (interacts with) 實",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2958,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2957",
        "source" : "273",
        "target" : "152",
        "shared_name" : "施 (interacts with) 釋",
        "shared_interaction" : "interacts with",
        "name" : "施 (interacts with) 釋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2956",
        "source" : "273",
        "target" : "2399",
        "shared_name" : "施 (interacts with) 施2",
        "shared_interaction" : "interacts with",
        "name" : "施 (interacts with) 施2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2955",
        "source" : "274",
        "target" : "126",
        "shared_name" : "便 (interacts with) 婢",
        "shared_interaction" : "interacts with",
        "name" : "便 (interacts with) 婢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2954",
        "source" : "281",
        "target" : "472",
        "shared_name" : "雌 (interacts with) 此",
        "shared_interaction" : "interacts with",
        "name" : "雌 (interacts with) 此",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2954,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2953",
        "source" : "282",
        "target" : "481",
        "shared_name" : "韋 (interacts with) 薳",
        "shared_interaction" : "interacts with",
        "name" : "韋 (interacts with) 薳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2952",
        "source" : "283",
        "target" : "337",
        "shared_name" : "墟 (interacts with) 起",
        "shared_interaction" : "interacts with",
        "name" : "墟 (interacts with) 起",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2951",
        "source" : "283",
        "target" : "309",
        "shared_name" : "墟 (interacts with) 綺",
        "shared_interaction" : "interacts with",
        "name" : "墟 (interacts with) 綺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2950",
        "source" : "284",
        "target" : "169",
        "shared_name" : "過 (interacts with) 詭",
        "shared_interaction" : "interacts with",
        "name" : "過 (interacts with) 詭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2949",
        "source" : "285",
        "target" : "473",
        "shared_name" : "文 (interacts with) 武",
        "shared_interaction" : "interacts with",
        "name" : "文 (interacts with) 武",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2949,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2948",
        "source" : "285",
        "target" : "480",
        "shared_name" : "文 (interacts with) 靡",
        "shared_interaction" : "interacts with",
        "name" : "文 (interacts with) 靡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2948,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2947",
        "source" : "286",
        "target" : "457",
        "shared_name" : "承 (interacts with) 視",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 視",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2946",
        "source" : "286",
        "target" : "2378",
        "shared_name" : "承 (interacts with) 氏3",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 氏3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2945",
        "source" : "286",
        "target" : "479",
        "shared_name" : "承 (interacts with) 是",
        "shared_interaction" : "interacts with",
        "name" : "承 (interacts with) 是",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2944",
        "source" : "289",
        "target" : "447",
        "shared_name" : "時 (interacts with) 市",
        "shared_interaction" : "interacts with",
        "name" : "時 (interacts with) 市",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2943",
        "source" : "290",
        "target" : "544",
        "shared_name" : "之 (interacts with) 職",
        "shared_interaction" : "interacts with",
        "name" : "之 (interacts with) 職",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2942",
        "source" : "290",
        "target" : "2431",
        "shared_name" : "之 (interacts with) 正2",
        "shared_interaction" : "interacts with",
        "name" : "之 (interacts with) 正2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2941",
        "source" : "291",
        "target" : "528",
        "shared_name" : "康 (interacts with) 苦",
        "shared_interaction" : "interacts with",
        "name" : "康 (interacts with) 苦",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2940",
        "source" : "292",
        "target" : "2377",
        "shared_name" : "僕 (interacts with) 平3",
        "shared_interaction" : "interacts with",
        "name" : "僕 (interacts with) 平3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2939",
        "source" : "299",
        "target" : "2423",
        "shared_name" : "知 (interacts with) 張2",
        "shared_interaction" : "interacts with",
        "name" : "知 (interacts with) 張2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2938",
        "source" : "299",
        "target" : "2387",
        "shared_name" : "知 (interacts with) 柱2",
        "shared_interaction" : "interacts with",
        "name" : "知 (interacts with) 柱2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2937",
        "source" : "306",
        "target" : "259",
        "shared_name" : "縛 (interacts with) 浮",
        "shared_interaction" : "interacts with",
        "name" : "縛 (interacts with) 浮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2937,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2936",
        "source" : "310",
        "target" : "505",
        "shared_name" : "虛 (interacts with) 許",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 許",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2936,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2935",
        "source" : "310",
        "target" : "450",
        "shared_name" : "虛 (interacts with) 喜",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 喜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2935,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2934",
        "source" : "310",
        "target" : "270",
        "shared_name" : "虛 (interacts with) 興",
        "shared_interaction" : "interacts with",
        "name" : "虛 (interacts with) 興",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2933",
        "source" : "314",
        "target" : "305",
        "shared_name" : "桑 (interacts with) 速",
        "shared_interaction" : "interacts with",
        "name" : "桑 (interacts with) 速",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2932",
        "source" : "314",
        "target" : "415",
        "shared_name" : "桑 (interacts with) 素",
        "shared_interaction" : "interacts with",
        "name" : "桑 (interacts with) 素",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2931",
        "source" : "316",
        "target" : "2383",
        "shared_name" : "余 (interacts with) 與2",
        "shared_interaction" : "interacts with",
        "name" : "余 (interacts with) 與2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2930",
        "source" : "316",
        "target" : "68",
        "shared_name" : "余 (interacts with) 營",
        "shared_interaction" : "interacts with",
        "name" : "余 (interacts with) 營",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2930,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2929",
        "source" : "317",
        "target" : "454",
        "shared_name" : "中 (interacts with) 丁",
        "shared_interaction" : "interacts with",
        "name" : "中 (interacts with) 丁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2929,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2928",
        "source" : "318",
        "target" : "269",
        "shared_name" : "永 (interacts with) 榮",
        "shared_interaction" : "interacts with",
        "name" : "永 (interacts with) 榮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2927",
        "source" : "321",
        "target" : "2410",
        "shared_name" : "色 (interacts with) 數2",
        "shared_interaction" : "interacts with",
        "name" : "色 (interacts with) 數2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2926",
        "source" : "325",
        "target" : "429",
        "shared_name" : "初 (interacts with) 測",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 測",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2925",
        "source" : "325",
        "target" : "146",
        "shared_name" : "初 (interacts with) 瘡",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 瘡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2924",
        "source" : "325",
        "target" : "256",
        "shared_name" : "初 (interacts with) 創",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 創",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2923",
        "source" : "325",
        "target" : "2365",
        "shared_name" : "初 (interacts with) 叉2",
        "shared_interaction" : "interacts with",
        "name" : "初 (interacts with) 叉2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2922",
        "source" : "326",
        "target" : "287",
        "shared_name" : "伯 (interacts with) 巴",
        "shared_interaction" : "interacts with",
        "name" : "伯 (interacts with) 巴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2921",
        "source" : "327",
        "target" : "2364",
        "shared_name" : "正 (interacts with) 諸2",
        "shared_interaction" : "interacts with",
        "name" : "正 (interacts with) 諸2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2920",
        "source" : "331",
        "target" : "2415",
        "shared_name" : "滂 (interacts with) 妃2",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 妃2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2920,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2919",
        "source" : "331",
        "target" : "411",
        "shared_name" : "滂 (interacts with) 普",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 普",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2918",
        "source" : "332",
        "target" : "73",
        "shared_name" : "虎 (interacts with) 呵",
        "shared_interaction" : "interacts with",
        "name" : "虎 (interacts with) 呵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2918,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2917",
        "source" : "333",
        "target" : "367",
        "shared_name" : "諾 (interacts with) 那",
        "shared_interaction" : "interacts with",
        "name" : "諾 (interacts with) 那",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2916",
        "source" : "334",
        "target" : "521",
        "shared_name" : "託 (interacts with) 他",
        "shared_interaction" : "interacts with",
        "name" : "託 (interacts with) 他",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2915",
        "source" : "335",
        "target" : "366",
        "shared_name" : "得 (interacts with) 多",
        "shared_interaction" : "interacts with",
        "name" : "得 (interacts with) 多",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2914",
        "source" : "336",
        "target" : "423",
        "shared_name" : "鉏 (interacts with) 仕",
        "shared_interaction" : "interacts with",
        "name" : "鉏 (interacts with) 仕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2914,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2913",
        "source" : "336",
        "target" : "484",
        "shared_name" : "鉏 (interacts with) 士",
        "shared_interaction" : "interacts with",
        "name" : "鉏 (interacts with) 士",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2912",
        "source" : "339",
        "target" : "202",
        "shared_name" : "于 (interacts with) 又",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 又",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2912,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2911",
        "source" : "339",
        "target" : "2425",
        "shared_name" : "于 (interacts with) 王2",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 王2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2910",
        "source" : "339",
        "target" : "2398",
        "shared_name" : "于 (interacts with) 爲2",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 爲2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2909",
        "source" : "339",
        "target" : "318",
        "shared_name" : "于 (interacts with) 永",
        "shared_interaction" : "interacts with",
        "name" : "于 (interacts with) 永",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2908",
        "source" : "342",
        "target" : "385",
        "shared_name" : "卑 (interacts with) 必",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 必",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2907",
        "source" : "342",
        "target" : "2381",
        "shared_name" : "卑 (interacts with) 比2",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 比2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2906",
        "source" : "344",
        "target" : "466",
        "shared_name" : "張 (interacts with) 竹",
        "shared_interaction" : "interacts with",
        "name" : "張 (interacts with) 竹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2905",
        "source" : "345",
        "target" : "449",
        "shared_name" : "諸 (interacts with) 止",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 止",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2904",
        "source" : "345",
        "target" : "327",
        "shared_name" : "諸 (interacts with) 正",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 正",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2903",
        "source" : "345",
        "target" : "141",
        "shared_name" : "諸 (interacts with) 征",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 征",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2902",
        "source" : "345",
        "target" : "483",
        "shared_name" : "諸 (interacts with) 章",
        "shared_interaction" : "interacts with",
        "name" : "諸 (interacts with) 章",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2901",
        "source" : "347",
        "target" : "303",
        "shared_name" : "蒼 (interacts with) 千",
        "shared_interaction" : "interacts with",
        "name" : "蒼 (interacts with) 千",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2900",
        "source" : "350",
        "target" : "2360",
        "shared_name" : "目 (interacts with) 眉2",
        "shared_interaction" : "interacts with",
        "name" : "目 (interacts with) 眉2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2899",
        "source" : "357",
        "target" : "464",
        "shared_name" : "阻 (interacts with) 側",
        "shared_interaction" : "interacts with",
        "name" : "阻 (interacts with) 側",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2899,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2898",
        "source" : "363",
        "target" : "414",
        "shared_name" : "在 (interacts with) 昨",
        "shared_interaction" : "interacts with",
        "name" : "在 (interacts with) 昨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2897",
        "source" : "366",
        "target" : "335",
        "shared_name" : "多 (interacts with) 得",
        "shared_interaction" : "interacts with",
        "name" : "多 (interacts with) 得",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2896",
        "source" : "366",
        "target" : "548",
        "shared_name" : "多 (interacts with) 德",
        "shared_interaction" : "interacts with",
        "name" : "多 (interacts with) 德",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2895",
        "source" : "369",
        "target" : "2369",
        "shared_name" : "吐 (interacts with) 湯2",
        "shared_interaction" : "interacts with",
        "name" : "吐 (interacts with) 湯2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2894",
        "source" : "370",
        "target" : "292",
        "shared_name" : "蒲 (interacts with) 僕",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 僕",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2893",
        "source" : "370",
        "target" : "2427",
        "shared_name" : "蒲 (interacts with) 傍2",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 傍2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2893,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2892",
        "source" : "370",
        "target" : "2393",
        "shared_name" : "蒲 (interacts with) 部2",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 部2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2891",
        "source" : "370",
        "target" : "351",
        "shared_name" : "蒲 (interacts with) 並",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 並",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2891,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2890",
        "source" : "374",
        "target" : "226",
        "shared_name" : "孚 (interacts with) 反",
        "shared_interaction" : "interacts with",
        "name" : "孚 (interacts with) 反",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2889",
        "source" : "377",
        "target" : "440",
        "shared_name" : "王 (interacts with) 雨",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 雨",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2888",
        "source" : "377",
        "target" : "537",
        "shared_name" : "王 (interacts with) 羽",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 羽",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2887",
        "source" : "377",
        "target" : "227",
        "shared_name" : "王 (interacts with) 云",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 云",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2887,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2886",
        "source" : "377",
        "target" : "224",
        "shared_name" : "王 (interacts with) 雲",
        "shared_interaction" : "interacts with",
        "name" : "王 (interacts with) 雲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2885",
        "source" : "378",
        "target" : "445",
        "shared_name" : "詳 (interacts with) 似",
        "shared_interaction" : "interacts with",
        "name" : "詳 (interacts with) 似",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2884",
        "source" : "378",
        "target" : "477",
        "shared_name" : "詳 (interacts with) 旬",
        "shared_interaction" : "interacts with",
        "name" : "詳 (interacts with) 旬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2883",
        "source" : "379",
        "target" : "2440",
        "shared_name" : "常 (interacts with) 植2",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 植2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2882",
        "source" : "379",
        "target" : "191",
        "shared_name" : "常 (interacts with) 殖",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 殖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2881",
        "source" : "379",
        "target" : "124",
        "shared_name" : "常 (interacts with) 寔",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 寔",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2880",
        "source" : "379",
        "target" : "431",
        "shared_name" : "常 (interacts with) 署",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 署",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2879",
        "source" : "379",
        "target" : "2400",
        "shared_name" : "常 (interacts with) 視2",
        "shared_interaction" : "interacts with",
        "name" : "常 (interacts with) 視2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2878",
        "source" : "381",
        "target" : "62",
        "shared_name" : "爲 (interacts with) 筠",
        "shared_interaction" : "interacts with",
        "name" : "爲 (interacts with) 筠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2877",
        "source" : "383",
        "target" : "155",
        "shared_name" : "匠 (interacts with) 秦",
        "shared_interaction" : "interacts with",
        "name" : "匠 (interacts with) 秦",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2876",
        "source" : "384",
        "target" : "453",
        "shared_name" : "將 (interacts with) 醉",
        "shared_interaction" : "interacts with",
        "name" : "將 (interacts with) 醉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2875",
        "source" : "384",
        "target" : "467",
        "shared_name" : "將 (interacts with) 遵",
        "shared_interaction" : "interacts with",
        "name" : "將 (interacts with) 遵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2874",
        "source" : "385",
        "target" : "2402",
        "shared_name" : "必 (interacts with) 比4",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 比4",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2873",
        "source" : "385",
        "target" : "114",
        "shared_name" : "必 (interacts with) 𢌿",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 𢌿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2873,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2872",
        "source" : "385",
        "target" : "342",
        "shared_name" : "必 (interacts with) 卑",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 卑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2872,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2871",
        "source" : "385",
        "target" : "102",
        "shared_name" : "必 (interacts with) 賔",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 賔",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2870",
        "source" : "387",
        "target" : "64",
        "shared_name" : "食 (interacts with) 乗",
        "shared_interaction" : "interacts with",
        "name" : "食 (interacts with) 乗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2869",
        "source" : "387",
        "target" : "271",
        "shared_name" : "食 (interacts with) 神",
        "shared_interaction" : "interacts with",
        "name" : "食 (interacts with) 神",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2868",
        "source" : "388",
        "target" : "252",
        "shared_name" : "植 (interacts with) 臣",
        "shared_interaction" : "interacts with",
        "name" : "植 (interacts with) 臣",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2867",
        "source" : "389",
        "target" : "2416",
        "shared_name" : "扶 (interacts with) 分2",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 分2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2867,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2866",
        "source" : "389",
        "target" : "2386",
        "shared_name" : "扶 (interacts with) 父2",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 父2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2866,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2865",
        "source" : "389",
        "target" : "2374",
        "shared_name" : "扶 (interacts with) 馮2",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 馮2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2865,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2864",
        "source" : "391",
        "target" : "512",
        "shared_name" : "臧 (interacts with) 作",
        "shared_interaction" : "interacts with",
        "name" : "臧 (interacts with) 作",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2863",
        "source" : "392",
        "target" : "408",
        "shared_name" : "布 (interacts with) 邊",
        "shared_interaction" : "interacts with",
        "name" : "布 (interacts with) 邊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2862",
        "source" : "392",
        "target" : "101",
        "shared_name" : "布 (interacts with) 班",
        "shared_interaction" : "interacts with",
        "name" : "布 (interacts with) 班",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2861",
        "source" : "393",
        "target" : "410",
        "shared_name" : "魯 (interacts with) 郎",
        "shared_interaction" : "interacts with",
        "name" : "魯 (interacts with) 郎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2861,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2860",
        "source" : "394",
        "target" : "527",
        "shared_name" : "公 (interacts with) 古",
        "shared_interaction" : "interacts with",
        "name" : "公 (interacts with) 古",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2859",
        "source" : "399",
        "target" : "2370",
        "shared_name" : "步 (interacts with) 房2",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 房2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2858",
        "source" : "399",
        "target" : "243",
        "shared_name" : "步 (interacts with) 傍",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 傍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2857",
        "source" : "399",
        "target" : "2361",
        "shared_name" : "步 (interacts with) 頻2",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 頻2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2856",
        "source" : "405",
        "target" : "2359",
        "shared_name" : "土 (interacts with) 台2",
        "shared_interaction" : "interacts with",
        "name" : "土 (interacts with) 台2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2855",
        "source" : "407",
        "target" : "352",
        "shared_name" : "胡 (interacts with) 獲",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 獲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2854",
        "source" : "407",
        "target" : "490",
        "shared_name" : "胡 (interacts with) 下",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 下",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2853",
        "source" : "407",
        "target" : "139",
        "shared_name" : "胡 (interacts with) 黃",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 黃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2852",
        "source" : "407",
        "target" : "194",
        "shared_name" : "胡 (interacts with) 何",
        "shared_interaction" : "interacts with",
        "name" : "胡 (interacts with) 何",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2851",
        "source" : "410",
        "target" : "82",
        "shared_name" : "郎 (interacts with) 練",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 練",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2850",
        "source" : "410",
        "target" : "2414",
        "shared_name" : "郎 (interacts with) 離3",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 離3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2850,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2849",
        "source" : "410",
        "target" : "393",
        "shared_name" : "郎 (interacts with) 魯",
        "shared_interaction" : "interacts with",
        "name" : "郎 (interacts with) 魯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2848",
        "source" : "411",
        "target" : "331",
        "shared_name" : "普 (interacts with) 滂",
        "shared_interaction" : "interacts with",
        "name" : "普 (interacts with) 滂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2847",
        "source" : "412",
        "target" : "2389",
        "shared_name" : "當 (interacts with) 楮2",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 楮2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2846",
        "source" : "412",
        "target" : "2373",
        "shared_name" : "當 (interacts with) 丁2",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 丁2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2845",
        "source" : "412",
        "target" : "515",
        "shared_name" : "當 (interacts with) 都",
        "shared_interaction" : "interacts with",
        "name" : "當 (interacts with) 都",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2844",
        "source" : "413",
        "target" : "2356",
        "shared_name" : "哀 (interacts with) 於2",
        "shared_interaction" : "interacts with",
        "name" : "哀 (interacts with) 於2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2844,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2843",
        "source" : "413",
        "target" : "523",
        "shared_name" : "哀 (interacts with) 烏",
        "shared_interaction" : "interacts with",
        "name" : "哀 (interacts with) 烏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2843,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2842",
        "source" : "414",
        "target" : "363",
        "shared_name" : "昨 (interacts with) 在",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 在",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2841",
        "source" : "414",
        "target" : "514",
        "shared_name" : "昨 (interacts with) 藏",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 藏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2840",
        "source" : "414",
        "target" : "67",
        "shared_name" : "昨 (interacts with) 前",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 前",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2839",
        "source" : "414",
        "target" : "324",
        "shared_name" : "昨 (interacts with) 才",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 才",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2838",
        "source" : "414",
        "target" : "524",
        "shared_name" : "昨 (interacts with) 徂",
        "shared_interaction" : "interacts with",
        "name" : "昨 (interacts with) 徂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2838,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2837",
        "source" : "415",
        "target" : "516",
        "shared_name" : "素 (interacts with) 蘇",
        "shared_interaction" : "interacts with",
        "name" : "素 (interacts with) 蘇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2837,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2836",
        "source" : "416",
        "target" : "397",
        "shared_name" : "落 (interacts with) 賴",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 賴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2835",
        "source" : "416",
        "target" : "234",
        "shared_name" : "落 (interacts with) 來",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 來",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2834",
        "source" : "416",
        "target" : "526",
        "shared_name" : "落 (interacts with) 盧",
        "shared_interaction" : "interacts with",
        "name" : "落 (interacts with) 盧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2833",
        "source" : "417",
        "target" : "2437",
        "shared_name" : "則 (interacts with) 作3",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 作3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2832",
        "source" : "417",
        "target" : "2420",
        "shared_name" : "則 (interacts with) 作2",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 作2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2831",
        "source" : "417",
        "target" : "390",
        "shared_name" : "則 (interacts with) 祖",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 祖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2830",
        "source" : "417",
        "target" : "391",
        "shared_name" : "則 (interacts with) 臧",
        "shared_interaction" : "interacts with",
        "name" : "則 (interacts with) 臧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2829",
        "source" : "418",
        "target" : "518",
        "shared_name" : "荒 (interacts with) 呼",
        "shared_interaction" : "interacts with",
        "name" : "荒 (interacts with) 呼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2828",
        "source" : "419",
        "target" : "513",
        "shared_name" : "乃 (interacts with) 奴",
        "shared_interaction" : "interacts with",
        "name" : "乃 (interacts with) 奴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2828,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2827",
        "source" : "420",
        "target" : "547",
        "shared_name" : "同 (interacts with) 徒",
        "shared_interaction" : "interacts with",
        "name" : "同 (interacts with) 徒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2826",
        "source" : "421",
        "target" : "198",
        "shared_name" : "憶 (interacts with) 紆",
        "shared_interaction" : "interacts with",
        "name" : "憶 (interacts with) 紆",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2825",
        "source" : "422",
        "target" : "2407",
        "shared_name" : "莊 (interacts with) 阻2",
        "shared_interaction" : "interacts with",
        "name" : "莊 (interacts with) 阻2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2824",
        "source" : "423",
        "target" : "249",
        "shared_name" : "仕 (interacts with) 鶵",
        "shared_interaction" : "interacts with",
        "name" : "仕 (interacts with) 鶵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2823",
        "source" : "423",
        "target" : "219",
        "shared_name" : "仕 (interacts with) 雛",
        "shared_interaction" : "interacts with",
        "name" : "仕 (interacts with) 雛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2823,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2822",
        "source" : "424",
        "target" : "211",
        "shared_name" : "防 (interacts with) 苻",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 苻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2821",
        "source" : "424",
        "target" : "499",
        "shared_name" : "防 (interacts with) 符",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 符",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2820",
        "source" : "424",
        "target" : "389",
        "shared_name" : "防 (interacts with) 扶",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 扶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2819",
        "source" : "425",
        "target" : "251",
        "shared_name" : "豈 (interacts with) 驅",
        "shared_interaction" : "interacts with",
        "name" : "豈 (interacts with) 驅",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2819,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2818",
        "source" : "425",
        "target" : "172",
        "shared_name" : "豈 (interacts with) 區",
        "shared_interaction" : "interacts with",
        "name" : "豈 (interacts with) 區",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2817",
        "source" : "426",
        "target" : "2408",
        "shared_name" : "羊 (interacts with) 與3",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 與3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2816",
        "source" : "426",
        "target" : "387",
        "shared_name" : "羊 (interacts with) 食",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 食",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2816,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2815",
        "source" : "426",
        "target" : "538",
        "shared_name" : "羊 (interacts with) 以",
        "shared_interaction" : "interacts with",
        "name" : "羊 (interacts with) 以",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2814",
        "source" : "427",
        "target" : "75",
        "shared_name" : "其 (interacts with) 具",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 具",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2813",
        "source" : "427",
        "target" : "132",
        "shared_name" : "其 (interacts with) 臼",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 臼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2813,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2812",
        "source" : "427",
        "target" : "150",
        "shared_name" : "其 (interacts with) 近",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 近",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2811",
        "source" : "427",
        "target" : "476",
        "shared_name" : "其 (interacts with) 巨",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 巨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2810",
        "source" : "427",
        "target" : "89",
        "shared_name" : "其 (interacts with) 衢",
        "shared_interaction" : "interacts with",
        "name" : "其 (interacts with) 衢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2810,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2809",
        "source" : "429",
        "target" : "144",
        "shared_name" : "測 (interacts with) 芻",
        "shared_interaction" : "interacts with",
        "name" : "測 (interacts with) 芻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2808",
        "source" : "430",
        "target" : "376",
        "shared_name" : "遇 (interacts with) 愚",
        "shared_interaction" : "interacts with",
        "name" : "遇 (interacts with) 愚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2807",
        "source" : "430",
        "target" : "253",
        "shared_name" : "遇 (interacts with) 虞",
        "shared_interaction" : "interacts with",
        "name" : "遇 (interacts with) 虞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2807,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2806",
        "source" : "431",
        "target" : "286",
        "shared_name" : "署 (interacts with) 承",
        "shared_interaction" : "interacts with",
        "name" : "署 (interacts with) 承",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2805",
        "source" : "432",
        "target" : "503",
        "shared_name" : "央 (interacts with) 於",
        "shared_interaction" : "interacts with",
        "name" : "央 (interacts with) 於",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2805,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2804",
        "source" : "433",
        "target" : "310",
        "shared_name" : "朽 (interacts with) 虛",
        "shared_interaction" : "interacts with",
        "name" : "朽 (interacts with) 虛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2804,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2803",
        "source" : "434",
        "target" : "541",
        "shared_name" : "相 (interacts with) 息",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 息",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2802",
        "source" : "434",
        "target" : "2403",
        "shared_name" : "相 (interacts with) 思2",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 思2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2801",
        "source" : "434",
        "target" : "343",
        "shared_name" : "相 (interacts with) 須",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 須",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2801,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2800",
        "source" : "434",
        "target" : "263",
        "shared_name" : "相 (interacts with) 胥",
        "shared_interaction" : "interacts with",
        "name" : "相 (interacts with) 胥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2800,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2799",
        "source" : "435",
        "target" : "534",
        "shared_name" : "強 (interacts with) 渠",
        "shared_interaction" : "interacts with",
        "name" : "強 (interacts with) 渠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2798",
        "source" : "436",
        "target" : "258",
        "shared_name" : "傷 (interacts with) 舒",
        "shared_interaction" : "interacts with",
        "name" : "傷 (interacts with) 舒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2798,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2797",
        "source" : "436",
        "target" : "510",
        "shared_name" : "傷 (interacts with) 書",
        "shared_interaction" : "interacts with",
        "name" : "傷 (interacts with) 書",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2796",
        "source" : "437",
        "target" : "495",
        "shared_name" : "舉 (interacts with) 九",
        "shared_interaction" : "interacts with",
        "name" : "舉 (interacts with) 九",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2795",
        "source" : "437",
        "target" : "250",
        "shared_name" : "舉 (interacts with) 俱",
        "shared_interaction" : "interacts with",
        "name" : "舉 (interacts with) 俱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2795,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2794",
        "source" : "438",
        "target" : "478",
        "shared_name" : "甫 (interacts with) 彼",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 彼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2793",
        "source" : "438",
        "target" : "195",
        "shared_name" : "甫 (interacts with) 兵",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 兵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2792",
        "source" : "438",
        "target" : "2355",
        "shared_name" : "甫 (interacts with) 扶2",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 扶2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2792,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2791",
        "source" : "439",
        "target" : "338",
        "shared_name" : "芳 (interacts with) 撫",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 撫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2791,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2790",
        "source" : "439",
        "target" : "348",
        "shared_name" : "芳 (interacts with) 偏",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 偏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2789",
        "source" : "439",
        "target" : "374",
        "shared_name" : "芳 (interacts with) 孚",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 孚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2788",
        "source" : "439",
        "target" : "531",
        "shared_name" : "芳 (interacts with) 敷",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 敷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2787",
        "source" : "439",
        "target" : "200",
        "shared_name" : "芳 (interacts with) 妃",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 妃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2787,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2786",
        "source" : "440",
        "target" : "377",
        "shared_name" : "雨 (interacts with) 王",
        "shared_interaction" : "interacts with",
        "name" : "雨 (interacts with) 王",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2786,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2785",
        "source" : "440",
        "target" : "282",
        "shared_name" : "雨 (interacts with) 韋",
        "shared_interaction" : "interacts with",
        "name" : "雨 (interacts with) 韋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2784",
        "source" : "441",
        "target" : "95",
        "shared_name" : "無 (interacts with) 美",
        "shared_interaction" : "interacts with",
        "name" : "無 (interacts with) 美",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2783",
        "source" : "441",
        "target" : "285",
        "shared_name" : "無 (interacts with) 文",
        "shared_interaction" : "interacts with",
        "name" : "無 (interacts with) 文",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2782",
        "source" : "445",
        "target" : "509",
        "shared_name" : "似 (interacts with) 祥",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 祥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2781",
        "source" : "445",
        "target" : "2367",
        "shared_name" : "似 (interacts with) 詳2",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 詳2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2780",
        "source" : "445",
        "target" : "300",
        "shared_name" : "似 (interacts with) 徐",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 徐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2780,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2779",
        "source" : "445",
        "target" : "220",
        "shared_name" : "似 (interacts with) 辝",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 辝",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2778",
        "source" : "445",
        "target" : "134",
        "shared_name" : "似 (interacts with) 辭",
        "shared_interaction" : "interacts with",
        "name" : "似 (interacts with) 辭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2777",
        "source" : "446",
        "target" : "451",
        "shared_name" : "語 (interacts with) 牛",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 牛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2776",
        "source" : "446",
        "target" : "504",
        "shared_name" : "語 (interacts with) 魚",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 魚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2776,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2775",
        "source" : "446",
        "target" : "247",
        "shared_name" : "語 (interacts with) 疑",
        "shared_interaction" : "interacts with",
        "name" : "語 (interacts with) 疑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2774",
        "source" : "447",
        "target" : "496",
        "shared_name" : "市 (interacts with) 蜀",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 蜀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2773",
        "source" : "447",
        "target" : "140",
        "shared_name" : "市 (interacts with) 嘗",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 嘗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2772",
        "source" : "447",
        "target" : "379",
        "shared_name" : "市 (interacts with) 常",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 常",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2771",
        "source" : "447",
        "target" : "100",
        "shared_name" : "市 (interacts with) 殊",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 殊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2770",
        "source" : "447",
        "target" : "289",
        "shared_name" : "市 (interacts with) 時",
        "shared_interaction" : "interacts with",
        "name" : "市 (interacts with) 時",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2770,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2769",
        "source" : "448",
        "target" : "382",
        "shared_name" : "與 (interacts with) 翼",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 翼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2768",
        "source" : "448",
        "target" : "482",
        "shared_name" : "與 (interacts with) 弋",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 弋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2767",
        "source" : "448",
        "target" : "378",
        "shared_name" : "與 (interacts with) 詳",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 詳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2766",
        "source" : "448",
        "target" : "426",
        "shared_name" : "與 (interacts with) 羊",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 羊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2765",
        "source" : "448",
        "target" : "111",
        "shared_name" : "與 (interacts with) 台",
        "shared_interaction" : "interacts with",
        "name" : "與 (interacts with) 台",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2764",
        "source" : "449",
        "target" : "290",
        "shared_name" : "止 (interacts with) 之",
        "shared_interaction" : "interacts with",
        "name" : "止 (interacts with) 之",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2763",
        "source" : "451",
        "target" : "430",
        "shared_name" : "牛 (interacts with) 遇",
        "shared_interaction" : "interacts with",
        "name" : "牛 (interacts with) 遇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2762",
        "source" : "451",
        "target" : "2404",
        "shared_name" : "牛 (interacts with) 語2",
        "shared_interaction" : "interacts with",
        "name" : "牛 (interacts with) 語2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2761",
        "source" : "452",
        "target" : "493",
        "shared_name" : "丘 (interacts with) 曲",
        "shared_interaction" : "interacts with",
        "name" : "丘 (interacts with) 曲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2760",
        "source" : "454",
        "target" : "2429",
        "shared_name" : "丁 (interacts with) 當2",
        "shared_interaction" : "interacts with",
        "name" : "丁 (interacts with) 當2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2759",
        "source" : "457",
        "target" : "2366",
        "shared_name" : "視 (interacts with) 余2",
        "shared_interaction" : "interacts with",
        "name" : "視 (interacts with) 余2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2758",
        "source" : "462",
        "target" : "160",
        "shared_name" : "旨 (interacts with) 脂",
        "shared_interaction" : "interacts with",
        "name" : "旨 (interacts with) 脂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2757",
        "source" : "464",
        "target" : "357",
        "shared_name" : "側 (interacts with) 阻",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 阻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2756",
        "source" : "464",
        "target" : "69",
        "shared_name" : "側 (interacts with) 簪",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 簪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2756,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2755",
        "source" : "464",
        "target" : "85",
        "shared_name" : "側 (interacts with) 鄒",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 鄒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2754",
        "source" : "464",
        "target" : "162",
        "shared_name" : "側 (interacts with) 爭",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 爭",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2753",
        "source" : "464",
        "target" : "422",
        "shared_name" : "側 (interacts with) 莊",
        "shared_interaction" : "interacts with",
        "name" : "側 (interacts with) 莊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2752",
        "source" : "466",
        "target" : "546",
        "shared_name" : "竹 (interacts with) 陟",
        "shared_interaction" : "interacts with",
        "name" : "竹 (interacts with) 陟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2751",
        "source" : "466",
        "target" : "398",
        "shared_name" : "竹 (interacts with) 卓",
        "shared_interaction" : "interacts with",
        "name" : "竹 (interacts with) 卓",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2750",
        "source" : "469",
        "target" : "475",
        "shared_name" : "人 (interacts with) 汝",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 汝",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2749",
        "source" : "469",
        "target" : "458",
        "shared_name" : "人 (interacts with) 儒",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 儒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2748",
        "source" : "469",
        "target" : "540",
        "shared_name" : "人 (interacts with) 如",
        "shared_interaction" : "interacts with",
        "name" : "人 (interacts with) 如",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2747",
        "source" : "472",
        "target" : "281",
        "shared_name" : "此 (interacts with) 雌",
        "shared_interaction" : "interacts with",
        "name" : "此 (interacts with) 雌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2746",
        "source" : "473",
        "target" : "293",
        "shared_name" : "武 (interacts with) 名",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 名",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2745",
        "source" : "473",
        "target" : "180",
        "shared_name" : "武 (interacts with) 明",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 明",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2744",
        "source" : "473",
        "target" : "88",
        "shared_name" : "武 (interacts with) 望",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 望",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2743",
        "source" : "473",
        "target" : "302",
        "shared_name" : "武 (interacts with) 亡",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 亡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2742",
        "source" : "473",
        "target" : "275",
        "shared_name" : "武 (interacts with) 綿",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 綿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2741",
        "source" : "473",
        "target" : "118",
        "shared_name" : "武 (interacts with) 巫",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 巫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2741,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2740",
        "source" : "473",
        "target" : "441",
        "shared_name" : "武 (interacts with) 無",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 無",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2739",
        "source" : "473",
        "target" : "231",
        "shared_name" : "武 (interacts with) 眉",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 眉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2739,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2738",
        "source" : "473",
        "target" : "380",
        "shared_name" : "武 (interacts with) 彌",
        "shared_interaction" : "interacts with",
        "name" : "武 (interacts with) 彌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2737",
        "source" : "474",
        "target" : "386",
        "shared_name" : "式 (interacts with) 失",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 失",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2736",
        "source" : "474",
        "target" : "135",
        "shared_name" : "式 (interacts with) 試",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 試",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2735",
        "source" : "474",
        "target" : "153",
        "shared_name" : "式 (interacts with) 矢",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 矢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2734",
        "source" : "474",
        "target" : "142",
        "shared_name" : "式 (interacts with) 湯",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 湯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2733",
        "source" : "474",
        "target" : "436",
        "shared_name" : "式 (interacts with) 傷",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 傷",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2732",
        "source" : "474",
        "target" : "149",
        "shared_name" : "式 (interacts with) 商",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 商",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2732,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2731",
        "source" : "474",
        "target" : "273",
        "shared_name" : "式 (interacts with) 施",
        "shared_interaction" : "interacts with",
        "name" : "式 (interacts with) 施",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2730",
        "source" : "475",
        "target" : "276",
        "shared_name" : "汝 (interacts with) 兒",
        "shared_interaction" : "interacts with",
        "name" : "汝 (interacts with) 兒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2729",
        "source" : "476",
        "target" : "2417",
        "shared_name" : "巨 (interacts with) 近2",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 近2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2728",
        "source" : "476",
        "target" : "330",
        "shared_name" : "巨 (interacts with) 求",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 求",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2728,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2727",
        "source" : "476",
        "target" : "215",
        "shared_name" : "巨 (interacts with) 狂",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 狂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2726",
        "source" : "476",
        "target" : "435",
        "shared_name" : "巨 (interacts with) 強",
        "shared_interaction" : "interacts with",
        "name" : "巨 (interacts with) 強",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2726,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2725",
        "source" : "477",
        "target" : "272",
        "shared_name" : "旬 (interacts with) 隨",
        "shared_interaction" : "interacts with",
        "name" : "旬 (interacts with) 隨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2724",
        "source" : "478",
        "target" : "210",
        "shared_name" : "彼 (interacts with) 陂",
        "shared_interaction" : "interacts with",
        "name" : "彼 (interacts with) 陂",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2723",
        "source" : "479",
        "target" : "403",
        "shared_name" : "是 (interacts with) 成",
        "shared_interaction" : "interacts with",
        "name" : "是 (interacts with) 成",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2722",
        "source" : "481",
        "target" : "381",
        "shared_name" : "薳 (interacts with) 爲",
        "shared_interaction" : "interacts with",
        "name" : "薳 (interacts with) 爲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2722,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2721",
        "source" : "482",
        "target" : "463",
        "shared_name" : "弋 (interacts with) 恱",
        "shared_interaction" : "interacts with",
        "name" : "弋 (interacts with) 恱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2720",
        "source" : "482",
        "target" : "278",
        "shared_name" : "弋 (interacts with) 移",
        "shared_interaction" : "interacts with",
        "name" : "弋 (interacts with) 移",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2719",
        "source" : "483",
        "target" : "2434",
        "shared_name" : "章 (interacts with) 占2",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 占2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2718",
        "source" : "483",
        "target" : "313",
        "shared_name" : "章 (interacts with) 煑",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 煑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2717",
        "source" : "483",
        "target" : "345",
        "shared_name" : "章 (interacts with) 諸",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 諸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2716",
        "source" : "483",
        "target" : "298",
        "shared_name" : "章 (interacts with) 氏",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 氏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2716,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2715",
        "source" : "483",
        "target" : "170",
        "shared_name" : "章 (interacts with) 支",
        "shared_interaction" : "interacts with",
        "name" : "章 (interacts with) 支",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2715,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2714",
        "source" : "484",
        "target" : "90",
        "shared_name" : "士 (interacts with) 崱",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 崱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2714,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2713",
        "source" : "484",
        "target" : "261",
        "shared_name" : "士 (interacts with) 牀",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 牀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2712",
        "source" : "484",
        "target" : "542",
        "shared_name" : "士 (interacts with) 鋤",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 鋤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2711",
        "source" : "484",
        "target" : "336",
        "shared_name" : "士 (interacts with) 鉏",
        "shared_interaction" : "interacts with",
        "name" : "士 (interacts with) 鉏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2710",
        "source" : "487",
        "target" : "321",
        "shared_name" : "所 (interacts with) 色",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 色",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2710,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2709",
        "source" : "487",
        "target" : "359",
        "shared_name" : "所 (interacts with) 數",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 數",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2708",
        "source" : "487",
        "target" : "130",
        "shared_name" : "所 (interacts with) 生",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 生",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2707",
        "source" : "487",
        "target" : "205",
        "shared_name" : "所 (interacts with) 砂",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 砂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2706",
        "source" : "487",
        "target" : "201",
        "shared_name" : "所 (interacts with) 沙",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 沙",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2705",
        "source" : "487",
        "target" : "470",
        "shared_name" : "所 (interacts with) 山",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 山",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2704",
        "source" : "487",
        "target" : "265",
        "shared_name" : "所 (interacts with) 踈",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 踈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2704,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2703",
        "source" : "487",
        "target" : "461",
        "shared_name" : "所 (interacts with) 䟽",
        "shared_interaction" : "interacts with",
        "name" : "所 (interacts with) 䟽",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2703,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2702",
        "source" : "488",
        "target" : "264",
        "shared_name" : "吕 (interacts with) 良",
        "shared_interaction" : "interacts with",
        "name" : "吕 (interacts with) 良",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2702,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2701",
        "source" : "488",
        "target" : "77",
        "shared_name" : "吕 (interacts with) 離",
        "shared_interaction" : "interacts with",
        "name" : "吕 (interacts with) 離",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2700",
        "source" : "489",
        "target" : "2418",
        "shared_name" : "匹 (interacts with) 偏2",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 偏2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2699",
        "source" : "489",
        "target" : "96",
        "shared_name" : "匹 (interacts with) 譬",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 譬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2698",
        "source" : "489",
        "target" : "2379",
        "shared_name" : "匹 (interacts with) 披2",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 披2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2697",
        "source" : "491",
        "target" : "360",
        "shared_name" : "博 (interacts with) 北",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 北",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2696",
        "source" : "491",
        "target" : "84",
        "shared_name" : "博 (interacts with) 百",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 百",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2695",
        "source" : "491",
        "target" : "326",
        "shared_name" : "博 (interacts with) 伯",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 伯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2694",
        "source" : "491",
        "target" : "349",
        "shared_name" : "博 (interacts with) 卜",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 卜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2694,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2693",
        "source" : "491",
        "target" : "392",
        "shared_name" : "博 (interacts with) 布",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 布",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2692",
        "source" : "491",
        "target" : "241",
        "shared_name" : "博 (interacts with) 補",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 補",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2692,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2691",
        "source" : "491",
        "target" : "129",
        "shared_name" : "博 (interacts with) 晡",
        "shared_interaction" : "interacts with",
        "name" : "博 (interacts with) 晡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2690",
        "source" : "492",
        "target" : "455",
        "shared_name" : "楚 (interacts with) 叉",
        "shared_interaction" : "interacts with",
        "name" : "楚 (interacts with) 叉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2689",
        "source" : "492",
        "target" : "325",
        "shared_name" : "楚 (interacts with) 初",
        "shared_interaction" : "interacts with",
        "name" : "楚 (interacts with) 初",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2688",
        "source" : "494",
        "target" : "459",
        "shared_name" : "七 (interacts with) 取",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 取",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2687",
        "source" : "494",
        "target" : "347",
        "shared_name" : "七 (interacts with) 蒼",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 蒼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2686",
        "source" : "494",
        "target" : "522",
        "shared_name" : "七 (interacts with) 倉",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 倉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2685",
        "source" : "494",
        "target" : "119",
        "shared_name" : "七 (interacts with) 遷",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 遷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2684",
        "source" : "494",
        "target" : "208",
        "shared_name" : "七 (interacts with) 親",
        "shared_interaction" : "interacts with",
        "name" : "七 (interacts with) 親",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2683",
        "source" : "495",
        "target" : "539",
        "shared_name" : "九 (interacts with) 居",
        "shared_interaction" : "interacts with",
        "name" : "九 (interacts with) 居",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2682",
        "source" : "497",
        "target" : "307",
        "shared_name" : "而 (interacts with) 耳",
        "shared_interaction" : "interacts with",
        "name" : "而 (interacts with) 耳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2681",
        "source" : "497",
        "target" : "2352",
        "shared_name" : "而 (interacts with) 穠2",
        "shared_interaction" : "interacts with",
        "name" : "而 (interacts with) 穠2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2680",
        "source" : "498",
        "target" : "520",
        "shared_name" : "即 (interacts with) 子",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 子",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2679",
        "source" : "498",
        "target" : "384",
        "shared_name" : "即 (interacts with) 將",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 將",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2678",
        "source" : "498",
        "target" : "156",
        "shared_name" : "即 (interacts with) 資",
        "shared_interaction" : "interacts with",
        "name" : "即 (interacts with) 資",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2677",
        "source" : "499",
        "target" : "306",
        "shared_name" : "符 (interacts with) 縛",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 縛",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2677,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2676",
        "source" : "499",
        "target" : "375",
        "shared_name" : "符 (interacts with) 附",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 附",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2675",
        "source" : "499",
        "target" : "2371",
        "shared_name" : "符 (interacts with) 平2",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 平2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2674",
        "source" : "499",
        "target" : "532",
        "shared_name" : "符 (interacts with) 方",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 方",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2673",
        "source" : "499",
        "target" : "424",
        "shared_name" : "符 (interacts with) 防",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 防",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2673,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2672",
        "source" : "499",
        "target" : "533",
        "shared_name" : "符 (interacts with) 房",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 房",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2672,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2671",
        "source" : "499",
        "target" : "177",
        "shared_name" : "符 (interacts with) 頻",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 頻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2671,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2670",
        "source" : "499",
        "target" : "246",
        "shared_name" : "符 (interacts with) 裴",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 裴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2669",
        "source" : "499",
        "target" : "301",
        "shared_name" : "符 (interacts with) 皮",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 皮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2668",
        "source" : "500",
        "target" : "267",
        "shared_name" : "丑 (interacts with) 楮",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 楮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2667",
        "source" : "500",
        "target" : "145",
        "shared_name" : "丑 (interacts with) 抽",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 抽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2666",
        "source" : "500",
        "target" : "230",
        "shared_name" : "丑 (interacts with) 癡",
        "shared_interaction" : "interacts with",
        "name" : "丑 (interacts with) 癡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2665",
        "source" : "501",
        "target" : "383",
        "shared_name" : "疾 (interacts with) 匠",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 匠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2664",
        "source" : "501",
        "target" : "308",
        "shared_name" : "疾 (interacts with) 自",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 自",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2663",
        "source" : "501",
        "target" : "81",
        "shared_name" : "疾 (interacts with) 情",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 情",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2662",
        "source" : "501",
        "target" : "223",
        "shared_name" : "疾 (interacts with) 兹",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 兹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2661",
        "source" : "501",
        "target" : "255",
        "shared_name" : "疾 (interacts with) 慈",
        "shared_interaction" : "interacts with",
        "name" : "疾 (interacts with) 慈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2660",
        "source" : "502",
        "target" : "193",
        "shared_name" : "女 (interacts with) 拏",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 拏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2659",
        "source" : "502",
        "target" : "257",
        "shared_name" : "女 (interacts with) 尼",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 尼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2659,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2658",
        "source" : "502",
        "target" : "171",
        "shared_name" : "女 (interacts with) 穠",
        "shared_interaction" : "interacts with",
        "name" : "女 (interacts with) 穠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2657",
        "source" : "503",
        "target" : "421",
        "shared_name" : "於 (interacts with) 憶",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 憶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2656",
        "source" : "503",
        "target" : "372",
        "shared_name" : "於 (interacts with) 謁",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 謁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2655",
        "source" : "503",
        "target" : "400",
        "shared_name" : "於 (interacts with) 乙",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 乙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2655,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2654",
        "source" : "503",
        "target" : "365",
        "shared_name" : "於 (interacts with) 一",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 一",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2653",
        "source" : "503",
        "target" : "486",
        "shared_name" : "於 (interacts with) 握",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 握",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2652",
        "source" : "503",
        "target" : "103",
        "shared_name" : "於 (interacts with) 音",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 音",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2651",
        "source" : "503",
        "target" : "76",
        "shared_name" : "於 (interacts with) 憂",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 憂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2650",
        "source" : "503",
        "target" : "432",
        "shared_name" : "於 (interacts with) 央",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 央",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2649",
        "source" : "503",
        "target" : "192",
        "shared_name" : "於 (interacts with) 烟",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 烟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2648",
        "source" : "503",
        "target" : "184",
        "shared_name" : "於 (interacts with) 衣",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 衣",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2647",
        "source" : "503",
        "target" : "148",
        "shared_name" : "於 (interacts with) 依",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 依",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2646",
        "source" : "503",
        "target" : "110",
        "shared_name" : "於 (interacts with) 伊",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 伊",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2645",
        "source" : "503",
        "target" : "355",
        "shared_name" : "於 (interacts with) 委",
        "shared_interaction" : "interacts with",
        "name" : "於 (interacts with) 委",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2644",
        "source" : "504",
        "target" : "105",
        "shared_name" : "魚 (interacts with) 玉",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 玉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2643",
        "source" : "504",
        "target" : "446",
        "shared_name" : "魚 (interacts with) 語",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 語",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2643,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2642",
        "source" : "504",
        "target" : "395",
        "shared_name" : "魚 (interacts with) 擬",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 擬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2642,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2641",
        "source" : "504",
        "target" : "164",
        "shared_name" : "魚 (interacts with) 危",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 危",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2641,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2640",
        "source" : "504",
        "target" : "232",
        "shared_name" : "魚 (interacts with) 宜",
        "shared_interaction" : "interacts with",
        "name" : "魚 (interacts with) 宜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2639",
        "source" : "505",
        "target" : "2433",
        "shared_name" : "許 (interacts with) 興2",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 興2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2638",
        "source" : "505",
        "target" : "428",
        "shared_name" : "許 (interacts with) 況",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 況",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2637",
        "source" : "505",
        "target" : "433",
        "shared_name" : "許 (interacts with) 朽",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 朽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2636",
        "source" : "505",
        "target" : "225",
        "shared_name" : "許 (interacts with) 休",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 休",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2635",
        "source" : "505",
        "target" : "471",
        "shared_name" : "許 (interacts with) 香",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 香",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2634",
        "source" : "505",
        "target" : "92",
        "shared_name" : "許 (interacts with) 羲",
        "shared_interaction" : "interacts with",
        "name" : "許 (interacts with) 羲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2634,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2633",
        "source" : "506",
        "target" : "2391",
        "shared_name" : "府 (interacts with) 反2",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 反2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2632",
        "source" : "506",
        "target" : "277",
        "shared_name" : "府 (interacts with) 并",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 并",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2631",
        "source" : "506",
        "target" : "2368",
        "shared_name" : "府 (interacts with) 方2",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 方2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2631,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2630",
        "source" : "506",
        "target" : "199",
        "shared_name" : "府 (interacts with) 分",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 分",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2629",
        "source" : "506",
        "target" : "97",
        "shared_name" : "府 (interacts with) 封",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 封",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2628",
        "source" : "508",
        "target" : "530",
        "shared_name" : "尺 (interacts with) 昌",
        "shared_interaction" : "interacts with",
        "name" : "尺 (interacts with) 昌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2628,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2627",
        "source" : "509",
        "target" : "341",
        "shared_name" : "祥 (interacts with) 夕",
        "shared_interaction" : "interacts with",
        "name" : "祥 (interacts with) 夕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2627,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2626",
        "source" : "509",
        "target" : "78",
        "shared_name" : "祥 (interacts with) 寺",
        "shared_interaction" : "interacts with",
        "name" : "祥 (interacts with) 寺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2625",
        "source" : "510",
        "target" : "187",
        "shared_name" : "書 (interacts with) 賞",
        "shared_interaction" : "interacts with",
        "name" : "書 (interacts with) 賞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2625,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2624",
        "source" : "510",
        "target" : "262",
        "shared_name" : "書 (interacts with) 詩",
        "shared_interaction" : "interacts with",
        "name" : "書 (interacts with) 詩",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2623",
        "source" : "511",
        "target" : "2384",
        "shared_name" : "私 (interacts with) 胥2",
        "shared_interaction" : "interacts with",
        "name" : "私 (interacts with) 胥2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2622",
        "source" : "512",
        "target" : "2376",
        "shared_name" : "作 (interacts with) 簪2",
        "shared_interaction" : "interacts with",
        "name" : "作 (interacts with) 簪2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2622,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2621",
        "source" : "513",
        "target" : "333",
        "shared_name" : "奴 (interacts with) 諾",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 諾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2620",
        "source" : "513",
        "target" : "2421",
        "shared_name" : "奴 (interacts with) 那2",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 那2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2619",
        "source" : "513",
        "target" : "419",
        "shared_name" : "奴 (interacts with) 乃",
        "shared_interaction" : "interacts with",
        "name" : "奴 (interacts with) 乃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2618",
        "source" : "515",
        "target" : "412",
        "shared_name" : "都 (interacts with) 當",
        "shared_interaction" : "interacts with",
        "name" : "都 (interacts with) 當",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2617",
        "source" : "515",
        "target" : "99",
        "shared_name" : "都 (interacts with) 冬",
        "shared_interaction" : "interacts with",
        "name" : "都 (interacts with) 冬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2616",
        "source" : "516",
        "target" : "406",
        "shared_name" : "蘇 (interacts with) 先",
        "shared_interaction" : "interacts with",
        "name" : "蘇 (interacts with) 先",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2615",
        "source" : "517",
        "target" : "368",
        "shared_name" : "五 (interacts with) 俄",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 俄",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2615,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2614",
        "source" : "517",
        "target" : "2357",
        "shared_name" : "五 (interacts with) 兒2",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 兒2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2613",
        "source" : "517",
        "target" : "133",
        "shared_name" : "五 (interacts with) 吾",
        "shared_interaction" : "interacts with",
        "name" : "五 (interacts with) 吾",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2613,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2612",
        "source" : "518",
        "target" : "2422",
        "shared_name" : "呼 (interacts with) 呵2",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 呵2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2611",
        "source" : "518",
        "target" : "402",
        "shared_name" : "呼 (interacts with) 火",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 火",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2610",
        "source" : "518",
        "target" : "136",
        "shared_name" : "呼 (interacts with) 海",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 海",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2610,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2609",
        "source" : "518",
        "target" : "332",
        "shared_name" : "呼 (interacts with) 虎",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 虎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2608",
        "source" : "518",
        "target" : "213",
        "shared_name" : "呼 (interacts with) 馨",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 馨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2607",
        "source" : "518",
        "target" : "418",
        "shared_name" : "呼 (interacts with) 荒",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 荒",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2607,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2606",
        "source" : "518",
        "target" : "236",
        "shared_name" : "呼 (interacts with) 花",
        "shared_interaction" : "interacts with",
        "name" : "呼 (interacts with) 花",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2605",
        "source" : "519",
        "target" : "399",
        "shared_name" : "薄 (interacts with) 步",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 步",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2604",
        "source" : "519",
        "target" : "206",
        "shared_name" : "薄 (interacts with) 捕",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 捕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2604,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2603",
        "source" : "519",
        "target" : "2358",
        "shared_name" : "薄 (interacts with) 裴2",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 裴2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2603,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2602",
        "source" : "519",
        "target" : "370",
        "shared_name" : "薄 (interacts with) 蒲",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 蒲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2601",
        "source" : "520",
        "target" : "417",
        "shared_name" : "子 (interacts with) 則",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 則",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2600",
        "source" : "520",
        "target" : "498",
        "shared_name" : "子 (interacts with) 即",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 即",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2599",
        "source" : "520",
        "target" : "362",
        "shared_name" : "子 (interacts with) 借",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 借",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2598",
        "source" : "520",
        "target" : "107",
        "shared_name" : "子 (interacts with) 漸",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 漸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2598,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2597",
        "source" : "520",
        "target" : "2372",
        "shared_name" : "子 (interacts with) 氏2",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 氏2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2596",
        "source" : "520",
        "target" : "203",
        "shared_name" : "子 (interacts with) 𩛠",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 𩛠",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2595",
        "source" : "520",
        "target" : "2354",
        "shared_name" : "子 (interacts with) 兹2",
        "shared_interaction" : "interacts with",
        "name" : "子 (interacts with) 兹2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2595,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2594",
        "source" : "521",
        "target" : "334",
        "shared_name" : "他 (interacts with) 託",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 託",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2593",
        "source" : "521",
        "target" : "2430",
        "shared_name" : "他 (interacts with) 湯3",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 湯3",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2592",
        "source" : "521",
        "target" : "369",
        "shared_name" : "他 (interacts with) 吐",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 吐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2592,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2591",
        "source" : "521",
        "target" : "405",
        "shared_name" : "他 (interacts with) 土",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 土",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2591,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2590",
        "source" : "521",
        "target" : "190",
        "shared_name" : "他 (interacts with) 天",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 天",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2589",
        "source" : "521",
        "target" : "131",
        "shared_name" : "他 (interacts with) 通",
        "shared_interaction" : "interacts with",
        "name" : "他 (interacts with) 通",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2589,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2588",
        "source" : "522",
        "target" : "329",
        "shared_name" : "倉 (interacts with) 醋",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 醋",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2587",
        "source" : "522",
        "target" : "2394",
        "shared_name" : "倉 (interacts with) 取2",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 取2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2586",
        "source" : "522",
        "target" : "248",
        "shared_name" : "倉 (interacts with) 采",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 采",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2586,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2585",
        "source" : "522",
        "target" : "196",
        "shared_name" : "倉 (interacts with) 麁",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 麁",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2584",
        "source" : "522",
        "target" : "138",
        "shared_name" : "倉 (interacts with) 麤",
        "shared_interaction" : "interacts with",
        "name" : "倉 (interacts with) 麤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2583",
        "source" : "523",
        "target" : "63",
        "shared_name" : "烏 (interacts with) 愛",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 愛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2583,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2582",
        "source" : "523",
        "target" : "2375",
        "shared_name" : "烏 (interacts with) 區2",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 區2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2581",
        "source" : "523",
        "target" : "2362",
        "shared_name" : "烏 (interacts with) 烟2",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 烟2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2580",
        "source" : "523",
        "target" : "245",
        "shared_name" : "烏 (interacts with) 安",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 安",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2579",
        "source" : "523",
        "target" : "413",
        "shared_name" : "烏 (interacts with) 哀",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 哀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2578",
        "source" : "523",
        "target" : "115",
        "shared_name" : "烏 (interacts with) 鷖",
        "shared_interaction" : "interacts with",
        "name" : "烏 (interacts with) 鷖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2577",
        "source" : "524",
        "target" : "2428",
        "shared_name" : "徂 (interacts with) 藏2",
        "shared_interaction" : "interacts with",
        "name" : "徂 (interacts with) 藏2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2577,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2576",
        "source" : "525",
        "target" : "244",
        "shared_name" : "戸 (interacts with) 侯",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 侯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2575",
        "source" : "525",
        "target" : "237",
        "shared_name" : "戸 (interacts with) 懷",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 懷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2574",
        "source" : "525",
        "target" : "174",
        "shared_name" : "戸 (interacts with) 乎",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 乎",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2574,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2573",
        "source" : "525",
        "target" : "407",
        "shared_name" : "戸 (interacts with) 胡",
        "shared_interaction" : "interacts with",
        "name" : "戸 (interacts with) 胡",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2572",
        "source" : "526",
        "target" : "295",
        "shared_name" : "盧 (interacts with) 勒",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 勒",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2571",
        "source" : "526",
        "target" : "143",
        "shared_name" : "盧 (interacts with) 洛",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 洛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2571,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2570",
        "source" : "526",
        "target" : "416",
        "shared_name" : "盧 (interacts with) 落",
        "shared_interaction" : "interacts with",
        "name" : "盧 (interacts with) 落",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2569",
        "source" : "527",
        "target" : "104",
        "shared_name" : "古 (interacts with) 格",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 格",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2568",
        "source" : "527",
        "target" : "197",
        "shared_name" : "古 (interacts with) 各",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 各",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2568,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2567",
        "source" : "527",
        "target" : "181",
        "shared_name" : "古 (interacts with) 兼",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 兼",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2566",
        "source" : "527",
        "target" : "284",
        "shared_name" : "古 (interacts with) 過",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 過",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2565",
        "source" : "527",
        "target" : "175",
        "shared_name" : "古 (interacts with) 干",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 干",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2565,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2564",
        "source" : "527",
        "target" : "239",
        "shared_name" : "古 (interacts with) 乖",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 乖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2563",
        "source" : "527",
        "target" : "70",
        "shared_name" : "古 (interacts with) 楷",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 楷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2562",
        "source" : "527",
        "target" : "240",
        "shared_name" : "古 (interacts with) 佳",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 佳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2562,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2561",
        "source" : "527",
        "target" : "218",
        "shared_name" : "古 (interacts with) 姑",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 姑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2560",
        "source" : "527",
        "target" : "394",
        "shared_name" : "古 (interacts with) 公",
        "shared_interaction" : "interacts with",
        "name" : "古 (interacts with) 公",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2559",
        "source" : "528",
        "target" : "320",
        "shared_name" : "苦 (interacts with) 客",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 客",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2559,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2558",
        "source" : "528",
        "target" : "304",
        "shared_name" : "苦 (interacts with) 恪",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 恪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2557",
        "source" : "528",
        "target" : "2413",
        "shared_name" : "苦 (interacts with) 苦2",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 苦2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2556",
        "source" : "528",
        "target" : "396",
        "shared_name" : "苦 (interacts with) 口",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 口",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2555",
        "source" : "528",
        "target" : "2390",
        "shared_name" : "苦 (interacts with) 楷2",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 楷2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2554",
        "source" : "528",
        "target" : "183",
        "shared_name" : "苦 (interacts with) 謙",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 謙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2553",
        "source" : "528",
        "target" : "291",
        "shared_name" : "苦 (interacts with) 康",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 康",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2553,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2552",
        "source" : "528",
        "target" : "217",
        "shared_name" : "苦 (interacts with) 牽",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 牽",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2551",
        "source" : "528",
        "target" : "207",
        "shared_name" : "苦 (interacts with) 枯",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 枯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2551,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2550",
        "source" : "528",
        "target" : "221",
        "shared_name" : "苦 (interacts with) 空",
        "shared_interaction" : "interacts with",
        "name" : "苦 (interacts with) 空",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2550,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2549",
        "source" : "529",
        "target" : "2397",
        "shared_name" : "力 (interacts with) 離2",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 離2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2548",
        "source" : "529",
        "target" : "328",
        "shared_name" : "力 (interacts with) 縷",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 縷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2547",
        "source" : "529",
        "target" : "488",
        "shared_name" : "力 (interacts with) 吕",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 吕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2547,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2546",
        "source" : "529",
        "target" : "66",
        "shared_name" : "力 (interacts with) 林",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 林",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2545",
        "source" : "529",
        "target" : "125",
        "shared_name" : "力 (interacts with) 連",
        "shared_interaction" : "interacts with",
        "name" : "力 (interacts with) 連",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2544",
        "source" : "530",
        "target" : "443",
        "shared_name" : "昌 (interacts with) 赤",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 赤",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2544,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2543",
        "source" : "530",
        "target" : "508",
        "shared_name" : "昌 (interacts with) 尺",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 尺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2543,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2542",
        "source" : "530",
        "target" : "460",
        "shared_name" : "昌 (interacts with) 處",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 處",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2541",
        "source" : "530",
        "target" : "356",
        "shared_name" : "昌 (interacts with) 充",
        "shared_interaction" : "interacts with",
        "name" : "昌 (interacts with) 充",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2541,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2540",
        "source" : "531",
        "target" : "87",
        "shared_name" : "敷 (interacts with) 拂",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 拂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2539",
        "source" : "531",
        "target" : "439",
        "shared_name" : "敷 (interacts with) 芳",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 芳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2538",
        "source" : "531",
        "target" : "189",
        "shared_name" : "敷 (interacts with) 丕",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 丕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2538,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2537",
        "source" : "531",
        "target" : "168",
        "shared_name" : "敷 (interacts with) 披",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 披",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2536",
        "source" : "531",
        "target" : "179",
        "shared_name" : "敷 (interacts with) 峯",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 峯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2535",
        "source" : "532",
        "target" : "178",
        "shared_name" : "方 (interacts with) 徧",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 徧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2535,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2534",
        "source" : "532",
        "target" : "2396",
        "shared_name" : "方 (interacts with) 封2",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 封2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2533",
        "source" : "532",
        "target" : "112",
        "shared_name" : "方 (interacts with) 父",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 父",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2532",
        "source" : "532",
        "target" : "506",
        "shared_name" : "方 (interacts with) 府",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 府",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2532,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2531",
        "source" : "532",
        "target" : "438",
        "shared_name" : "方 (interacts with) 甫",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 甫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2531,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2530",
        "source" : "532",
        "target" : "94",
        "shared_name" : "方 (interacts with) 鄙",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 鄙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2529",
        "source" : "533",
        "target" : "71",
        "shared_name" : "房 (interacts with) 弼",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 弼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2528",
        "source" : "533",
        "target" : "209",
        "shared_name" : "房 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2528,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2527",
        "source" : "533",
        "target" : "274",
        "shared_name" : "房 (interacts with) 便",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 便",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2526",
        "source" : "533",
        "target" : "116",
        "shared_name" : "房 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2525",
        "source" : "533",
        "target" : "233",
        "shared_name" : "房 (interacts with) 毗",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 毗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2525,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2524",
        "source" : "533",
        "target" : "176",
        "shared_name" : "房 (interacts with) 馮",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 馮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2523",
        "source" : "534",
        "target" : "2426",
        "shared_name" : "渠 (interacts with) 狂2",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 狂2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2522",
        "source" : "534",
        "target" : "2380",
        "shared_name" : "渠 (interacts with) 跪2",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 跪2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2522,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2521",
        "source" : "534",
        "target" : "442",
        "shared_name" : "渠 (interacts with) 俟",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 俟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2520",
        "source" : "534",
        "target" : "427",
        "shared_name" : "渠 (interacts with) 其",
        "shared_interaction" : "interacts with",
        "name" : "渠 (interacts with) 其",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2520,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2519",
        "source" : "535",
        "target" : "322",
        "shared_name" : "去 (interacts with) 乞",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 乞",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2519,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2518",
        "source" : "535",
        "target" : "158",
        "shared_name" : "去 (interacts with) 詰",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 詰",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2517",
        "source" : "535",
        "target" : "353",
        "shared_name" : "去 (interacts with) 跪",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 跪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2516",
        "source" : "535",
        "target" : "188",
        "shared_name" : "去 (interacts with) 欽",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 欽",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2516,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2515",
        "source" : "535",
        "target" : "452",
        "shared_name" : "去 (interacts with) 丘",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 丘",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2514",
        "source" : "535",
        "target" : "80",
        "shared_name" : "去 (interacts with) 傾",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 傾",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2513",
        "source" : "535",
        "target" : "161",
        "shared_name" : "去 (interacts with) 卿",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 卿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2513,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2512",
        "source" : "535",
        "target" : "254",
        "shared_name" : "去 (interacts with) 羌",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 羌",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2511",
        "source" : "535",
        "target" : "260",
        "shared_name" : "去 (interacts with) 袪",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 袪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2511,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2510",
        "source" : "535",
        "target" : "283",
        "shared_name" : "去 (interacts with) 墟",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 墟",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2510,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2509",
        "source" : "535",
        "target" : "373",
        "shared_name" : "去 (interacts with) 虚",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 虚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2508",
        "source" : "535",
        "target" : "165",
        "shared_name" : "去 (interacts with) 窺",
        "shared_interaction" : "interacts with",
        "name" : "去 (interacts with) 窺",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2507",
        "source" : "536",
        "target" : "350",
        "shared_name" : "莫 (interacts with) 目",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 目",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2507,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2506",
        "source" : "536",
        "target" : "74",
        "shared_name" : "莫 (interacts with) 慕",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 慕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2505",
        "source" : "536",
        "target" : "361",
        "shared_name" : "莫 (interacts with) 母",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 母",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2505,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2504",
        "source" : "536",
        "target" : "186",
        "shared_name" : "莫 (interacts with) 謨",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 謨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2504,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2503",
        "source" : "536",
        "target" : "122",
        "shared_name" : "莫 (interacts with) 摸",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 摸",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2502",
        "source" : "536",
        "target" : "222",
        "shared_name" : "莫 (interacts with) 模",
        "shared_interaction" : "interacts with",
        "name" : "莫 (interacts with) 模",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2501",
        "source" : "537",
        "target" : "339",
        "shared_name" : "羽 (interacts with) 于",
        "shared_interaction" : "interacts with",
        "name" : "羽 (interacts with) 于",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2501,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2500",
        "source" : "538",
        "target" : "448",
        "shared_name" : "以 (interacts with) 與",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 與",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2499",
        "source" : "538",
        "target" : "507",
        "shared_name" : "以 (interacts with) 餘",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 餘",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2499,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2498",
        "source" : "538",
        "target" : "316",
        "shared_name" : "以 (interacts with) 余",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 余",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2498,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2497",
        "source" : "538",
        "target" : "235",
        "shared_name" : "以 (interacts with) 夷",
        "shared_interaction" : "interacts with",
        "name" : "以 (interacts with) 夷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2496",
        "source" : "539",
        "target" : "127",
        "shared_name" : "居 (interacts with) 吉",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 吉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2495",
        "source" : "539",
        "target" : "266",
        "shared_name" : "居 (interacts with) 曁",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 曁",
        "interaction" : "interacts with",
        "weight" : 3,
        "SUID" : 2495,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2494",
        "source" : "539",
        "target" : "437",
        "shared_name" : "居 (interacts with) 舉",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 舉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2493",
        "source" : "539",
        "target" : "108",
        "shared_name" : "居 (interacts with) 紀",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 紀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2492",
        "source" : "539",
        "target" : "157",
        "shared_name" : "居 (interacts with) 几",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 几",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2492,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2491",
        "source" : "539",
        "target" : "2353",
        "shared_name" : "居 (interacts with) 其2",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 其2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2490",
        "source" : "539",
        "target" : "163",
        "shared_name" : "居 (interacts with) 規",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 規",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2490,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2489",
        "source" : "539",
        "target" : "167",
        "shared_name" : "居 (interacts with) 奇",
        "shared_interaction" : "interacts with",
        "name" : "居 (interacts with) 奇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2489,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2488",
        "source" : "540",
        "target" : "151",
        "shared_name" : "如 (interacts with) 仍",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 仍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2487",
        "source" : "540",
        "target" : "469",
        "shared_name" : "如 (interacts with) 人",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 人",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2486",
        "source" : "540",
        "target" : "497",
        "shared_name" : "如 (interacts with) 而",
        "shared_interaction" : "interacts with",
        "name" : "如 (interacts with) 而",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2486,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2485",
        "source" : "541",
        "target" : "204",
        "shared_name" : "息 (interacts with) 悉",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 悉",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2484",
        "source" : "541",
        "target" : "314",
        "shared_name" : "息 (interacts with) 桑",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 桑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2483",
        "source" : "541",
        "target" : "434",
        "shared_name" : "息 (interacts with) 相",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 相",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2483,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2482",
        "source" : "541",
        "target" : "91",
        "shared_name" : "息 (interacts with) 辛",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 辛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2481",
        "source" : "541",
        "target" : "121",
        "shared_name" : "息 (interacts with) 司",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 司",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2481,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2480",
        "source" : "541",
        "target" : "371",
        "shared_name" : "息 (interacts with) 思",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 思",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2480,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2479",
        "source" : "541",
        "target" : "159",
        "shared_name" : "息 (interacts with) 雖",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 雖",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2478",
        "source" : "541",
        "target" : "511",
        "shared_name" : "息 (interacts with) 私",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 私",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2477",
        "source" : "541",
        "target" : "279",
        "shared_name" : "息 (interacts with) 斯",
        "shared_interaction" : "interacts with",
        "name" : "息 (interacts with) 斯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2477,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2476",
        "source" : "542",
        "target" : "346",
        "shared_name" : "鋤 (interacts with) 崇",
        "shared_interaction" : "interacts with",
        "name" : "鋤 (interacts with) 崇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2475",
        "source" : "543",
        "target" : "500",
        "shared_name" : "敕 (interacts with) 丑",
        "shared_interaction" : "interacts with",
        "name" : "敕 (interacts with) 丑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2475,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2474",
        "source" : "543",
        "target" : "65",
        "shared_name" : "敕 (interacts with) 恥",
        "shared_interaction" : "interacts with",
        "name" : "敕 (interacts with) 恥",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2474,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2473",
        "source" : "544",
        "target" : "311",
        "shared_name" : "職 (interacts with) 識",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 識",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2472",
        "source" : "544",
        "target" : "462",
        "shared_name" : "職 (interacts with) 旨",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 旨",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2471",
        "source" : "544",
        "target" : "185",
        "shared_name" : "職 (interacts with) 占",
        "shared_interaction" : "interacts with",
        "name" : "職 (interacts with) 占",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2471,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2470",
        "source" : "545",
        "target" : "388",
        "shared_name" : "直 (interacts with) 植",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 植",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2469",
        "source" : "545",
        "target" : "354",
        "shared_name" : "直 (interacts with) 墜",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 墜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2469,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2468",
        "source" : "545",
        "target" : "238",
        "shared_name" : "直 (interacts with) 丈",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 丈",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2468,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2467",
        "source" : "545",
        "target" : "173",
        "shared_name" : "直 (interacts with) 柱",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 柱",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2466",
        "source" : "545",
        "target" : "106",
        "shared_name" : "直 (interacts with) 佇",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 佇",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2465",
        "source" : "545",
        "target" : "72",
        "shared_name" : "直 (interacts with) 場",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 場",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2464",
        "source" : "545",
        "target" : "214",
        "shared_name" : "直 (interacts with) 除",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 除",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2464,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2463",
        "source" : "545",
        "target" : "216",
        "shared_name" : "直 (interacts with) 持",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 持",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2462",
        "source" : "545",
        "target" : "212",
        "shared_name" : "直 (interacts with) 治",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 治",
        "interaction" : "interacts with",
        "weight" : 3,
        "SUID" : 2462,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2461",
        "source" : "545",
        "target" : "147",
        "shared_name" : "直 (interacts with) 遟",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 遟",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2460",
        "source" : "545",
        "target" : "280",
        "shared_name" : "直 (interacts with) 池",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 池",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2460,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2459",
        "source" : "545",
        "target" : "166",
        "shared_name" : "直 (interacts with) 馳",
        "shared_interaction" : "interacts with",
        "name" : "直 (interacts with) 馳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2458",
        "source" : "546",
        "target" : "93",
        "shared_name" : "陟 (interacts with) 徵",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 徵",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2457",
        "source" : "546",
        "target" : "344",
        "shared_name" : "陟 (interacts with) 張",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 張",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2456",
        "source" : "546",
        "target" : "228",
        "shared_name" : "陟 (interacts with) 珍",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 珍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2455",
        "source" : "546",
        "target" : "117",
        "shared_name" : "陟 (interacts with) 猪",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 猪",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2455,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2454",
        "source" : "546",
        "target" : "268",
        "shared_name" : "陟 (interacts with) 豬",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 豬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2453",
        "source" : "546",
        "target" : "154",
        "shared_name" : "陟 (interacts with) 追",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 追",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2452",
        "source" : "546",
        "target" : "299",
        "shared_name" : "陟 (interacts with) 知",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 知",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2451",
        "source" : "546",
        "target" : "317",
        "shared_name" : "陟 (interacts with) 中",
        "shared_interaction" : "interacts with",
        "name" : "陟 (interacts with) 中",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2450",
        "source" : "547",
        "target" : "315",
        "shared_name" : "徒 (interacts with) 特",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 特",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2449",
        "source" : "547",
        "target" : "364",
        "shared_name" : "徒 (interacts with) 度",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 度",
        "interaction" : "interacts with",
        "weight" : 2,
        "SUID" : 2449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2448",
        "source" : "547",
        "target" : "2388",
        "shared_name" : "徒 (interacts with) 土2",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 土2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2448,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2447",
        "source" : "547",
        "target" : "409",
        "shared_name" : "徒 (interacts with) 杜",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 杜",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2446",
        "source" : "547",
        "target" : "128",
        "shared_name" : "徒 (interacts with) 堂",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 堂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2445",
        "source" : "547",
        "target" : "123",
        "shared_name" : "徒 (interacts with) 唐",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 唐",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2444",
        "source" : "547",
        "target" : "2363",
        "shared_name" : "徒 (interacts with) 池2",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 池2",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2443",
        "source" : "547",
        "target" : "86",
        "shared_name" : "徒 (interacts with) 陀",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 陀",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2443,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "2442",
        "source" : "547",
        "target" : "420",
        "shared_name" : "徒 (interacts with) 同",
        "shared_interaction" : "interacts with",
        "name" : "徒 (interacts with) 同",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 2442,
        "selected" : false
      },
      "selected" : false
    } ]
  }
},"guangyun.gml(1)": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "guangyun.gml(1)",
    "name" : "guangyun.gml(1)",
    "SUID" : 1115,
    "__Annotations" : [ "" ],
    "selected" : false
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "499",
        "shared_name" : "符",
        "color" : "#c8c864",
        "name" : "符",
        "reading" : "bʰĭu˩",
        "SUID" : 499,
        "label" : "符",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1601.589585513933,
        "y" : 546.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "243",
        "shared_name" : "傍",
        "color" : "#c8c864",
        "name" : "傍",
        "reading" : "bʰɑŋ˩",
        "SUID" : 243,
        "label" : "傍",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1941.589585513933,
        "y" : 549.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "370",
        "shared_name" : "蒲",
        "color" : "#c8c864",
        "name" : "蒲",
        "reading" : "bʰu˩",
        "SUID" : 370,
        "label" : "蒲",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1941.589585513933,
        "y" : 435.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "114",
        "shared_name" : "𢌿",
        "color" : "#c8c864",
        "name" : "𢌿",
        "reading" : "pi˩˥",
        "SUID" : 114,
        "label" : "𢌿",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1852.589585513933,
        "y" : 983.1704917519791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "112",
        "shared_name" : "父",
        "color" : "#c8c864",
        "name" : "父",
        "reading" : "pĭu˥",
        "SUID" : 112,
        "label" : "父",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1482.589585513933,
        "y" : 522.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "489",
        "shared_name" : "匹",
        "color" : "#c8c864",
        "name" : "匹",
        "reading" : "pʰĭĕt",
        "SUID" : 489,
        "label" : "匹",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -800.5895855139329,
        "y" : 38.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "233",
        "shared_name" : "毗",
        "color" : "#c8c864",
        "name" : "毗",
        "reading" : "bʰi˩",
        "SUID" : 233,
        "label" : "毗",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1730.589585513933,
        "y" : 737.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "102",
        "shared_name" : "賔",
        "color" : "#c8c864",
        "name" : "賔",
        "reading" : "pĭĕn˥˩",
        "SUID" : 102,
        "label" : "賔",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1726.589585513933,
        "y" : 1045.1704917519792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "226",
        "shared_name" : "反",
        "color" : "#c8c864",
        "name" : "反",
        "reading" : "pʰĭwɐn˥˩",
        "SUID" : 226,
        "label" : "反",
        "community" : 10,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1226.589585513933,
        "y" : 327.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "97",
        "shared_name" : "封",
        "color" : "#c8c864",
        "name" : "封",
        "reading" : "pĭwoŋ˥˩",
        "SUID" : 97,
        "label" : "封",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1414.589585513933,
        "y" : 346.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "96",
        "shared_name" : "譬",
        "color" : "#c8c864",
        "name" : "譬",
        "reading" : "pʰĭe˩˥",
        "SUID" : 96,
        "label" : "譬",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -683.5895855139329,
        "y" : 19.170491751978943
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "351",
        "shared_name" : "並",
        "color" : "#c8c864",
        "name" : "並",
        "reading" : "bʰieŋ˥",
        "SUID" : 351,
        "label" : "並",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -2054.589585513933,
        "y" : 390.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "478",
        "shared_name" : "彼",
        "color" : "#c8c864",
        "name" : "彼",
        "reading" : "pĭe˥",
        "SUID" : 478,
        "label" : "彼",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1290.589585513933,
        "y" : 651.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "94",
        "shared_name" : "鄙",
        "color" : "#c8c864",
        "name" : "鄙",
        "reading" : "pi˥",
        "SUID" : 94,
        "label" : "鄙",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1576.589585513933,
        "y" : 344.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "348",
        "shared_name" : "偏",
        "color" : "#c8c864",
        "name" : "偏",
        "reading" : "pʰĭɛn˥˩",
        "SUID" : 348,
        "label" : "偏",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -876.5895855139329,
        "y" : 121.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "87",
        "shared_name" : "拂",
        "color" : "#c8c864",
        "name" : "拂",
        "reading" : "pʰĭuət",
        "SUID" : 87,
        "label" : "拂",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1026.0400726304463,
        "y" : -82.82950824802106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "342",
        "shared_name" : "卑",
        "color" : "#c8c864",
        "name" : "卑",
        "reading" : "dzʰæn˩",
        "SUID" : 342,
        "label" : "卑",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1633.589585513933,
        "y" : 916.1704917519791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "211",
        "shared_name" : "苻",
        "color" : "#c8c864",
        "name" : "苻",
        "reading" : "bʰĭu˩",
        "SUID" : 211,
        "label" : "苻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1429.589585513933,
        "y" : 737.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "338",
        "shared_name" : "撫",
        "color" : "#c8c864",
        "name" : "撫",
        "reading" : "pʰĭu˥",
        "SUID" : 338,
        "label" : "撫",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -986.5895855139329,
        "y" : 318.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "210",
        "shared_name" : "陂",
        "color" : "#c8c864",
        "name" : "陂",
        "reading" : "pĭe˩˥",
        "SUID" : 210,
        "label" : "陂",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1198.589585513933,
        "y" : 727.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "209",
        "shared_name" : "平",
        "color" : "#c8c864",
        "name" : "平",
        "reading" : "bʰĭɛn˩",
        "SUID" : 209,
        "label" : "平",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1759.589585513933,
        "y" : 571.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "206",
        "shared_name" : "捕",
        "color" : "#c8c864",
        "name" : "捕",
        "reading" : "bʰu˩˥",
        "SUID" : 206,
        "label" : "捕",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1910.589585513933,
        "y" : 336.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "331",
        "shared_name" : "滂",
        "color" : "#c8c864",
        "name" : "滂",
        "reading" : "pʰɑŋ˥˩",
        "SUID" : 331,
        "label" : "滂",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : -766.5895855139329,
        "y" : 290.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "200",
        "shared_name" : "妃",
        "color" : "#c8c864",
        "name" : "妃",
        "reading" : "pʰĭwəi˥˩",
        "SUID" : 200,
        "label" : "妃",
        "community" : 55,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -900.829567179902,
        "y" : 233.34397102810584
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "199",
        "shared_name" : "分",
        "color" : "#c8c864",
        "name" : "分",
        "reading" : "pĭuən˥˩",
        "SUID" : 199,
        "label" : "分",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1385.589585513933,
        "y" : 469.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "71",
        "shared_name" : "弼",
        "color" : "#c8c864",
        "name" : "弼",
        "reading" : "bʰĭĕt",
        "SUID" : 71,
        "label" : "弼",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1806.589585513933,
        "y" : 779.1704917519791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "195",
        "shared_name" : "兵",
        "color" : "#c8c864",
        "name" : "兵",
        "reading" : "pĭɐŋ˥˩",
        "SUID" : 195,
        "label" : "兵",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1250.589585513933,
        "y" : 530.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "189",
        "shared_name" : "丕",
        "color" : "#c8c864",
        "name" : "丕",
        "reading" : "pʰi˥˩",
        "SUID" : 189,
        "label" : "丕",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1245.1390983974193,
        "y" : 43.66737325772567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "312",
        "shared_name" : "筆",
        "color" : "#c8c864",
        "name" : "筆",
        "reading" : "pĭĕt",
        "SUID" : 312,
        "label" : "筆",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1585.589585513933,
        "y" : 228.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "439",
        "shared_name" : "芳",
        "color" : "#c8c864",
        "name" : "芳",
        "reading" : "pʰĭwaŋ˥˩",
        "SUID" : 439,
        "label" : "芳",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1031.6561279296875,
        "y" : 173.4595568039254
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "438",
        "shared_name" : "甫",
        "color" : "#c8c864",
        "name" : "甫",
        "reading" : "pĭu˥",
        "SUID" : 438,
        "label" : "甫",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1369.589585513933,
        "y" : 557.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "179",
        "shared_name" : "峯",
        "color" : "#c8c864",
        "name" : "峯",
        "reading" : "pʰĭwoŋ˥˩",
        "SUID" : 179,
        "label" : "峯",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1245.1390983974195,
        "y" : -209.32638975376778
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "306",
        "shared_name" : "縛",
        "color" : "#c8c864",
        "name" : "縛",
        "reading" : "bʰĭwak",
        "SUID" : 306,
        "label" : "縛",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1612.589585513933,
        "y" : 698.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "178",
        "shared_name" : "徧",
        "color" : "#c8c864",
        "name" : "徧",
        "reading" : "pien˩˥",
        "SUID" : 178,
        "label" : "徧",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1490.589585513933,
        "y" : 346.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "177",
        "shared_name" : "頻",
        "color" : "#c8c864",
        "name" : "頻",
        "reading" : "bʰĭĕn˩",
        "SUID" : 177,
        "label" : "頻",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1683.589585513933,
        "y" : 561.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "176",
        "shared_name" : "馮",
        "color" : "#c8c864",
        "name" : "馮",
        "reading" : "bʰĭuŋ˩",
        "SUID" : 176,
        "label" : "馮",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1588.589585513933,
        "y" : 622.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "301",
        "shared_name" : "皮",
        "color" : "#c8c864",
        "name" : "皮",
        "reading" : "bʰĭe˩",
        "SUID" : 301,
        "label" : "皮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1568.589585513933,
        "y" : 466.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "424",
        "shared_name" : "防",
        "color" : "#c8c864",
        "name" : "防",
        "reading" : "bʰĭwaŋ˩˥",
        "SUID" : 424,
        "label" : "防",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1511.589585513933,
        "y" : 675.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "168",
        "shared_name" : "披",
        "color" : "#c8c864",
        "name" : "披",
        "reading" : "pʰĭe˥˩",
        "SUID" : 168,
        "label" : "披",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -822.5895855139329,
        "y" : -81.82950824802106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "294",
        "shared_name" : "白",
        "color" : "#c8c864",
        "name" : "白",
        "reading" : "bʰɐk",
        "SUID" : 294,
        "label" : "白",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -2057.589585513933,
        "y" : 580.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "292",
        "shared_name" : "僕",
        "color" : "#c8c864",
        "name" : "僕",
        "reading" : "bʰuok",
        "SUID" : 292,
        "label" : "僕",
        "community" : 25,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1854.589585513933,
        "y" : 524.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "411",
        "shared_name" : "普",
        "color" : "#c8c864",
        "name" : "普",
        "reading" : "pʰu˥",
        "SUID" : 411,
        "label" : "普",
        "community" : 55,
        "selected" : false,
        "group" : "ph "
      },
      "position" : {
        "x" : -654.5895855139329,
        "y" : 326.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "533",
        "shared_name" : "房",
        "color" : "#c8c864",
        "name" : "房",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 533,
        "label" : "房",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1713.589585513933,
        "y" : 661.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "277",
        "shared_name" : "并",
        "color" : "#c8c864",
        "name" : "并",
        "reading" : "pĭɛŋ˥˩",
        "SUID" : 277,
        "label" : "并",
        "community" : 2,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1338.589585513933,
        "y" : 256.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "532",
        "shared_name" : "方",
        "color" : "#c8c864",
        "name" : "方",
        "reading" : "bʰĭwaŋ˩",
        "SUID" : 532,
        "label" : "方",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1479.589585513933,
        "y" : 438.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "404",
        "shared_name" : "部",
        "color" : "#c8c864",
        "name" : "部",
        "reading" : "bʰu˥",
        "SUID" : 404,
        "label" : "部",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1814.589585513933,
        "y" : 368.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "531",
        "shared_name" : "敷",
        "color" : "#c8c864",
        "name" : "敷",
        "reading" : "pʰĭu˥˩",
        "SUID" : 531,
        "label" : "敷",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1172.1060898084284,
        "y" : -82.82950824802106
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "274",
        "shared_name" : "便",
        "color" : "#c8c864",
        "name" : "便",
        "reading" : "bʰĭɛn˩",
        "SUID" : 274,
        "label" : "便",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1847.589585513933,
        "y" : 690.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "399",
        "shared_name" : "步",
        "color" : "#c8c864",
        "name" : "步",
        "reading" : "bʰu˩˥",
        "SUID" : 399,
        "label" : "步",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1839.589585513933,
        "y" : 600.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "519",
        "shared_name" : "薄",
        "color" : "#c8c864",
        "name" : "薄",
        "reading" : "bʰuɑk",
        "SUID" : 519,
        "label" : "薄",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1854.589585513933,
        "y" : 448.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "389",
        "shared_name" : "扶",
        "color" : "#c8c864",
        "name" : "扶",
        "reading" : "bʰĭu˩",
        "SUID" : 389,
        "label" : "扶",
        "community" : 2,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1466.589585513933,
        "y" : 598.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "259",
        "shared_name" : "浮",
        "color" : "#c8c864",
        "name" : "浮",
        "reading" : "bʰĭəu˩",
        "SUID" : 259,
        "label" : "浮",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1552.589585513933,
        "y" : 796.1704917519791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "385",
        "shared_name" : "必",
        "color" : "#c8c864",
        "name" : "必",
        "reading" : "pĭĕt",
        "SUID" : 385,
        "label" : "必",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1746.589585513933,
        "y" : 925.1704917519791
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "126",
        "shared_name" : "婢",
        "color" : "#c8c864",
        "name" : "婢",
        "reading" : "bʰĭe˥",
        "SUID" : 126,
        "label" : "婢",
        "community" : 16,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1952.589585513933,
        "y" : 753.170491751979
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "506",
        "shared_name" : "府",
        "color" : "#c8c864",
        "name" : "府",
        "reading" : "pĭu˥",
        "SUID" : 506,
        "label" : "府",
        "community" : 2,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1330.589585513933,
        "y" : 377.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "375",
        "shared_name" : "附",
        "color" : "#c8c864",
        "name" : "附",
        "reading" : "bʰĭu˩˥",
        "SUID" : 375,
        "label" : "附",
        "community" : 25,
        "selected" : false,
        "group" : "b j"
      },
      "position" : {
        "x" : -1661.589585513933,
        "y" : 418.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "374",
        "shared_name" : "孚",
        "color" : "#c8c864",
        "name" : "孚",
        "reading" : "pʰĭu˥˩",
        "SUID" : 374,
        "label" : "孚",
        "community" : 10,
        "selected" : false,
        "group" : "ph j"
      },
      "position" : {
        "x" : -1112.589585513933,
        "y" : 260.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "246",
        "shared_name" : "裴",
        "color" : "#c8c864",
        "name" : "裴",
        "reading" : "bʰĭwəi˩",
        "SUID" : 246,
        "label" : "裴",
        "community" : 26,
        "selected" : false,
        "group" : "b "
      },
      "position" : {
        "x" : -1742.589585513933,
        "y" : 470.17049175197894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "116",
        "shared_name" : "比",
        "color" : "#c8c864",
        "name" : "比",
        "reading" : "bʰi˩",
        "SUID" : 116,
        "label" : "比",
        "community" : 16,
        "selected" : false,
        "group" : "p j"
      },
      "position" : {
        "x" : -1688.589585513933,
        "y" : 813.1704917519791
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "878",
        "source" : "499",
        "target" : "306",
        "shared_name" : "符 (interacts with) 縛",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 縛",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "879",
        "source" : "499",
        "target" : "375",
        "shared_name" : "符 (interacts with) 附",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 附",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "880",
        "source" : "499",
        "target" : "209",
        "shared_name" : "符 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "881",
        "source" : "499",
        "target" : "532",
        "shared_name" : "符 (interacts with) 方",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 方",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "882",
        "source" : "499",
        "target" : "424",
        "shared_name" : "符 (interacts with) 防",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 防",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "883",
        "source" : "499",
        "target" : "533",
        "shared_name" : "符 (interacts with) 房",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 房",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "884",
        "source" : "499",
        "target" : "177",
        "shared_name" : "符 (interacts with) 頻",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 頻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "885",
        "source" : "499",
        "target" : "246",
        "shared_name" : "符 (interacts with) 裴",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 裴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "886",
        "source" : "499",
        "target" : "301",
        "shared_name" : "符 (interacts with) 皮",
        "shared_interaction" : "interacts with",
        "name" : "符 (interacts with) 皮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "580",
        "source" : "243",
        "target" : "294",
        "shared_name" : "傍 (interacts with) 白",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 白",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 580,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "581",
        "source" : "243",
        "target" : "519",
        "shared_name" : "傍 (interacts with) 薄",
        "shared_interaction" : "interacts with",
        "name" : "傍 (interacts with) 薄",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "662",
        "source" : "370",
        "target" : "292",
        "shared_name" : "蒲 (interacts with) 僕",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 僕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "663",
        "source" : "370",
        "target" : "243",
        "shared_name" : "蒲 (interacts with) 傍",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 傍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "664",
        "source" : "370",
        "target" : "404",
        "shared_name" : "蒲 (interacts with) 部",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 部",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "665",
        "source" : "370",
        "target" : "351",
        "shared_name" : "蒲 (interacts with) 並",
        "shared_interaction" : "interacts with",
        "name" : "蒲 (interacts with) 並",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 665,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "855",
        "source" : "489",
        "target" : "348",
        "shared_name" : "匹 (interacts with) 偏",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 偏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 855,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "856",
        "source" : "489",
        "target" : "96",
        "shared_name" : "匹 (interacts with) 譬",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 譬",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 856,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "857",
        "source" : "489",
        "target" : "168",
        "shared_name" : "匹 (interacts with) 披",
        "shared_interaction" : "interacts with",
        "name" : "匹 (interacts with) 披",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 857,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "578",
        "source" : "233",
        "target" : "116",
        "shared_name" : "毗 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "毗 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "556",
        "source" : "96",
        "target" : "489",
        "shared_name" : "譬 (interacts with) 匹",
        "shared_interaction" : "interacts with",
        "name" : "譬 (interacts with) 匹",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 556,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "831",
        "source" : "478",
        "target" : "210",
        "shared_name" : "彼 (interacts with) 陂",
        "shared_interaction" : "interacts with",
        "name" : "彼 (interacts with) 陂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "555",
        "source" : "94",
        "target" : "312",
        "shared_name" : "鄙 (interacts with) 筆",
        "shared_interaction" : "interacts with",
        "name" : "鄙 (interacts with) 筆",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 555,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "648",
        "source" : "342",
        "target" : "385",
        "shared_name" : "卑 (interacts with) 必",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 必",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 648,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "649",
        "source" : "342",
        "target" : "116",
        "shared_name" : "卑 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "卑 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "636",
        "source" : "331",
        "target" : "200",
        "shared_name" : "滂 (interacts with) 妃",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 妃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "637",
        "source" : "331",
        "target" : "411",
        "shared_name" : "滂 (interacts with) 普",
        "shared_interaction" : "interacts with",
        "name" : "滂 (interacts with) 普",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 637,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "768",
        "source" : "439",
        "target" : "200",
        "shared_name" : "芳 (interacts with) 妃",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 妃",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 768,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "764",
        "source" : "439",
        "target" : "338",
        "shared_name" : "芳 (interacts with) 撫",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 撫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "765",
        "source" : "439",
        "target" : "348",
        "shared_name" : "芳 (interacts with) 偏",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 偏",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "766",
        "source" : "439",
        "target" : "374",
        "shared_name" : "芳 (interacts with) 孚",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 孚",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "767",
        "source" : "439",
        "target" : "531",
        "shared_name" : "芳 (interacts with) 敷",
        "shared_interaction" : "interacts with",
        "name" : "芳 (interacts with) 敷",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "761",
        "source" : "438",
        "target" : "478",
        "shared_name" : "甫 (interacts with) 彼",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 彼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "762",
        "source" : "438",
        "target" : "195",
        "shared_name" : "甫 (interacts with) 兵",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 兵",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "763",
        "source" : "438",
        "target" : "389",
        "shared_name" : "甫 (interacts with) 扶",
        "shared_interaction" : "interacts with",
        "name" : "甫 (interacts with) 扶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "619",
        "source" : "306",
        "target" : "259",
        "shared_name" : "縛 (interacts with) 浮",
        "shared_interaction" : "interacts with",
        "name" : "縛 (interacts with) 浮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 619,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "733",
        "source" : "424",
        "target" : "211",
        "shared_name" : "防 (interacts with) 苻",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 苻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "734",
        "source" : "424",
        "target" : "499",
        "shared_name" : "防 (interacts with) 符",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 符",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "735",
        "source" : "424",
        "target" : "389",
        "shared_name" : "防 (interacts with) 扶",
        "shared_interaction" : "interacts with",
        "name" : "防 (interacts with) 扶",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "616",
        "source" : "292",
        "target" : "209",
        "shared_name" : "僕 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "僕 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 616,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "708",
        "source" : "411",
        "target" : "331",
        "shared_name" : "普 (interacts with) 滂",
        "shared_interaction" : "interacts with",
        "name" : "普 (interacts with) 滂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1026",
        "source" : "533",
        "target" : "71",
        "shared_name" : "房 (interacts with) 弼",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 弼",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1027",
        "source" : "533",
        "target" : "209",
        "shared_name" : "房 (interacts with) 平",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 平",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1027,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1028",
        "source" : "533",
        "target" : "274",
        "shared_name" : "房 (interacts with) 便",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 便",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1028,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1029",
        "source" : "533",
        "target" : "116",
        "shared_name" : "房 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1030",
        "source" : "533",
        "target" : "233",
        "shared_name" : "房 (interacts with) 毗",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 毗",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1031",
        "source" : "533",
        "target" : "176",
        "shared_name" : "房 (interacts with) 馮",
        "shared_interaction" : "interacts with",
        "name" : "房 (interacts with) 馮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1024",
        "source" : "532",
        "target" : "438",
        "shared_name" : "方 (interacts with) 甫",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 甫",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1025",
        "source" : "532",
        "target" : "94",
        "shared_name" : "方 (interacts with) 鄙",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 鄙",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1025,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1020",
        "source" : "532",
        "target" : "178",
        "shared_name" : "方 (interacts with) 徧",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 徧",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1021",
        "source" : "532",
        "target" : "97",
        "shared_name" : "方 (interacts with) 封",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 封",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1022",
        "source" : "532",
        "target" : "112",
        "shared_name" : "方 (interacts with) 父",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 父",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1022,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1023",
        "source" : "532",
        "target" : "506",
        "shared_name" : "方 (interacts with) 府",
        "shared_interaction" : "interacts with",
        "name" : "方 (interacts with) 府",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1015",
        "source" : "531",
        "target" : "87",
        "shared_name" : "敷 (interacts with) 拂",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 拂",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1016",
        "source" : "531",
        "target" : "439",
        "shared_name" : "敷 (interacts with) 芳",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 芳",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1016,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1017",
        "source" : "531",
        "target" : "189",
        "shared_name" : "敷 (interacts with) 丕",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 丕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1018",
        "source" : "531",
        "target" : "168",
        "shared_name" : "敷 (interacts with) 披",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 披",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1018,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "1019",
        "source" : "531",
        "target" : "179",
        "shared_name" : "敷 (interacts with) 峯",
        "shared_interaction" : "interacts with",
        "name" : "敷 (interacts with) 峯",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 1019,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "601",
        "source" : "274",
        "target" : "126",
        "shared_name" : "便 (interacts with) 婢",
        "shared_interaction" : "interacts with",
        "name" : "便 (interacts with) 婢",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 601,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "697",
        "source" : "399",
        "target" : "533",
        "shared_name" : "步 (interacts with) 房",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 房",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "698",
        "source" : "399",
        "target" : "243",
        "shared_name" : "步 (interacts with) 傍",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 傍",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 698,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "699",
        "source" : "399",
        "target" : "177",
        "shared_name" : "步 (interacts with) 頻",
        "shared_interaction" : "interacts with",
        "name" : "步 (interacts with) 頻",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "950",
        "source" : "519",
        "target" : "399",
        "shared_name" : "薄 (interacts with) 步",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 步",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "951",
        "source" : "519",
        "target" : "206",
        "shared_name" : "薄 (interacts with) 捕",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 捕",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "952",
        "source" : "519",
        "target" : "246",
        "shared_name" : "薄 (interacts with) 裴",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 裴",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "953",
        "source" : "519",
        "target" : "370",
        "shared_name" : "薄 (interacts with) 蒲",
        "shared_interaction" : "interacts with",
        "name" : "薄 (interacts with) 蒲",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 953,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "689",
        "source" : "389",
        "target" : "199",
        "shared_name" : "扶 (interacts with) 分",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 分",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "690",
        "source" : "389",
        "target" : "112",
        "shared_name" : "扶 (interacts with) 父",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 父",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 690,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "691",
        "source" : "389",
        "target" : "176",
        "shared_name" : "扶 (interacts with) 馮",
        "shared_interaction" : "interacts with",
        "name" : "扶 (interacts with) 馮",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "682",
        "source" : "385",
        "target" : "116",
        "shared_name" : "必 (interacts with) 比",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 比",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "683",
        "source" : "385",
        "target" : "114",
        "shared_name" : "必 (interacts with) 𢌿",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 𢌿",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "684",
        "source" : "385",
        "target" : "342",
        "shared_name" : "必 (interacts with) 卑",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 卑",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 684,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "685",
        "source" : "385",
        "target" : "102",
        "shared_name" : "必 (interacts with) 賔",
        "shared_interaction" : "interacts with",
        "name" : "必 (interacts with) 賔",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "560",
        "source" : "126",
        "target" : "274",
        "shared_name" : "婢 (interacts with) 便",
        "shared_interaction" : "interacts with",
        "name" : "婢 (interacts with) 便",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "922",
        "source" : "506",
        "target" : "226",
        "shared_name" : "府 (interacts with) 反",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 反",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "923",
        "source" : "506",
        "target" : "277",
        "shared_name" : "府 (interacts with) 并",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 并",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "924",
        "source" : "506",
        "target" : "532",
        "shared_name" : "府 (interacts with) 方",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 方",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "925",
        "source" : "506",
        "target" : "199",
        "shared_name" : "府 (interacts with) 分",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 分",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "926",
        "source" : "506",
        "target" : "97",
        "shared_name" : "府 (interacts with) 封",
        "shared_interaction" : "interacts with",
        "name" : "府 (interacts with) 封",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "666",
        "source" : "374",
        "target" : "226",
        "shared_name" : "孚 (interacts with) 反",
        "shared_interaction" : "interacts with",
        "name" : "孚 (interacts with) 反",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "583",
        "source" : "246",
        "target" : "404",
        "shared_name" : "裴 (interacts with) 部",
        "shared_interaction" : "interacts with",
        "name" : "裴 (interacts with) 部",
        "interaction" : "interacts with",
        "weight" : 1,
        "SUID" : 583,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}